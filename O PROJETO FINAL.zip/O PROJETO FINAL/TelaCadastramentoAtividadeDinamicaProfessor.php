
<?php 

session_start();

$_SESSION['fase']=1;
$_SESSION['info_linha']='';
$_SESSION['n_linha']=1;

$_SESSION['dado_Fase1']='';
$_SESSION['dado_Fase2']='';


$_SESSION['info_linha1']='';
$_SESSION['info_linha2']='';
$_SESSION['info_linha3']='';

$_SESSION['Tipo_Fase1']=0;
$_SESSION['Tipo_Fase2']=0;

$_SESSION['texto']='';

$_SESSION['id_prova']=0;



$_SESSION['texto_tipo_1']='';

$msg='';


$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

$nome='';

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

      if ($mysqli-> connect_errno) 
      echo "Falha na Conexão: (".$mysqli-> connect_errno.")".$mysqli-> connect_errno;

		$consulta_id_prova = "SELECT max(id_prova) as ID  FROM tabela_prova";
        /*$con_id_prova = $mysqli-> query($consulta_id_prova) or die($mysqli-> erro);*/

 if (!$mysqli -> query( $consulta_id_prova))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_id_prova = $mysqli-> query($consulta_id_prova);
      
    }



	// Create connection
				$conn = mysqli_connect($host,$usuario,$senha,$bd);
				// Check connection
				if (!$conn) {
				      die("Connection failed: " . mysqli_connect_error());
				}
		 
					/*echo "Connected successfully";*/






/*-------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------Busca IE---------------------------------------------------------------------------------------*/

$var_nome_professor= $_SESSION['session_NOME_professor'];

$var_ID_professor=$_SESSION['session_ID_professor'];


$sql_busca_IE="SELECT distinct (ti.nome_instituto) as nome_IE, tp.nome_professor as nome_prof FROM tabela_prof_instituto as tpi, tabela_professor as tp,tabela_instituto as ti where tpi.id_professor = tp.id_professor and tpi.id_instituto = ti.id_instituto and tp.id_professor ='$var_ID_professor' ";

         if (!$mysqli -> query( $sql_busca_IE))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_IE = $mysqli-> query($sql_busca_IE);
         
            
          }

  
$sql_busca_professor=" SELECT * FROM tabela_professor where id_professor='$var_ID_professor' ";

         if (!$mysqli -> query( $sql_busca_professor))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_PROF = $mysqli-> query($sql_busca_professor);
           
            
          }
  
/*-----------------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------------Buscar DIS ------------------------------------------------------------------------*/
$var_nome_IE='';
/*$var_nome_professor='Denise Cipriano';*/
if (isset($_POST['btn-ok']))
 {

  $var_nome_IE=$_POST['combobox_IE'];
  $_SESSION['sessao_nome_IE_aux']=$_POST['combobox_IE'];
  $msg=$var_nome_IE;
}

$sql_pesquisa_IE="SELECT * from tabela_instituto WHERE nome_instituto='$var_nome_IE'";

  if (!$mysqli -> query( $sql_pesquisa_IE))
             {
                  echo("Error description: " . $mysqli -> error);
                  
          }else
          {
            $sql_ie = $mysqli-> query($sql_pesquisa_IE);
            
            
          }


  while ($dado_IE_ID = $sql_ie-> fetch_array())
  {

     $_SESSION['session_ID_IE_aux']= $dado_IE_ID['id_instituto'];
    
    
  }
   $var_ID_IE=$_SESSION['session_ID_IE_aux'];


$sql_busca_DIS="SELECT td.nome_disciplina as nome_dis, td.id_disciplina as id_dis FROM tabela_prof_disciplina as tpd, tabela_professor as tp,tabela_disciplina as td 
WHERE tp.nome_professor ='$var_nome_professor' and td.id_instituto='$var_ID_IE' and tpd.id_professor = tp.id_professor and tpd.id_disciplina = td.id_disciplina ;";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                  
          }else
          {
            $sql_resultado_DIS = $mysqli-> query($sql_busca_DIS);
            
            
          }

 
/*-----------------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------B O T A O  C A D A S T R A R ------------------------------------------------------------*/



          if (isset($_POST['btn_cadastrar'])) 

          {

                $_SESSION['session_Nome_DIS_aux']=$_POST['combobox_DIS'];
                $var_nome_DIS= $_SESSION['session_Nome_DIS_aux'];

                $sql_pesquisa_DIS="SELECT  td.id_disciplina as id_dis FROM tabela_disciplina as td 
                WHERE  td.id_instituto=' $var_ID_IE'  and td.nome_disciplina = '$var_nome_DIS' ";

                if (!$mysqli -> query( $sql_pesquisa_DIS))
                  {
                      echo("Error description: " . $mysqli -> error);
                  
                   }else
                  {
                    $sql_DIS_novo = $mysqli-> query($sql_pesquisa_DIS);
            
            
                  }

                  while ($dado_DIS_ID = $sql_DIS_novo-> fetch_array())
                  {

                    $_SESSION['session_ID_DIS_aux']= $dado_DIS_ID['id_dis'];
                    
                    
                  }

                $nome=$_SESSION['session_NOME_professor'];

                $titulo = $_POST['campo_titulo'];  

                $assunto = $_POST['combo_assunto'];  

                $var_serial_disciplina= $_SESSION['session_ID_DIS_aux'];


                $serial_IE=$_SESSION['session_ID_IE_aux'];

                $id_atual=  $_SESSION['id_prova_atual'];

                $var_objetivo =$_POST['campo_objetivo']; 

                $sql = "INSERT INTO tabela_prova (nome_prof,titulo_exercicio,assunto_exercicio,id_prova,id_instituto,id_disciplina,tipo,id_professor,objetivo)
                 VALUES (' $nome',' $titulo',' $assunto',$id_atual,' $serial_IE',' $var_serial_disciplina','DINAMICO',' $var_ID_professor',' $var_objetivo')";
                  
                    if (mysqli_query($conn, $sql))
                {
                      echo "Dado na Tabela PROVA ADD!!";
                      header('Location: JanelaCadastramentoAtividadeDinamicaProfessor2.php');
                } else {
                      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                }

                 
          }



          if (isset($_POST['volt']))

             {
              header('Location: MenuPrincipalNovo.php');
            }




?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<body contenteditable>
  
	<form action="" method="POST">
			<?php while ($dado_id_prova = $con_id_prova-> fetch_array()){ ?>


					<h1 align="center">Cadastro do Exercício</h1>

          <label>Código da Prova </label> <input type="text" name="campo_codigo" disabled=""
           value= <?php echo $dado_id_prova['ID'] +1?> >
            <br><br>
            <?php $_SESSION['id_prova_atual']= $dado_id_prova['ID'] +1; ?>
            <label>Tipo da Atividade: Dinâmica</label><br><br>

             <label>Instituto de Ensino: </label>
                <select class="combo-estilo"  name="combobox_IE">
   <option ><?php echo $msg; ?></option> 
    <?php while ($dado_IE = $sql_resultado_IE-> fetch_array()){ ?>


   
   <option  value="<?php echo $dado_IE['nome_IE'] ?>" ><?php echo $dado_IE['nome_IE'] ?></option>
   


   <?php }   ?>
   
   </select><button name="btn-ok" id="btn-estilo" ><i class="fa fa-check"></i></button>

					<label>Nome Professor: </label>  <label ><?php echo $var_nome_professor; ?></label> <br><br>
					<label>Título do Exercício: </label>  <input type="text" name="campo_titulo"><br><br>

					<label>Escolha o Assunto do Exercício </label><select   class="chosen" name="combo_assunto" style="">
											
											

												   <option value=""></option>
											       <option value="Imagem">Imagem</option>
											       <option value="Formulário">Formulário</option>
											       <option value="Listas">Listas</option>
											       <option value="Tabelas">Tabelas</option>
											       <option value="CSS">CSS</option>
											       <option value="Botão">Botão</option>
											       
											                        
											                        
											</select><br><br>

					
            <label>Objetivo: </label>  <input type="text" name="campo_objetivo"><br><br>
            <label>Tipo da Atividade: Dinâmica</label><br>
           
   <label>Disciplina: </label>
                <select  class="combo-estilo"    name="combobox_DIS"  >
   <option ></option> 
    <?php while ($dado_DIS = $sql_resultado_DIS-> fetch_array()){ ?>


   
   <option  value="<?php echo $dado_DIS['nome_dis'] ?>" ><?php echo $dado_DIS['nome_dis'] ?></option>
   


   <?php }   ?>
   
   </select> 
					<button class="botao"  name="btn_cadastrar">Cadastrar</button>   <button class="botao" name="volt">Voltar</button>


		    <?php }   ?>
	</form>

</body>
</html>

<style type="text/css">
	@import url(https://fonts.googleapis.com/css?family=Walter+Turncoat);
html {
  background: -webkit-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -moz-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -ms-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -o-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: linear-gradient(90deg, #485563 10%, #29323c 90%);
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
  overflow: hidden
}

body {
  font-size: 40px;
  color: #E8E8E8;
  font-family: "Walter Turncoat", cursive;
  display: block;
  width: 80%;
  height: 80%;
  min-height: auto;
  margin: 30px auto 0 auto;
  background-color: #497959;
  padding: 20px 30px;
  overflow-y: auto;
  box-shadow: -1px 2px 2px 0px #555, inset 0 0 10px 0 #555;
  -webkit-border-radius: 10px;
  -khtml-border-radius: 10px;
  -moz-border-radius: 10px;
  -ms-border-radius: 10px;
  -o-border-radius: 10px;
  border-radius: 10px;
  border: #B78240 solid 10px;
  
  background-size: cover;
  background-repeat: no-repeat;
  position: relative;
}

body:after {
  content: "";
  display: block;
  position: fixed;
  -webkit-border-radius: 0.1em 0.1em 0 0.1em;
  -khtml-border-radius: 0.1em 0.1em 0 0.1em;
  -moz-border-radius: 0.1em 0.1em 0 0.1em;
  -ms-border-radius: 0.1em 0.1em 0 0.1em;
  -o-border-radius: 0.1em 0.1em 0 0.1em;
  border-radius: 0.1em 0.1em 0 0.1em;
  width: 50px;
  height: 8px;
  background: #f1f1f1;
  top: 80%;
  margin-top: 75px;
  margin-right: 60px;
  right: 5%;
  box-shadow: inset 0 -4px 1px rgba(0, 0, 0, 0.3), -1px -1px 1px rgba(0, 0, 0, 0.2), 0 2px 0 rgba(0, 0, 0, 0.3)
}

a {
  color: #ff0
}

h1
	{
		color: white;
		font-size: 1.5em;
	}


	label
	{
		font-size: 1em;
		color: white;
	}
/*
	input
	{
		width: 300px;
		border: 5px solid red;
	}

*/

input  {
 
  
  border: none;
  
  width: 30ch;
  background: repeating-linear-gradient(90deg, white 0, white 1ch, transparent 0, transparent 1.5ch) 0 100%/ 100ch 2px no-repeat;
  font: 2ch droid sans mono, consolas, monospace;
  letter-spacing: 0.5ch;
  color: white;

}

select {
 
  
  border: none;
  
  width: 30ch;
  background: repeating-linear-gradient(90deg, white 0, white 1ch, transparent 0, transparent 1.5ch) 0 100%/ 100ch 2px no-repeat;
  font: 2ch droid sans mono, consolas, monospace;
  letter-spacing: 0.5ch;
  color: black;
  cursor: pointer;

}

input:focus {
  outline: none;
  color: dodgerblue;
}

.botao
{
	font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
 font-size: 0.8em;
  cursor: pointer;
margin:10px;
}

.botao:hover
{
  font-family: "Walter Turncoat", cursive;
  border: none;
  background: none;
  color: red;
   letter-spacing: 0.5ch;
 font-size: 0.8em;
  cursor: pointer;
margin:10px;
}

#btn-estilo
{
  font-family: "Walter Turncoat", cursive;
  border: none;
  background: none;
  
   letter-spacing: 0.5ch;
 font-size: 0.8em;
  cursor: pointer;
margin:10px;

color: white;

}
</style>