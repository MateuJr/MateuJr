<?php 

session_start();

  $host ="localhost";	
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  		$mysqli = new mysqli($host,$usuario,$senha,$bd);

  		$var_mysqli = new mysqli($host,$usuario,$senha,$bd);

  		$variavel_mysqli = new mysqli($host,$usuario,$senha,$bd);





/*---------------------------------------------------------------------------------------------------------*/

  		$consulta_id_aluno= "SELECT max(id_aluno) as ID_ALUNO  FROM tabela_aluno";

      if (!$mysqli -> query( $consulta_id_aluno))
       {
            echo("Error description: " . $mysqli -> error);
	    }else
	    {
	      $con_id_aluno = $mysqli-> query($consulta_id_aluno);
	      
	    }

	    while ($dado_id_aluno = $con_id_aluno-> fetch_array())
	    {
	    	$id_user = $dado_id_aluno['ID_ALUNO'] +1;
	    	$_SESSION['campo_id_aluno_session']=$id_user;
	    }


    /*------------------------------------------------------------------------------------------------------*/


    $consulta_instituto = "SELECT nome_instituto as Nome_Instituto_IE  FROM tabela_instituto";

	      if (!$mysqli -> query( $consulta_instituto))

	        {
		            echo("Error description: " . $mysqli -> error);
		    }else
		    {
		      $con_consulta_instituto = $mysqli-> query($consulta_instituto);
		      
		    }


/*-----------------------------------------------------------------------------------------------------------*/
 
$busca_IE='';
    if (isset($_POST['combobox_IE']))
        {
        $busca_IE=$_POST['combobox_IE'];
       }
       
    $pesquisar_professor ="SELECT distinct(tp.nome_professor) as prof FROM tabela_prof_instituto as tpi INNER JOIN tabela_professor as tp ON (tpi.id_professor = tp.id_professor)
INNER JOIN tabela_instituto as ti ON
(tpi.id_instituto = ti.id_instituto )
WHERE ti.nome_instituto = '$busca_IE' ";

if (!$mysqli -> query( $pesquisar_professor))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_professor = $mysqli-> query($pesquisar_professor);
      
    }

/*-----------------------------------------------------------------------------------------------------------*/



/* 
==============================================================================================================

	 									BTN - ENVIAR - NOME - EMAIL

==============================================================================================================
 */

			if (isset($_POST['btn-Enviar-Nome-Email'])) 

		 	{
		 		
			

			    $variavel_email='';
			    $variavel_id_aluno='';
			    $variavel_nome_aluno='';

			    $_POST['campo-email'];

			    $_SESSION['campo_aluno_email_session']=$_POST['campo-email'];
			    $variavel_email=$_SESSION['campo_aluno_email_session'];

			    $variavel_id_aluno=$_SESSION['campo_id_aluno_session'];
			    $_SESSION['session_Numero_ID_Aluno_Atualizado']=$_SESSION['campo_id_aluno_session'];

			    $_SESSION['campo_nome_aluno_session']=$_POST['campo-nome'];
			    $variavel_nome_aluno= $_SESSION['campo_nome_aluno_session'];
			    
			    if (empty($variavel_nome_aluno) or empty($variavel_email) )
			     {
		 			$_SESSION['MSG_INFO_1']='Por favor preencha os campos Obrigatórios!';
		 		}else{



			    $sql = "INSERT INTO tabela_aluno (id_aluno,nome_aluno,email)
		                     VALUES (' $variavel_id_aluno',' $variavel_nome_aluno',' $variavel_email')";


		                        if (mysqli_query($mysqli, $sql))
		                    {
		                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
		                          $_SESSION['MSG_aluno_email_session']='Dados Inseridos com Sucesso!';
		                          $_SESSION['Permissao_painel_2']='';
		                          $_SESSION['Permissao_painel_1']='disabled=""';
		                          $_SESSION['Permissao_Combo_IE']='';

		                          $_SESSION['MSG_INFO_1']='Dados Inseridos com Sucesso!';

		                    } else {
		                          echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
		                          $_SESSION['MSG_aluno_email_session']='Dados Inseridos Incorretamente!';
		                    }

		             $_SESSION['MSG_Combobox_IE_session_SELECIONADO']='Selecione...';
		             $_SESSION['Permissao_Combo_PROF']='disabled=""';
		      }
			}
/*
=============================================================================================================*/

/*
==============================================================================================================

							 					B O T A O 1 Instituto Ensino IE

==============================================================================================================

*/
	

/*-----------------------------------------------------------------------------------------------*/
$var_desbloquear_2_janela=$_SESSION['Permissao_painel_2'];

		if (isset($_POST['btn-Enviar-IE']))

		 {
		 	$busca_IE='';
					$_SESSION['Permissao_Combo_IE']='disabled=""';

					$_SESSION['campo_nome_IE_session']=$_POST['combobox_IE'];

				

				   $busca_IE=$_SESSION['campo_nome_IE_session'];
				  

				   $_SESSION['Permissao_Combo_PROF']='';
        if (empty($busca_IE)  )
			     {
			     	$_SESSION['MSG_IE_session']='Por favor escolha um Instituto de Ensino!';
			     	$_SESSION['Permissao_Combo_IE']='';

			     }else
			     {

			     
			    $pesquisar_professor ="SELECT distinct(tp.nome_professor) as prof 
			    FROM tabela_prof_instituto as tpi INNER JOIN tabela_professor as tp ON (tpi.id_professor = tp.id_professor)
					INNER JOIN tabela_instituto as ti ON
					(tpi.id_instituto = ti.id_instituto )
					WHERE ti.nome_instituto = '$busca_IE' ";

					if (!$mysqli -> query( $pesquisar_professor))
					       {
					            echo("Error description: " . $mysqli -> error);
					    }else
					    {
					      $con_professor = $mysqli-> query($pesquisar_professor);
					      
					    }

					    $sql_buscar_codigo_IE="SELECT id_instituto FROM tabela_instituto
					     WHERE nome_instituto =' $busca_IE ' ";

					    if (!$var_mysqli -> query( $sql_buscar_codigo_IE))
					       {
					            echo("Error description: " . $var_mysqli -> error);
					    }else
					    {
					      $con_IE_codigo = $var_mysqli-> query($sql_buscar_codigo_IE);
					      
					    }

					    while ($dado_numero_IE = $con_IE_codigo-> fetch_array())
					    {
					    	$_SESSION['session_Numero_IE']= $dado_numero_IE['id_instituto'];
					    	$_SESSION['session_Numero_IE_atualizado']=$dado_numero_IE['id_instituto'];
					    }

					    

/* ---------------------------------------------------------------------------------------------------------*/	

					    	if (isset($_POST['combobox_IE']))

	 {
		$_SESSION['campo_nome_IE_session']=$_POST['combobox_IE'];
	}

$nome_IE_pesquisa=$_SESSION['campo_nome_IE_session'];
$consulta_instituto_IE = "SELECT id_instituto as ID_IE,nome_instituto as nome_IE  FROM tabela_instituto 
		WHERE nome_instituto = '$nome_IE_pesquisa' ";

	      if (!$mysqli -> query( $consulta_instituto_IE))

	        {
		            echo("Error description: " . $mysqli -> error);
		    }else
		    {
		      $con_consulta_IE_ID = $mysqli-> query($consulta_instituto_IE);
		      
		    }
		    while ($dado_ID_IE = $con_consulta_IE_ID-> fetch_array())
					   
					    {
					    	
					    	$_SESSION['session_Numero_ID_IE_Atualizado']=$dado_ID_IE['ID_IE'];
					    	$_SESSION['session_Nome_IE_Atualizado']=$dado_ID_IE['nome_IE'];
					    	
					    }

					    $variavel_id_aluno_n=$_SESSION['session_Numero_ID_Aluno_Atualizado'];

						$id_ie_variavel=$_SESSION['session_Numero_ID_IE_Atualizado'];

						$nome_ie_atual=$_SESSION['session_Nome_IE_Atualizado'];

					    $sql_Aluno_update_ID_IE = "UPDATE tabela_aluno SET
		                    id_instituto='$id_ie_variavel', instituto_ensino='$nome_ie_atual'
		                    WHERE id_aluno=$variavel_id_aluno_n";


		                      
		                        if (mysqli_query($mysqli, $sql_Aluno_update_ID_IE))
		                    {
		                        
		                         $_SESSION['MSG_IE_session']='Dados inseridos com Sucesso!';

		                         $_SESSION['MSG_INFO_2']='Dados inseridos com Sucesso!';

		                    } else {
		                          echo "Error: " . $sql_Aluno_update_ID_IE . "<br>" . mysqli_error($mysqli);
		                    }

		       }
		}
/*
=============================================================================================================*/
/*


/*----------------------------------------------------------------------------------------------------------*/



$busca_nome_professor=$_SESSION['session_Nome_Combobox_Professor'];

$id_ie_variavel=$_SESSION['session_Numero_ID_IE_Atualizado'];
	

	 $sql_teste="SELECT distinct (td.nome_disciplina) as nome_dis FROM tabela_prof_disciplina as tpd, tabela_professor as tp,tabela_disciplina as td 
WHERE tp.nome_professor =' $busca_nome_professor ' and td.id_instituto='$id_ie_variavel' and tpd.id_professor = tp.id_professor and tpd.id_disciplina = td.id_disciplina ;";

			   if (!$variavel_mysqli -> query( $sql_teste))
			       {
			            echo("Error description: " . $variavel_mysqli -> error);
			           
			    }else
			    {
			      $sql_resultado = $variavel_mysqli-> query($sql_teste);
			     /* echo "jefferson";*/
			      
			    }



	 while ($dado_ddd = $sql_resultado-> fetch_array())
	 {
	 	
	 }


if (isset($_POST['teste']))
 {
	if (isset($_POST['combobox_professor']))
			 {
				$_SESSION['session_Nome_Combobox_Professor']=$_POST['combobox_professor'];
			}

			if (empty($_POST['combobox_professor']) or $_POST['combobox_professor']=='Selecione...' )
			 {

				$_SESSION['MSG_INFO_Painel_3_1']='Selecione um Professor Por Gentileza!';

				
			$_SESSION['MSG_INFO_Painel_3_2']='';
				$id_ie_variavel=$_SESSION['session_Numero_ID_IE_Atualizado'];

$busca_IE=$_SESSION['campo_nome_IE_session'];  

				  
       
			    $pesquisar_professor ="SELECT distinct(tp.nome_professor) as prof 
			    FROM tabela_prof_instituto as tpi INNER JOIN tabela_professor as tp ON (tpi.id_professor = tp.id_professor)
					INNER JOIN tabela_instituto as ti ON
					(tpi.id_instituto = ti.id_instituto )
					WHERE ti.nome_instituto = '$busca_IE' ";

					if (!$mysqli -> query( $pesquisar_professor))
					       {
					            echo("Error description: " . $mysqli -> error);
					    }else
					    {
					      $con_professor = $mysqli-> query($pesquisar_professor);
					      
					    }	
			}else
			{

					$busca_nome_professor=$_SESSION['session_Nome_Combobox_Professor'];

					$id_ie_variavel=$_SESSION['session_Numero_ID_IE_Atualizado'];

					
					 while ($dado_ddd = $sql_resultado-> fetch_array())
					 {
					 	
					 }

					 $_SESSION['session_NUMERO']=0;

				$_SESSION['MSG_INFO_Painel_3_1']='Professor Selecionado!';
				$_SESSION['MSG_INFO_Painel_3_2']='';
				$a=$_POST['combobox_professor'];
				
			}
}

$xa=0;
$gg=$_SESSION['session_Nome_Combobox_Professor'];
$hh=$_SESSION['session_Numero_ID_IE_Atualizado'];

if  ($xa>=$_SESSION['session_NUMERO'])    {

	$gg=$_SESSION['session_Nome_Combobox_Professor'];
	$hh=$_SESSION['session_Numero_ID_IE_Atualizado'];

	 $sql_teste="SELECT td.nome_disciplina as xx FROM tabela_prof_disciplina as tpd, tabela_professor as tp,tabela_disciplina as td 
WHERE tp.nome_professor ='$gg' and td.id_instituto='$hh' and tpd.id_professor = tp.id_professor and tpd.id_disciplina = td.id_disciplina ;";

			   if (!$variavel_mysqli -> query( $sql_teste))
			       {
			            echo("Error description: " . $variavel_mysqli -> error);
			            
			    }else
			    {
			      $sql_resultad = $variavel_mysqli-> query($sql_teste);
			      
			      
			    }

			    
}

/*====================================================================================================*/

	if (isset($_POST['salvar-IE-PROF']))
	 {
		$_SESSION['session_Nome_DIS']=$_POST['combobox_disciplina'];

		$var_nome_disc=$_SESSION['session_Nome_DIS'];

		$hh=$_SESSION['session_Numero_ID_IE_Atualizado'];

		$SQL_DIS_dados= "SELECT nome_disciplina as nd, id_disciplina as id_dis
		  FROM tabela_disciplina WHERE nome_disciplina = '$var_nome_disc' and id_instituto= '$hh' ";

      if (!$mysqli -> query( $SQL_DIS_dados))
       {
            echo("Error description: " . $mysqli -> error);
	    }else
	    {
	      $con_id_d = $mysqli-> query($SQL_DIS_dados);
	      
	    }

	    $v_Numero_dis='';
	    while ($dado_id_aluno_dis = $con_id_d-> fetch_array())
	    {
	    	$v_Numero_dis = $dado_id_aluno_dis['id_dis'] ;
	    	
	    }
	    	$variavel_id_aluno_n=$_SESSION['session_Numero_ID_Aluno_Atualizado'];

	      $sql_add_tabela_aluno_dis = "INSERT INTO tabela_disciplina_aluno (id_aluno,id_disciplina)
		                     VALUES (' $variavel_id_aluno_n',' $v_Numero_dis')";


		                        if (mysqli_query($mysqli, $sql_add_tabela_aluno_dis))
		                    {
		                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
		                          

		                    } else {
		                          echo "Error: " . $sql_add_tabela_aluno_dis . "<br>" . mysqli_error($mysqli);
		                         
		                    }

$nome_professor_dado= $_SESSION['session_Nome_Combobox_Professor'];

		                    $SQL_PROF_dados= "SELECT id_professor as id_prof
		  FROM tabela_professor WHERE nome_professor = '$nome_professor_dado' ";

      if (!$mysqli -> query( $SQL_PROF_dados))
       {
            echo("Error description: " . $mysqli -> error);
	    }else
	    {
	      $con_id_prof = $mysqli-> query($SQL_PROF_dados);
	      
	    }

	    $v_ID_prof='';
	    while ($dado_ID_prof = $con_id_prof-> fetch_array())
	    {
	    	$v_ID_prof = $dado_ID_prof['id_prof'] ;
	    	
	    }
	    	$variavel_id_aluno_n=$_SESSION['session_Numero_ID_Aluno_Atualizado'];

	     $sql_add_tabela_aluno_professor = "INSERT INTO tabela_prof_aluno (id_aluno,id_professor)
		                     VALUES (' $variavel_id_aluno_n',' $v_ID_prof')";


		                        if (mysqli_query($mysqli, $sql_add_tabela_aluno_professor))
		                    {
		                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
		                          

		                    } else {
		                          echo "Error: " . $sql_add_tabela_aluno_professor . "<br>" . mysqli_error($mysqli);
		                         
		                    }

		               

/*-------------------------------------------------------------------------------------------------------*/
		               
		               $busca_IE=$_SESSION['campo_nome_IE_session'];  

				  
       
			    $pesquisar_professor ="SELECT distinct(tp.nome_professor) as prof 
			    FROM tabela_prof_instituto as tpi INNER JOIN tabela_professor as tp ON (tpi.id_professor = tp.id_professor)
					INNER JOIN tabela_instituto as ti ON
					(tpi.id_instituto = ti.id_instituto )
					WHERE ti.nome_instituto = '$busca_IE' ";

					if (!$mysqli -> query( $pesquisar_professor))
					       {
					            echo("Error description: " . $mysqli -> error);
					    }else
					    {
					      $con_professor = $mysqli-> query($pesquisar_professor);
					      
					    }

			$_SESSION['MSG_INFO_Painel_3_1']='';
			$_SESSION['MSG_INFO_Painel_3_2']='Dados inseridos com sucesso!';
	}

	
/*============================================================================================================================================*/
	
	

/*============================================================================================================================================*/
		if (isset($_POST['btn-palavra-User']))

		 {
			$var_nome_USUARIO='';

			$var_nome_USUARIO=$_POST['campo-usuario'];

			$var_palavra_chave='';
			$var_palavra_chave= $_POST['campo-palavra'];

			$_SESSION['session_Nome_USUARIO']=$_POST['campo-usuario'];

			$_SESSION['session_PALAVRA_CHAVE']=$_POST['campo-palavra'];

			if (($_SESSION['session_Nome_USUARIO'] =='' ) or ($_SESSION['session_PALAVRA_CHAVE'] =='') )
			 {
				
				$_SESSION['MSG_Usuario_session']='Por favor, preencha os campos Obrigatórios!';

			}else{
					   $SQL_Usuario_dados= "SELECT usuario as user,id_usuario 
				  FROM tabela_usuario WHERE usuario = ' $var_nome_USUARIO ' ";

		      if (!$mysqli -> query( $SQL_Usuario_dados))
		       {
		            echo("Error description: " . $mysqli -> error);
			    }else
			    {
			      $con_Usuario = $mysqli-> query($SQL_Usuario_dados);
			      
			    }


					    $var_USER='';
			    while ($dado_USUARIO = $con_Usuario-> fetch_array())
			    {
			    	$var_USER = $dado_USUARIO['user'] ;
			    	
			    }

				    if ($var_USER !='')
				     {
				    	
				    	$_SESSION['MSG_Usuario_session']='Este usuário já existe!';
				    }else
				    {


				    	
/*----------------------------- ADICIONAR  USUARIO ----------------------------------------------------------*/

						$vet_user_tipo='ALUNO';
				    	$var_usuario=$_SESSION['session_Nome_USUARIO'];


				    	$sql_usuario_inserir = "INSERT INTO tabela_usuario (usuario,tipo)
                     VALUES (' $var_usuario',' $vet_user_tipo')";


		                        if (mysqli_query($mysqli, $sql_usuario_inserir))
		                    {
		                         /* echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
		                    } else {
		                          echo "Error: " . $sql_usuario_inserir . "<br>" . mysqli_error($mysqli);
		                    }

/*----------------------------- ATUALIZAR  ALUNO ------------------------------------------------------------*/

						$var_palavra_chave=$_SESSION['session_PALAVRA_CHAVE'];

						$variavel_id_aluno_n=$_SESSION['session_Numero_ID_Aluno_Atualizado'];


		                     $sql_aluno_update = "UPDATE tabela_aluno SET
		                    palavra_chave='$var_palavra_chave'
		                    WHERE id_aluno=$variavel_id_aluno_n";


		                      
		                        if (mysqli_query($mysqli, $sql_aluno_update))
		                    {
		                          /*echo "<br>Dado na Tabela Professor ATUALIZADO!!";*/
		                          $_SESSION['MSG_Usuario_session']='Dados inseridos com Sucesso!';

		                    } else {
		                          echo "Error: " . $sql_aluno_update . "<br>" . mysqli_error($mysqli);
		                    }

				    }

				}

		}


/*=============================  GRAVAR  SENHA ===============================================================*/		
			if (isset($_POST['btn-salvar-senha']))
			 {
			 	$s1='';
			 	$s2='';
				$s1=$_POST['campo-senha'];
				$s2=$_POST['campo-confirmar'];

				$var_teste_user='';
					

					$var_teste_user=$_SESSION['session_Nome_USUARIO'];
					

					$consulta_user_1 = "SELECT usuario,id_usuario FROM tabela_usuario 
									  where usuario = ' $var_teste_user ' ";

			      if (!$mysqli -> query( $consulta_user_1))
			       {
			            echo("Error description: " . $mysqli -> error);
			    }else
			    {
			      $con_user_1 = $mysqli-> query($consulta_user_1);


			    }
			    $vet_user='';
			    while ($dado_user = $con_user_1-> fetch_array())

			        {
			        	$vet_user=$dado_user['id_usuario'];
			        		
			        }


						if ( ($s1 != $s2) or empty($s1) or empty($s2) )

					 {

					 		$_SESSION['MSG_Senha_session']='Veririque a senha!';
					 }
					 else
					 {

					 		$var_senha =mysqli_escape_string($mysqli,$s1);
                			$var_senh=md5($var_senha);

                			$sql_user_update = "UPDATE tabela_usuario SET
		                    senha='$var_senh'
		                    WHERE id_usuario=$vet_user";

				               if (mysqli_query($mysqli, $sql_user_update))
				           {
				               
				               $_SESSION['MSG_Senha_session']='Dados inseridos com sucesso!';

				            } else {
				                    echo "Error: " . $sql_user_update . "<br>" . mysqli_error($mysqli);
				                }


				               $variavel_id_aluno_n=$_SESSION['session_Numero_ID_Aluno_Atualizado'];

				                 $sql_aluno_update = "UPDATE tabela_aluno SET
		                    id_usuario='$vet_user'
		                    WHERE id_aluno=$variavel_id_aluno_n";


				                      
			           if (mysqli_query($mysqli, $sql_aluno_update))
				           {
				               
				               
				            } else {
				                    echo "Error: " . $sql_aluno_update . "<br>" . mysqli_error($mysqli);
				                }


				                $_SESSION['campo_id_aluno_session']='';

						$_SESSION['campo_aluno_email_session']='';

						$_SESSION['campo_nome_aluno_session']='';

						$_SESSION['MSG_aluno_email_session']='';

						$_SESSION['Permissao_painel_2']='disabled=""';

						$_SESSION['Permissao_painel_1']='';

						$_SESSION['Permissao_Combo_IE']='disabled=""';

						$_SESSION['campo_nome_IE_session']='';

						$_SESSION['session_Numero_IE']=0;
						$_SESSION['session_Numero_IE_atualizado']='';


						$_SESSION['MSG_Combobox_IE_session_SELECIONADO']='';


						$_SESSION['Permissao_Combo_PROF']='';

						$_SESSION['session_Numero_ID_Aluno_Atualizado']='';

						$_SESSION['session_Numero_ID_IE_Atualizado']='';

						$_SESSION['session_Nome_IE_Atualizado']='';

						$_SESSION['session_Nome_Combobox_Professor']='';

						$_SESSION['session_NUMERO']='';

						$_SESSION['session_Nome_DIS']='';


						$_SESSION['session_Nome_USUARIO']='';

						$_SESSION['session_PALAVRA_CHAVE']='';

						$_SESSION['MSG_Senha_session']='';

						$_SESSION['MSG_Usuario_session']='';

						$_SESSION['MSG_IE_session']='';


						$_SESSION['Permissao_IE']='';
						$_SESSION['MSG_INFO_1']='';

						$_SESSION['MSG_INFO_Painel_3_1']='';

						$_SESSION['MSG_INFO_Painel_3_2']='';

						 header('Location: TelaLogin.php');

					 }

					 
			}


?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href='http://fonts.googleapis.com/css?family=Bitter' rel='stylesheet' type='text/css'>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src ="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.min.css
">
</head>
<body>
	<form action="" method="POST">
<div class="form-style-10">
<h1>Registre-se como Aluno!<span>Insira seus dados pessoais e escolha sua faculdade!</span></h1>


    <div class="section"><span>1</span>Insira Nome/E-mail</div>
    <div class="inner-wrap">
        <label>Nome Completo*<input 
        	type="text"
        	<?php echo $_SESSION['Permissao_painel_1'] ; ?>
        	name="campo-nome"
        	value=<?php echo $_SESSION['campo_nome_aluno_session']; ?>>
        </label>

        <label>Email*<input
	         type="text"
	         <?php echo $_SESSION['Permissao_painel_1'] ; ?>
	         name="campo-email"
	         value= <?php echo $_SESSION['campo_aluno_email_session']; ?>>
	     </label>
       
         <input type="submit" name="btn-Enviar-Nome-Email" value="Enviar" /><h4 class="h4-class"><?php echo $_SESSION['MSG_INFO_1']; ?></h4>
    </div>

<div class="section"><span>2</span>Escolha sua Instituição de Ensino</div>
    <div class="inner-wrap">
       <label>Instituição de Ensino (IE)*</label><select
        class="chosen" name="combobox_IE">
	 <option ><?php echo $_SESSION['campo_nome_IE_session']; ?></option>
		<?php while ($dado_instituto = $con_consulta_instituto-> fetch_array()){ ?>


	 
	 <option <?php echo $_SESSION['Permissao_Combo_IE']; ?> value="<?php echo $dado_instituto['Nome_Instituto_IE'] ?>" ><?php echo $dado_instituto['Nome_Instituto_IE'] ?></option>
	 


	 <?php }   ?>
	 
	 </select>
	 <br><br><br>
         <input type="submit" name="btn-Enviar-IE" value="OK" /><br><br><label>IE--><?php echo $_SESSION['campo_nome_IE_session']; ?></label>
         <br><br>
         <h4 class="h4-class"><?php echo $_SESSION['MSG_IE_session']; ?></h4>
    </div>


    <div class="section"><span>3</span>Escolha Professor/Disciplina</div>
    <div class="inner-wrap">
       
        <label>Professor:* </label><select  class="chosen" name="combobox_professor">
	 <option >Selecione...</option>
		<?php while ($dado_Professor = $con_professor-> fetch_array()){ ?>


	 
	 <option  value="<?php echo $dado_Professor['prof'] ?>" ><?php echo $dado_Professor['prof'] ?></option>
	 


	 <?php }   ?>
	 <input type="submit" name="teste" value=">>" /><h4 class="h4-class"><?php echo $_SESSION['MSG_INFO_Painel_3_1']; ?></h4>
	 </select>
	 <br><br>
	 <label>Disciplina:* </label><select  class="chosen" name="combobox_disciplina">
	 <option >Selecione...</option> 
		<?php while ($dado_Professor = $sql_resultad-> fetch_array()){ ?>


	 
	 <option  value="<?php echo $dado_Professor['xx'] ?>" ><?php echo $dado_Professor['xx'] ?></option>
	 


	 <?php }   ?>
	 
	 </select> 

<br><br><br>
 <input type="submit" name="salvar-IE-PROF" value="Salvar" /> <h4 class="h4-class"><?php echo $_SESSION['MSG_INFO_Painel_3_2']; ?></h4>


    </div>

	<div class="section"><span>4</span>Insira Palavra-Chave/Usuário</div>
        <div class="inner-wrap">
        <label>Palavra-Chave:* <input 

         type="text"  name="campo-palavra" 
         value= <?php echo $_SESSION['session_PALAVRA_CHAVE'];?> ></label>
        <label>Usuário:* <input
         type="text"
          name="campo-usuario"
           value= <?php echo $_SESSION['session_Nome_USUARIO'];?> ></label>
        <input type="submit" name="btn-palavra-User" value="Salvar" />
        <br><br>
        <h4 class="h4-class"><?php echo $_SESSION['MSG_Usuario_session']; ?></h4>
    </div>


    <div class="section"><span>5</span>Cadastre uma Senha</div>
        <div class="inner-wrap">
        <label>Senha:* <input type="password" name="campo-senha" /></label>
        <label>Confirmar Senha:* <input type="password" name="campo-confirmar" /></label>
        <input type="submit" name="btn-salvar-senha" value="Salvar" />
        <br><br>
        <h4 class="h4-class"><?php echo $_SESSION['MSG_Senha_session']; ?></h4>
    </div>
    
</form>
</div>
</body>
<script type="text/javascript">
	$('.chosen').chosen();
</script>
</html>

<style type="text/css">

	.msg-1
	{
		color: red;
		font-size: 1.2em;
	}
.form-style-10{
	width:450px;
	padding:30px;
	margin:40px auto;
	background: #FFF;
	border-radius: 10px;
	-webkit-border-radius:10px;
	-moz-border-radius: 10px;
	box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.13);
	-moz-box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.13);
	-webkit-box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.13);
}
.form-style-10 .inner-wrap{
	padding: 30px;
	background: #F8F8F8;
	border-radius: 6px;
	margin-bottom: 15px;
}
.form-style-10 h1{
	background: #2A88AD;
	padding: 20px 30px 15px 30px;
	margin: -30px -30px 30px -30px;
	border-radius: 10px 10px 0 0;
	-webkit-border-radius: 10px 10px 0 0;
	-moz-border-radius: 10px 10px 0 0;
	color: #fff;
	text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.12);
	font: normal 30px 'Bitter', serif;
	-moz-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	-webkit-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	border: 1px solid #257C9E;
}
.form-style-10 h1 > span{
	display: block;
	margin-top: 2px;
	font: 13px Arial, Helvetica, sans-serif;
}
.form-style-10 label{
	display: block;
	font: 13px Arial, Helvetica, sans-serif;
	color: #888;
	margin-bottom: 15px;
}
.form-style-10 input[type="text"],
.form-style-10 input[type="date"],
.form-style-10 input[type="datetime"],
.form-style-10 input[type="email"],
.form-style-10 input[type="number"],
.form-style-10 input[type="search"],
.form-style-10 input[type="time"],
.form-style-10 input[type="url"],
.form-style-10 input[type="password"],
.form-style-10 textarea,
.form-style-10 select {
	display: block;
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	width: 100%;
	padding: 8px;
	border-radius: 6px;
	-webkit-border-radius:6px;
	-moz-border-radius:6px;
	border: 2px solid #fff;
	box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.33);
	-moz-box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.33);
	-webkit-box-shadow: inset 0px 1px 1px rgba(0, 0, 0, 0.33);
}

.form-style-10 .section{
	font: normal 20px 'Bitter', serif;
	color: #2A88AD;
	margin-bottom: 5px;
}
.form-style-10 .section span {
	background: #2A88AD;
	padding: 5px 10px 5px 10px;
	position: absolute;
	border-radius: 50%;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	border: 4px solid #fff;
	font-size: 14px;
	margin-left: -45px;
	color: #fff;
	margin-top: -3px;
}
.form-style-10 input[type="button"], 
.form-style-10 input[type="submit"]{
	background: #2A88AD;
	padding: 8px 20px 8px 20px;
	border-radius: 5px;
	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	color: #fff;
	text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.12);
	font: normal 30px 'Bitter', serif;
	-moz-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	-webkit-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.17);
	border: 1px solid #257C9E;
	font-size: 15px;
	cursor: pointer;
}
.form-style-10 input[type="button"]:hover, 
.form-style-10 input[type="submit"]:hover{
	background: #2A6881;
	-moz-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.28);
	-webkit-box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.28);
	box-shadow: inset 0px 2px 2px 0px rgba(255, 255, 255, 0.28);
}
.form-style-10 .privacy-policy{
	float: right;
	width: 250px;
	font: 12px Arial, Helvetica, sans-serif;
	color: #4D4D4D;
	margin-top: 10px;
	text-align: right;
}

/*========================================================================================*/
.h4-class
{
	color:red;
	font-size: 1.2em;
	text-align: center;
}
</style>