<?php
session_start();
$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";
$msg='Selecione...';

$var_ID_IE='';

$ocultar= 'style="display:none;"';

$Numero_IE='';
$Numero_DIS='';

$var_ID_PROF=$_SESSION['session_ID_professor'];
$mysqli = new mysqli($host,$usuario,$senha,$bd);


$conn = new mysqli ("localhost", "root", "", "projeto_tcc")
 or die("Error:" . mysqli_error($conn));

 $var_mysqli = new mysqli($host,$usuario,$senha,$bd);

 $_SESSION['sessao_ID_IE_aux']='';

 $ocultar= 'style="display:none;"';

$_SESSION['session_ocultar_MSG_DINAMICO']=$ocultar;
$ocultar=$_SESSION['session_ocultar_MSG_DINAMICO'];


/*===========================================================================================================================================*/

                            /*  Código Responsável por excluir as ATIVIDADES */
/*===========================================================================================================================================*/


if (isset($_POST['deletar']))
 {
  $ID= $_POST['deletar'];

$ocultar_div='';
$_SESSION['session_ocultar_MSG_DINAMICO']=$ocultar_div;
$ocultar_div=$_SESSION['session_ocultar_MSG_DINAMICO'];


    $QUERY_1= "DELETE from tabela_linha1 WHERE tabela_linha1.id_prova='$ID' ";
    $QUERY_2= "DELETE from tabela_linha2 WHERE tabela_linha2.id_prova='$ID' ";
    $QUERY_3= "DELETE from tabela_linha3 WHERE tabela_linha3.id_prova='$ID' ";
    $QUERY_4= "DELETE from tabela_linha4 WHERE tabela_linha4.id_prova='$ID' ";

    $QUERY_prova= "DELETE from tabela_prova WHERE tabela_prova.id_prova='$ID' ";

    $QUERY_gabarito= "DELETE from tabela_gabarito WHERE tabela_gabarito.id_prova='$ID' ";

    $QUERY_rascunho= "DELETE from tabela_rascunho WHERE tabela_rascunho.id_prova='$ID' ";




                            if (mysqli_query($conn, $QUERY_gabarito))
                        {
                              /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                              $_SESSION['msg'] = "Atividade excluida com Sucesso.";
                              $_SESSION['alert'] = "alert alert-danger";
                              mysqli_query($conn, $QUERY_rascunho);
                               mysqli_query($conn, $QUERY_prova);

                               mysqli_query($conn, $QUERY_2);
                               mysqli_query($conn, $QUERY_1);
                               mysqli_query($conn, $QUERY_3);
                               mysqli_query($conn, $QUERY_4);
                              
                        } else {
                              echo "Error: " . $QUERY_gabarito . "<br>" . mysqli_error($conn);
                             
                        }

                       
}
/*===========================================================================================================================================*/



/*===========================================================================================================================================*/

                            /*  Código permite Visualizar as atividades em outra Página */
/*===========================================================================================================================================*/


if (isset($_POST['ver']))
 {

  $ID= $_POST['ver'];
  $_SESSION['ID_PROVA_DINAMICA']=$_POST['ver'];

  $ocultar_div='style="display:none;"';
  $_SESSION['session_ocultar_MSG_DINAMICO']=$ocultar;


    $sql_buscar_dados_prova="SELECT * FROM tabela_prova
               WHERE id_prova =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova = $var_mysqli-> query($sql_buscar_dados_prova);
                
              }

              while ($dado_info_prova = $con_info_prova-> fetch_array())
              {
                $_SESSION['session_info_prova_assunto_Dinamico']= $dado_info_prova['assunto_exercicio'];
                $_SESSION['session_info_prova_objetivo_Dinamico']=$dado_info_prova['objetivo']; 
                $_SESSION['session_info_prova_titulo_Dinamico']=$dado_info_prova['titulo_exercicio']; 
              }

$sql_buscar_dados_prova_PROFESSOR ="SELECT * FROM tabela_prova
               WHERE id_prova = ' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova_PROFESSOR))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_PROFESSOR = $var_mysqli-> query($sql_buscar_dados_prova_PROFESSOR);
                
              }

              while ($dado_info_prova_PROFESSOR = $con_info_prova_PROFESSOR-> fetch_array())
              {
                $_SESSION['session_info_prova_ID_professor_Dinamico']= $dado_info_prova_PROFESSOR['id_professor'];
                $_SESSION['session_info_prova_ID_Disciplina_Dinamico']=$dado_info_prova_PROFESSOR['id_disciplina']; 
                $_SESSION['session_info_prova_ID_instituto_Dinamico']=$dado_info_prova_PROFESSOR['id_instituto']; 
              }

              header("location: ExibirResultadoAtividadeDinamica.php");

/*Buscar gabarito da atividade */
$sql_buscar_Gabarito="SELECT * FROM tabela_gabarito
               WHERE id_prova =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_Gabarito))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_GABARITO = $var_mysqli-> query($sql_buscar_Gabarito);
                
              }

              while ($dado_info_prova_GABARITO = $con_info_prova_GABARITO-> fetch_array())
              {
                $_SESSION['session_info_prova_GABARITO_Dinamico']= $dado_info_prova_GABARITO['resposta'];
                
              }



 }

/*===========================================================================================================================================*/



/*===========================================================================================================================================*/

                            /*  PREENCHE O PRIMEIRO COMBO LIST COM OS NOMES DOS INSTITUTOS DO PROFESSOR */
/*===========================================================================================================================================*/


 $sql_busca_IE="SELECT distinct (ti.nome_instituto) as nome_IE, ti.id_instituto as id_ie FROM tabela_prof_instituto as tpi, tabela_professor as tp,tabela_instituto as ti where tpi.id_professor = tp.id_professor and tpi.id_instituto = ti.id_instituto and tp.id_professor =' $var_ID_PROF ' ";

         if (!$mysqli -> query( $sql_busca_IE))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_IE = $mysqli-> query($sql_busca_IE);
           
            
          }

/*===========================================================================================================================================*/

    if (isset($_POST['btn-prox']))
     {

        $ocultar_div='style="display:none;"';
        $_SESSION['session_ocultar_MSG_DINAMICO']=$ocultar;


        $var_ID_IE=$_POST['combobox_IE'];
        
        $_SESSION['session_ID_IE']=$_POST['combobox_IE'];
    }

    

/*===========================================================================================================================================*/

                            /*  PREENCHE O SEGUNDO COMBO LIST COM OS NOMES DAS DISCIPLINAS */

/*===========================================================================================================================================*/


$sql_busca_DIS="SELECT td.nome_disciplina as nome_dis, td.id_disciplina as id_dis FROM tabela_prof_disciplina as tpd, tabela_professor as tp,tabela_disciplina as td 
WHERE tp.id_professor =' $var_ID_PROF ' and td.id_instituto='$var_ID_IE' and tpd.id_professor = tp.id_professor and tpd.id_disciplina = td.id_disciplina ;";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                  
          }else
          {
            $sql_resultado_DIS = $mysqli-> query($sql_busca_DIS);

          }
 /*===========================================================================================================================================*/           
    if (isset($_POST['btn-pesquisar']))
     {
       
             $ocultar='';

            
            $_SESSION['session_ID_DIS']=$_POST['combobox_DIS'];

              $Numero_DIS=$_SESSION['session_ID_DIS'];
             $Numero_IE=$_SESSION['session_ID_IE'];
           
     } 

/*========================================================================================================================================*/

if (isset($_POST['btn-sair'])) 
{
  
   $ocultar_div='style="display:none;"';
  $_SESSION['session_ocultar_MSG_DINAMICO']=$ocultar;


              header("location: MenuPrincipalNovo.php");
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">

    <title>Hello, world!</title>
  </head>
  <body>
    <form action="" method="POST">
    <div class="container-filtragem">
                <fieldset> <legend>Filtrar Pesquisa: </legend>
               
                  <div class="container-conteudo">
          <label>Instituto de Ensino: </label>
                        <select class="combo-estilo"  name="combobox_IE">
           <option ><?php echo $msg; ?></option> 
            <?php while ($dado_IE = $sql_resultado_IE-> fetch_array()){ ?>


           
           <option  value="<?php echo $dado_IE['id_ie'] ?>" ><?php echo $dado_IE['nome_IE'] ?></option>
           


           <?php }   ?>
           
           </select> <button class="botao-editar2" name="btn-prox"> <i class="fas fa-forward"></i></button>
           <label>Disciplina: </label>
                        <select  class="combo-estilo"    name="combobox_DIS"  >
           <option  >Selecione...</option> 
            <?php while ($dado_DIS = $sql_resultado_DIS-> fetch_array()){ ?>


           
           <option  value="<?php echo $dado_DIS['id_dis'] ?>" ><?php echo $dado_DIS['nome_dis'] ?></option>
           


           <?php }   ?>
           
           </select> <button class="botao-editar2" name="btn-pesquisar"><i  id="oo" class="fas fa-search"></i> </button>
           <button class="botao-editar2" name="btn-sair"><i class="fas fa-sign-out-alt"></i> Sair</button>
           </div>
          </fieldset>
    </div>
</form>
    <?php require_once("ListaAtividadeDinamica.php"); ?>

    <div class="container">
      
      
      <table class="table" <?php echo $ocultar; ?> >
        <thead>
          <tr class="teste">
            <th>Serial</th>
            <th>Título</th>
            <th>Assunto</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <form action="ListaAtividadeDinamica.php" method="POST">
          <?php 
          #Codigo para Listar os Dados
          $sQuery ="SELECT tae.id_prova as ID,tae.titulo_exercicio as titulo,tae.assunto_exercicio as assunto FROM tabela_prova as tae 
          WHERE
            tae.id_professor=' $var_ID_PROF ' AND tae.id_instituto=' $Numero_IE ' AND tae.id_disciplina=' $Numero_DIS ' limit 100";

           $result =$conn->query($sQuery);

           # Código Botão Editar

           while ($row = $result->fetch_assoc()): ?>
            <tr class="teste2">
              <td><?= $row['ID']; ?></td>
               <td><?= $row['titulo']; ?></td>
               <td><?= $row['assunto']; ?></td>
               <td style="width: 15%">
                 <button class="botao-editar" type="submit" name="deletar" value="<?= $row['ID']; ?>"><i class="fas fa-trash-alt"></i></button>

                 

                  <button class="botao-editar" type="submit" name="ver" value="<?= $row['ID']; ?>"><i class="fas fa-eye"></i></button>
                 
               </td>

            </tr>

          <?php endwhile; ?>
          </form>
          
        </tbody>
        
      </table>


    </div>
   
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

<?php $ocult=$_SESSION['session_ocultar_MSG_DINAMICO']; ?>

    <div class="div-excluir" <?php echo $ocult; ?>>
      <label class="label-excluir">Atividade excluida com Sucesso!</label>
    </div>


    

  </body>
</html>

<style type="text/css">

  body
  {
    background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);
  }

  .div-excluir
{
  position: relative;
  top: -10px;
  left: 100px;

  background: #ffcbdb;
  height: 70px;
  width: 1300px;
  color: red;
  font-size: 1.2em;

  border-style: solid 5px;

    border-radius: 12px;
    padding: 20px;
    text-align: center;

}

.table
{
  position: relative;
  top: 75px;
}


  .combo-estilo
{
  
  font-size: 1.4em;
  width: 250px;
  border: none;
  
  vertical-align: middle;
    font-family: 'Permanent Marker', cursive;
    font-size: 1.6em;
    color: black;
    text-align: center;
    background: none;
    cursor: pointer;
}


fieldset
{
 border:2px solid white;
    -moz-border-radius:8px;
    -webkit-border-radius:8px;  
    border-radius:8px;  
   background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);
   color: white;
}

.container-conteudo
{
  color: white;
  position: relative;
  font-size: 1.3em;
  text-align: center;
  vertical-align: center;
}

.container-filtragem
{
  width: 1010px;
  padding: 10px;
  position: relative;
  left: 150px;

}

.teste
{
  border:2px solid black ;
   border-radius:8px; 
   background: black;
   color:white;

}

.teste2
{
   border:2px solid black ;
   border-radius:8px; 
   background: white;
   color:black;
}

.botao-editar
{
  border: none;
  color: black;
  background: white;
  font-size: 2em;
  margin: 2px;

}

.botao-editar2
{
  border: none;
  color: white;
  
  font-size: 1em;
  margin: 2px;
  background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);

}


</style>