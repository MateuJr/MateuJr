<?php
session_start();
$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

$var_add_nome_email='';
$mysqli = new mysqli($host,$usuario,$senha,$bd);
 $consulta_id_professor = "SELECT max(id_professor) as ID  FROM tabela_professor";
      if (!$mysqli -> query( $consulta_id_professor))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_id_professor = $mysqli-> query($consulta_id_professor);
      
    }
$consulta_id_disciplina = "SELECT max(id_disciplina) as ID_disciplina  FROM tabela_disciplina";
if (!$mysqli -> query( $consulta_id_disciplina))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_id_disciplina = $mysqli-> query($consulta_id_disciplina);
      
    }





$consulta_id_instituicao = "SELECT max(id_instituto) as ID_instituto  FROM tabela_instituto";
      if (!$mysqli -> query( $consulta_id_instituicao))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_id_instituicao = $mysqli-> query($consulta_id_instituicao);
      
    }





$variavel_nome_professor='';

$variavel_nome_professor=$_SESSION['campo_nome_professor_session'];

$acao='';
$busca_instituto='';

       if (isset($_POST['campo-instituto']))
        {
      

            if ( $_SESSION['campo_nome_instituto_session'] != '' )
             {
               $busca_instituto=$_SESSION['campo_nome_instituto_session'];
            }else
            {
              $busca_instituto=$_POST['campo-instituto'];
            }

       }

$consulta_instituto = "SELECT nome_instituto,id_instituto, max(id_instituto) as ID_MAX_Instituto FROM tabela_instituto where nome_instituto = ' $busca_instituto ' ";
      if (!$mysqli -> query( $consulta_instituto))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_instituto = $mysqli-> query($consulta_instituto);
      
    }
if (isset($_POST['btn-add-FIM']))
   {

        while ($dado_instituto = $con_instituto-> fetch_array())

        {
          $vet_instituto=$dado_instituto['nome_instituto'];
         
          if ($vet_instituto!='')
           {
           /* echo "<br> Instituto já Existe !!";*/
            $variavel_id_instituto='';
          

            $variavel_id_instituto = $dado_instituto['id_instituto'];
            $variavel_nome_instituto=$_POST['campo-instituto'];

            $_SESSION['session_ID_instituto_IE']=$dado_instituto['id_instituto'];         



      $variavel_id_professor='';           
                $variavel_id_professor = $_SESSION['campo_id_professor_session'];
                $id_atualizado_professor='';
                $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];

                     $sql_professor_instituto = "INSERT INTO tabela_prof_instituto (id_professor,id_instituto)
                     VALUES (' $id_atualizado_professor', ' $variavel_id_instituto')";


                        if (mysqli_query($mysqli, $sql_professor_instituto))
                    {
                         /* echo "<br>Dado na Tabela INSTITUTO ADD!!";*/

                    } else {
                          echo "Error: " . $sql_professor_instituto . "<br>" . mysqli_error($mysqli);
                    }




          }else{
/*==================================================================================================*/

/*                                 NÃO EXISTE BOTAO FIM                */

/*==================================================================================================*/
            /*echo "<br> Instituto NÃO Existe !!";*/



                    $id_instituto_novo='';
                     while ($dado_instituicao_id = $con_id_instituicao-> fetch_array())

          {
              $id_instituto_novo = $dado_instituicao_id['ID_instituto'] +1;
              $_SESSION['session_ID_instituto_IE']=$id_instituto_novo;
              $az='';
              $az=$_SESSION['session_ID_instituto_IE'];
              
        }
          

            

             if ($_SESSION['campo_nome_instituto_session'] != '')
             {
               $variavel_nome_instituto=$_SESSION['campo_nome_instituto_session'];
            }else
            {
              $variavel_nome_instituto=$_POST['campo-instituto'];
            }


             $_SESSION['session_ID_instituto_IE']=$id_instituto_novo;

            $sql = "INSERT INTO tabela_instituto (nome_instituto,id_instituto)
                     VALUES (' $variavel_nome_instituto',' $id_instituto_novo')";


                        if (mysqli_query($mysqli, $sql))
                    {
                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                    } else {
                          echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
                    }


            $variavel_id_instituto='';
            $variavel_id_professor='';

            $variavel_id_instituto = $dado_instituto['ID_MAX_Instituto'];
            $variavel_id_professor = $_SESSION['campo_id_professor_session'];

        $id_atualizado_professor='';
                $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];

            $sql_professor_instituto = "INSERT INTO tabela_prof_instituto (id_professor,id_instituto)
                     VALUES (' $id_atualizado_professor', ' $id_instituto_novo')";


                        if (mysqli_query($mysqli, $sql_professor_instituto))
                    {
                         /* echo "<br>Dado na Tabela PROFESSOR__X__INSTITUTO ADD!!";*/
                    } else {
                          echo "Error: " . $sql_professor_instituto . "<br>" . mysqli_error($mysqli);
                    }


          }
          $_SESSION['campo_nome_instituto_session']='';
/*==================================================================================================*/

/*                              DISCIPLINA botao FIM                           */

/*==================================================================================================*/
 
        }

$busca_disciplina='';
$id_IE_variavel='';
       if (isset($_POST['campo-disciplina']))
        {
        $busca_disciplina=$_POST['campo-disciplina'];
       }

        $id_IE_variavel=$_SESSION['session_ID_instituto_IE'];

$consulta_disciplina = "SELECT nome_disciplina,id_disciplina, max(id_disciplina) as ID_MAX_Disciplina FROM tabela_disciplina where nome_disciplina = ' $busca_disciplina ' and id_instituto= ' $id_IE_variavel ' ";
      if (!$mysqli -> query( $consulta_disciplina))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_disciplina = $mysqli-> query($consulta_disciplina);
      
    }


$_SESSION['campo_nome_disciplina_session']=$_POST['campo-disciplina'];

       
  while ($dado_disciplina = $con_disciplina-> fetch_array())

        {
           $vet_disciplina=$dado_disciplina['nome_disciplina'];
           
            if ($vet_disciplina!='')
             {

             /* echo "<br> Disciplina $vet_disciplina Já existe";*/

              
              $teste=$_SESSION['campo_id_professor_session'];
                    $variavel_id_disciplina = $dado_disciplina['id_disciplina'];

                    $id_atualizado_professor='';
                $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];


                     $sql_professor_disciplina = "INSERT INTO tabela_prof_disciplina (id_professor,id_disciplina)
                     VALUES (' $id_atualizado_professor', ' $variavel_id_disciplina')";


                        if (mysqli_query($mysqli, $sql_professor_disciplina))
                    {
                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                    } else {
                          echo "Error: " . $sql_professor_disciplina . "<br>" . mysqli_error($mysqli);
                    }


             }else
             {

              /*echo "NAO EXISTEEEEEEEEE";*/




        
                     while ($dado_disciplina_id = $con_id_disciplina-> fetch_array())

          {
              $teste_id_disciplina = $dado_disciplina_id['ID_disciplina'] +1;
        }
                   $var_IE_disciplina='';
                   $var_IE_disciplina=$_SESSION['session_ID_instituto_IE'];

                   
                    
            $variavel_nome_disciplina=$_POST['campo-disciplina'];

            $sql_nova_disciplina = "INSERT INTO tabela_disciplina(nome_disciplina,id_disciplina,id_instituto)
                     VALUES (' $variavel_nome_disciplina',' $teste_id_disciplina',' $var_IE_disciplina')";


                        if (mysqli_query($mysqli, $sql_nova_disciplina))
                    {
                         /* echo "<br>Dado na Tabela Disciplina ADD!!";*/
                    } else {
                          echo "Error: " . $sql_nova_disciplina . "<br>" . mysqli_error($mysqli);
                    }

                    $teste=$_SESSION['campo_id_professor_session'];

                     $id_atualizado_professor='';
                $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];


                    $sql_professor_disciplina = "INSERT INTO tabela_prof_disciplina (id_professor,id_disciplina)
                     VALUES (' $id_atualizado_professor', ' $teste_id_disciplina')";


                        if (mysqli_query($mysqli, $sql_professor_disciplina))
                    {
                          /*echo "<br>Dado na Tabela PROFESSOR__X__DISCIPLINA ADD!!";*/
                    } else {
                          echo "Error: " . $sql_professor_disciplina . "<br>" . mysqli_error($mysqli);
                    }


             }
        }

$uo="";
$uo=$_SESSION['session_ID_instituto_IE'];

    }


$variavel_sessao_nome_professor='';
$variavel_sessao_nome_professor=$_SESSION['campo_nome_professor_session'];

$variavel_sessao_nome_disciplina='';
$variavel_sessao_nome_instituto='';
$variavel_sessao_nome_instituto= $_SESSION['campo_nome_instituto_session'];

        if (isset($_POST['btn-add-DIS']))

     {
      
      

      $_SESSION['campo_nome_professor_session']= $_POST['campo-nome'];
      $variavel_sessao_nome_professor=$_SESSION['campo_nome_professor_session'];

$_SESSION['campo_nome_instituto_session']= $_POST['campo-instituto'];

     if ( strlen ($_SESSION['campo_nome_instituto_session']) < strlen ( $_SESSION['SESSION_aux_IE'] ) )
      {
       
       $_SESSION['campo_nome_instituto_session']=$_SESSION['SESSION_aux_IE'];
     }

     $variavel_sessao_nome_instituto= $_SESSION['campo_nome_instituto_session'];
      
      
      $teste_var=$_SESSION['campo_nome_instituto_session'];

$_SESSION['SESSION_aux_IE']= $teste_var;



    }
    
/*==================================================================================================*/

/*                              DISCIPLINA botao SARLVAR NOME/E-MAIL                           */

/*==================================================================================================*/

 $var_desbloquear_2_janela=$_SESSION['Permissao_painel_2'];
 $variavel_sessao_email_professor='';
 $variavel_sessao_email_professor=$_SESSION['campo_email_professor_session'];
  if (isset($_POST['btn-add-salvar-1']))
   {
    

      $_SESSION['campo_nome_professor_session']= $_POST['campo-nome'];
      $variavel_sessao_nome_professor=$_SESSION['campo_nome_professor_session'];

      
      $_SESSION['campo_email_professor_session']=$_POST['campo-email'];
      $variavel_sessao_email_professor=$_SESSION['campo_email_professor_session'];

if (empty($_SESSION['campo_nome_professor_session']) or empty($_SESSION['campo_email_professor_session']))
 {
  $_SESSION['MSG_nome_email_session']='Os campos com (*) São obrigatórios!';
}else
{


$SQL_buscar_EMAIL= "SELECT * FROM tabela_professor WHERE email = ' $variavel_sessao_email_professor '  ";

      if (!$mysqli -> query( $SQL_buscar_EMAIL))
       {
            echo("Error description: " . $mysqli -> error);
      }else
      {
        $con_EMAIL = $mysqli-> query($SQL_buscar_EMAIL);
        
      }

      $variavel_email='';

      while ($dado_EMAIL = $con_EMAIL-> fetch_array())
      {
        $variavel_email = $dado_EMAIL['email'] ;
        
      }

    if ( empty($variavel_email)    )
     {
     
   

                    $teste='';
                     while ($dado_professor_id = $con_id_professor-> fetch_array())

                      {
                          $teste = $dado_professor_id['ID'] +1;
                          $_SESSION['campo_id_professor_session_atualizado']=$teste;
                    }

                    $_SESSION['campo_nome_professor_session'] = $_POST['campo-nome'];
                    $variavel_nome_professor=$_SESSION['campo_nome_professor_session'];

                    $sql_professor = "INSERT INTO tabela_professor (nome_professor,id_professor,email)
                     VALUES (' $variavel_nome_professor', ' $teste',' $variavel_sessao_email_professor')";


                        if (mysqli_query($mysqli, $sql_professor))
                    {
                        
                         $_SESSION['MSG_nome_email_session']='Dados Inseridos Com Sucesso!';
                         $var_add_nome_email=$_SESSION['MSG_nome_email_session'];
                    } else {
                          echo "Error: " . $sql_professor . "<br>" . mysqli_error($mysqli);
             
                             }


                    $var_desbloquear_2_janela='';
                    $_SESSION['Permissao_painel_2']=$var_desbloquear_2_janela;
                    header('Location: TelaCadastroProfessor.php');


                      $uo="";
                      $uo=$_SESSION['session_ID_instituto_IE'];

          }else
          {
            $_SESSION['MSG_nome_email_session']='O E-MAIL informado  Já consta no sistema!';
            
          }


    }

  }


/*============================================================================================*/

    
/*==================================================================================================*/

/*                              DISCIPLINA botao DIS                          */

/*==================================================================================================*/




$variavel_sessao_nome_disciplina='';
$variavel_sessao_nome_instituto='';
$variavel_sessao_nome_instituto= $_SESSION['campo_nome_instituto_session'];



       $busca='';

       if (isset($_POST['campo-instituto']))
        {
        $busca=$_SESSION['campo_nome_instituto_session'];
       }



$consulta_instituto_atualizado = "SELECT nome_instituto,id_instituto, max(id_instituto) as ID_MAX_Instituto FROM tabela_instituto where nome_instituto = ' $busca ' ";
      if (!$mysqli -> query( $consulta_instituto_atualizado))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_instituto_atualizado = $mysqli-> query($consulta_instituto_atualizado);
      
    }

 

        if (isset($_POST['btn-add-DIS']))

     {
$_SESSION['campo_nome_instituto_session']= $_POST['campo-instituto'];
     if ( strlen ($_SESSION['campo_nome_instituto_session']) < strlen ( $_SESSION['SESSION_aux_IE'] ) )
      {
        
       $_SESSION['campo_nome_instituto_session']=$_SESSION['SESSION_aux_IE'];
     }
      $variavel_sessao_nome_instituto= $_SESSION['campo_nome_instituto_session'];
      
      $teste_var=$_SESSION['campo_nome_instituto_session'];

$_SESSION['SESSION_aux_IE']= $teste_var;

      
/*====================================================================================================*/

$busca_instituto_atualizado=$_SESSION['campo_nome_instituto_session'];

/*----------------------------------------------------------------------------------------------------*/

$busca_instituto_ensino='';
$vet_IE='';
    if ($_SESSION['campo_nome_instituto_session'] !='')
     {
      $busca_instituto_ensino=$_SESSION['campo_nome_instituto_session'];
     
    }

$consulta_instituto_ensino = "SELECT nome_instituto,id_instituto FROM tabela_instituto 
where nome_instituto = ' $busca_instituto_ensino ' ";

      if (!$mysqli -> query( $consulta_instituto_ensino))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_instituto_ensino = $mysqli-> query($consulta_instituto_ensino);


    }
    while ($dado_IE = $con_instituto_ensino-> fetch_array())

        {
          $vet_IE=$dado_IE['nome_instituto'];
          $_SESSION['session_ID_instituto_IE']=$dado_IE['id_instituto'];
         
            
        }

 
/*---------------------------------------------------------------------------------------------------*/


  while ($dado_instituto = $con_instituto_atualizado-> fetch_array())

        {
                    $vet_instituto=$dado_instituto['nome_instituto'];
                   
               if ($vet_instituto!='')
              {
                   
                    $variavel_id_instituto='';
                  

                    $variavel_id_instituto = $dado_instituto['id_instituto'];
                    $variavel_nome_instituto=$_SESSION['campo_nome_instituto_session'];
                    
                    
                    $_SESSION['session_ID_instituto_IE']=$dado_instituto['id_instituto'];


                    $variavel_id_professor='';           
                    $variavel_id_professor = $_SESSION['campo_id_professor_session'];
                    $id_atualizado_professor='';
                    $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];



                }else
                {
                      



                    $id_instituto_novo='';
                     while ($dado_instituicao_id = $con_id_instituicao-> fetch_array())

                    {
                       $id_instituto_novo = $dado_instituicao_id['ID_instituto'] +1;
                       $_SESSION['session_ID_instituto_IE']=$dado_instituicao_id['ID_instituto'] +1;
                    }
          
                    
                     /*$variavel_nome_instituto=$_POST['campo-instituto'];*/

                    $variavel_nome_instituto= $_SESSION['campo_nome_instituto_session'];

                     $sql = "INSERT INTO tabela_instituto (nome_instituto,id_instituto)
                     VALUES (' $variavel_nome_instituto',' $id_instituto_novo')";


                          if (mysqli_query($mysqli, $sql))
                        {
                          /*echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                        } else {
                          echo "Error: " . $sql . "<br>" . mysqli_error($mysqli);
                        }


                      $variavel_id_instituto='';
                      $variavel_id_professor='';

                      $variavel_id_instituto = $dado_instituto['ID_MAX_Instituto'];
                      $variavel_id_professor = $_SESSION['campo_id_professor_session'];

                      $id_atualizado_professor='';
                      $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];


                }

        }

/*================================================================================================ */

        $busca_disciplina='';
       if (isset($_POST['campo-disciplina']))
        {
        $busca_disciplina=$_POST['campo-disciplina'];
       }

       $id_IE_variavel=$_SESSION['session_ID_instituto_IE'];
$consulta_disciplina = "SELECT nome_disciplina,id_disciplina, max(id_disciplina) as ID_MAX_Disciplina FROM tabela_disciplina where nome_disciplina = ' $busca_disciplina ' and id_instituto= ' $id_IE_variavel ' ";
      if (!$mysqli -> query( $consulta_disciplina))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_disciplina = $mysqli-> query($consulta_disciplina);
      
    }


$_SESSION['campo_nome_disciplina_session']=$_POST['campo-disciplina'];

       
  while ($dado_disciplina = $con_disciplina-> fetch_array())

        {
           $vet_disciplina=$dado_disciplina['nome_disciplina'];
           
            if ($vet_disciplina!='')
             {

             /* echo "<br> Disciplina $vet_disciplina Já existe";*/

              
              $teste=$_SESSION['campo_id_professor_session'];
                    $variavel_id_disciplina = $dado_disciplina['id_disciplina'];

                    $id_atualizado_professor='';
                $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];


                     $sql_professor_disciplina = "INSERT INTO tabela_prof_disciplina (id_professor,id_disciplina)
                     VALUES (' $id_atualizado_professor', ' $variavel_id_disciplina')";


                        if (mysqli_query($mysqli, $sql_professor_disciplina))
                    {
                         /* echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                    } else {
                          echo "Error: " . $sql_professor_disciplina . "<br>" . mysqli_error($mysqli);
                    }


             }else
             {

                  /*echo "NAO EXISTEEEEEEEEE";*/




        
                     while ($dado_disciplina_id = $con_id_disciplina-> fetch_array())

               {
                $teste_id_disciplina = $dado_disciplina_id['ID_disciplina'] +1;

              }
                   $ID_var_IE='';
                   $ID_var_IE=$_SESSION['session_ID_instituto_IE'];
                    
                $variavel_nome_disciplina=$_POST['campo-disciplina'];

                $sql_nova_disciplina = "INSERT INTO tabela_disciplina(nome_disciplina,id_disciplina,id_instituto)
                     VALUES (' $variavel_nome_disciplina',' $teste_id_disciplina',' $ID_var_IE')";


                        if (mysqli_query($mysqli, $sql_nova_disciplina))
                    {
                          /*echo "<br>Dado na Tabela Disciplina ADD!!";*/
                    } else {
                          echo "Error: " . $sql_nova_disciplina . "<br>" . mysqli_error($mysqli);
                    }

                    $teste=$_SESSION['campo_id_professor_session'];

                     $id_atualizado_professor='';
                  $id_atualizado_professor=$_SESSION['campo_id_professor_session_atualizado'];


                    $sql_professor_disciplina = "INSERT INTO tabela_prof_disciplina (id_professor,id_disciplina)
                     VALUES (' $id_atualizado_professor', ' $teste_id_disciplina')";


                        if (mysqli_query($mysqli, $sql_professor_disciplina))
                    {
                          /*echo "<br>Dado na Tabela PROFESSOR__X__DISCIPLINA ADD!!";*/
                    } else {
                          echo "Error: " . $sql_professor_disciplina . "<br>" . mysqli_error($mysqli);
                    }


            }
        }


    }
    
/*==============================================================================================*/

/*              Salvar USUARIO                          */

/*===============================================================================================*/



  if (isset($_POST['btn-teste-1'])) 
  {
    $var_teste_user='';
    

    $var_teste_user=$_POST['teste-usuario'];
    

    $consulta_user_1 = "SELECT usuario FROM tabela_usuario 
              where usuario = ' $var_teste_user ' ";

      if (!$mysqli -> query( $consulta_user_1))
       {
            echo("Error description: " . $mysqli -> error);
    }else
    {
      $con_user_1 = $mysqli-> query($consulta_user_1);


    }
    $vet_user='';
    while ($dado_user = $con_user_1-> fetch_array())

        {
          $vet_user=$dado_user['usuario'];
            
        }

            if ($vet_user =='')
           {
          
       
            /*echo "<br> Este Usuário não existe";*/


            $vet_user_tipo='PROFESSOR';
            $_SESSION['nome_usuario_session']=$var_teste_user;

          $sql_user = "INSERT INTO tabela_usuario (usuario,tipo)
                     VALUES (' $var_teste_user',' $vet_user_tipo')";


                        if (mysqli_query($mysqli, $sql_user))
                    {
                         /* echo "<br>Dado na Tabela INSTITUTO ADD!!";*/
                    } else {
                          echo "Error: " . $sql_user . "<br>" . mysqli_error($mysqli);
                    }

                     /* =================================================================*/
                       /*             UPDTE             */

                       $_SESSION['palavra_chave_session']=$_POST['campo-palavra-chave'];
                       $pesquisa_ID_professor =$_SESSION['campo_id_professor_session_atualizado'];
                       $palavra =$_POST['campo-palavra-chave'];
                       


                       $sql_professor_update = "UPDATE tabela_professor SET
                        palavra_chave='$palavra'
                        WHERE id_professor=$pesquisa_ID_professor";


                          
                            if (mysqli_query($mysqli, $sql_professor_update))
                        {
                              /*echo "<br>Dado na Tabela Professor ATUALIZADO!!";*/
                              $_SESSION['MSG_Usuario_session']='Dados inseridos com Sucesso!';

                        } else {
                              echo "Error: " . $sql_professor_update . "<br>" . mysqli_error($mysqli);
                        }

               }else
               {
                  /*echo "<br> Este Usuário JÁ existe";*/
                  $_SESSION['MSG_Usuario_session']='Este Usuário já existe';
               }


  }

/*==================================================================================================


                GRAVAR SENHA 

===================================================================================================
*/
    if (isset($_POST['bt-salvar-senha']))
     {
      $s1='';
      $s2='';
      $s1=$_POST['campo-senha'];
      $s2=$_POST['campo-confirmar'];


          $var_teste_user='';
          

          $var_teste_user=$_SESSION['nome_usuario_session'];
          

          $consulta_user_1 = "SELECT usuario,id_usuario FROM tabela_usuario 
                    where usuario = ' $var_teste_user ' ";

            if (!$mysqli -> query( $consulta_user_1))
             {
                  echo("Error description: " . $mysqli -> error);
          }else
          {
            $con_user_1 = $mysqli-> query($consulta_user_1);


          }
          $vet_user='';
          while ($dado_user = $con_user_1-> fetch_array())

              {
                $vet_user=$dado_user['id_usuario'];
                  
              }


      if ( ($s1 == $s2) and ($s1 !='') and ($s2 !='') )
       {
        /*echo "<br> Senhas Válidas!!"; */
        $var_senha =mysqli_escape_string($mysqli,$s1);
                $var_senh=md5($var_senha);

                $var_nome_user=$_SESSION['nome_usuario_session'];

                $sql_user_update = "UPDATE tabela_usuario SET
                        senha='$var_senh'
                        WHERE id_usuario=$vet_user";


                          
             if (mysqli_query($mysqli, $sql_user_update))
               {
                   /*echo "<br>Dado na Tabela Usuario ATUALIZADO!!";*/
                   $_SESSION['MSG_Senha_session']='Dados inseridos com sucesso!';

                } else {
                        echo "Error: " . $sql_user_update . "<br>" . mysqli_error($mysqli);
                    }

                    $var_id_prof='';
                    $var_id_prof=$_SESSION['campo_id_professor_session_atualizado'];


                $sql_prof_update = "UPDATE tabela_professor SET
                        id_usuario='$vet_user'
                        WHERE id_professor=$var_id_prof";


                          
             if (mysqli_query($mysqli, $sql_prof_update))
               {
                   /*echo "<br>Dado na Tabela Usuario ATUALIZADO!!";*/
                   header('Location: TelaLogin.php');
                   
                } else {
                        echo "Error: " . $sql_prof_update . "<br>" . mysqli_error($mysqli);
                    }


      }else

      {
        /*echo "<br> Senhas DIFERENTES!!";*/
        $_SESSION['MSG_Senha_session']='Senha são diferentes!';
       
        
      }

              $_SESSION['campo_nome_professor_session']='';
        $_SESSION['campo_email_professor_session']='';
        $_SESSION['campo_id_professor_session']='';

        $_SESSION['campo_id_professor_session_atualizado']='';


        $_SESSION['campo_id_disciplina_session']='';
        $_SESSION['campo_nome_disciplina_session']='';

        $_SESSION['campo_id_instituto_session']='';
        $_SESSION['campo_nome_instituto_session']='';

        $_SESSION['Permissao_painel_2']='disabled=""';

        $_SESSION['nome_usuario_session']='';

        $_SESSION['palavra_chave_session']='';

        $_SESSION['MSG_nome_email_session']='';

        $_SESSION['MSG_Usuario_session']='';

        /*$_SESSION['MSG_Senha_session']='';*/

        $_SESSION['MSG_IE_DIS_session']='';

        $_SESSION['session_ID_instituto_IE']='';


    }

$variavel_sessao_nome_user='';

$variavel_sessao_nome_user= $_SESSION['nome_usuario_session'];

$variavel_sessao_palavra_chave ='';

$variavel_sessao_palavra_chave=$_SESSION['palavra_chave_session'];




?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
<form action="" method="POST">
  <?php while ($dado_id_professor = $con_id_professor-> fetch_array()){ ?>
    
  <div class="form-style-3">
  

    <fieldset><legend>Inserir Nome/E-Mail</legend>
      <?php $id_user = $dado_id_professor['ID'] +1; $_SESSION['campo_id_professor_session']=$id_user; ?>
    
      <label>ID Professor:</label><input type="text" disabled="" name="campo-id"
      value=<?php   echo $dado_id_professor['ID'] +1;  ?> 
      >
      <label>Nome Completo*</label><input type="text"
       
       name="campo-nome"

       value=<?php echo $variavel_sessao_nome_professor;?>

      >
      <label>E-Mail*</label><input type="text" name="campo-email" value=<?php echo $variavel_sessao_email_professor;?>>

      <button class="learn-more" name="btn-add-salvar-1"><label class="t">Salvar</label></button>
      <br>
      <label class="texto-confirmacao"><?php echo $var_add_nome_email; ?></label>
      <label><?php echo $_SESSION['MSG_nome_email_session']; ?></label>

    
    </fieldset>

  

  </div>

  <div class="form-style-3">
  

    <fieldset><legend>Cadastrar Instituição/Disciplina</legend>
    
      <label>Instituição de Ensino (IE)* : </label><input type="text" 
       name="campo-instituto" <?php echo $var_desbloquear_2_janela; ?> value=<?php echo $variavel_sessao_nome_instituto ?>
       >
      <label>Disciplina (Dis)* : </label><input type="text"
       name="campo-disciplina" 
        <?php echo $var_desbloquear_2_janela; ?>>

    <button class="learn-more" name="btn-add-DIS"><label class="t">+ Dis</label></button>
    
    <button class="learn-more" name="btn-add-FIM"><label class="t">FIM</label></button>
    <br>
    <label>Caso tenha inserido todo o (IE) e (DIS) clique em 'FIM'</label>
    </fieldset>

  

  </div>


  <div class="form-style-3">
  

    <fieldset><legend>Cadastrar Usuário/Palavra-Chave</legend>
    
      <label>Palavra-Chave*</label><input type="text" value="" name="campo-palavra-chave"
      value=<?php echo $variavel_sessao_palavra_chave; ?>>
      <label>Usuário*</label><input type="text" name="teste-usuario" 
      value=<?php echo $variavel_sessao_nome_user; ?>>
      
      <button class="learn-more" name="btn-teste-1"><label class="t">O K</label></button><label><?php echo $_SESSION['MSG_Usuario_session']; ?></label>

      

    
    </fieldset>

  

  </div>

  <div class="form-style-3">
  

    <fieldset><legend>Cadastrar Senha</legend>
    
      <label>Senha*</label><input class="css-senha" type="password" value="" name="campo-senha">
      <label>Confirmar Senha*</label><input class="css-senha" type="password" name="campo-confirmar">

    <button class="learn-more" name="bt-salvar-senha"><label class="t">Salvar</label></button>
    <label><?php echo $_SESSION['MSG_Senha_session']; ?></label>
    </fieldset>

  

  </div>

 <?php }   ?>
</form>
</body>
</html>


<style type="text/css">

body
{

}
  .texto-confirmacao
  {
    color: black;
    font-size: 0.8em;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;


  }
  .css-senha
  {
    border-radius: 3px;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border: 1px solid #FFC2DC;
  outline: none;
  color: #F072A9;
  padding: 5px 8px 5px 8px;
  box-shadow: inset 1px 1px 4px #FFD5E7;
  -moz-box-shadow: inset 1px 1px 4px #FFD5E7;
  -webkit-box-shadow: inset 1px 1px 4px #FFD5E7;
  background: #FFEFF6;
  width:100px;
  }
  label
  {
    color: #F072A9;
  }
  .id-aviso-1
  {
    color: black;
    text-align: center;
  }
.form-style-3{
  max-width: 1050px;
  font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;

}

.form-style-3 fieldset{
  border-radius: 10px;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  margin: 0px 0px 10px 0px;
  border: 1px solid #FFD2D2;
  padding: 20px;
  background: #FFF4F4;
  box-shadow: inset 0px 0px 15px #FFE5E5;
  -moz-box-shadow: inset 0px 0px 15px #FFE5E5;
  -webkit-box-shadow: inset 0px 0px 15px #FFE5E5;


}
.form-style-3 fieldset legend{
  color: #FFA0C9;
  border-top: 1px solid #FFD2D2;
  border-left: 1px solid #FFD2D2;
  border-right: 1px solid #FFD2D2;
  border-radius: 5px 5px 0px 0px;
  -webkit-border-radius: 5px 5px 0px 0px;
  -moz-border-radius: 5px 5px 0px 0px;
  background: #FFF4F4;
  padding: 0px 8px 3px 8px;
  box-shadow: -0px -1px 2px #F1F1F1;
  -moz-box-shadow:-0px -1px 2px #F1F1F1;
  -webkit-box-shadow:-0px -1px 2px #F1F1F1;
  font-weight: normal;
  font-size: 12px;

}

input[type=text] {
   border: none;
   border-bottom: 4px solid #F072A9;  
   background-color: #FFF4F4;
   margin: 5px;
}

.t
{
  text-align: center;
  color: #F072A9;
  font-size: 1em;
  position: relative;
  left: -10px;
  top: -10px;
}
button {
   position: relative;
   display: inline-block;
   cursor: pointer;
   outline: none;
   border: 0;
   vertical-align: middle;
   text-decoration: none;
   font-size: inherit;
   font-family: inherit;
   top: -10px;
   width: 80px;
   height: 50px;
}
 button.learn-more {
   font-weight: 100;
   color: #382b22;
   text-transform: uppercase;
   margin: 3px;
   display: inline;
   padding: 1.45em 1em;
   background: #fff0f0;
   border: 2px solid #b18597;
   border-radius: 0.75em;
   transform-style: preserve-3d;
   transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), background 150ms cubic-bezier(0, 0, 0.58, 1);
}
 button.learn-more::before {
   position: absolute;
   content: '';
   width: 100%;
   height: 100%;
   top: 0;
   left: 0;
   right: 0;
   bottom: 0;
   background: #f9c4d2;
   border-radius: inherit;
   box-shadow: 0 0 0 2px #b18597, 0 0.625em 0 0 #ffe3e2;
   transform: translate3d(0, 0.75em, -1em);
   transition: transform 150ms cubic-bezier(0, 0, 0.58, 1), box-shadow 150ms cubic-bezier(0, 0, 0.58, 1);
}
 button.learn-more:hover {
   background: #ffe9e9;
   transform: translate(0, 0.25em);
}
 button.learn-more:hover::before {
   box-shadow: 0 0 0 2px #b18597, 0 0.5em 0 0 #ffe3e2;
   transform: translate3d(0, 0.5em, -1em);
}
 button.learn-more:active {
   background: #ffe9e9;
   transform: translate(0em, 0.75em);
}
 button.learn-more:active::before {
   box-shadow: 0 0 0 2px #b18597, 0 0 #ffe3e2;
   transform: translate3d(0, 0, -1em);
}

</style>