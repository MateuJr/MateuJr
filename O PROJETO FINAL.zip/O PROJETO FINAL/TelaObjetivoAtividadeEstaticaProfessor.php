<?php
session_start();

$Assunto= $_SESSION['session_info_prova_assunto'];

$Objetivo= $_SESSION['session_info_prova_objetivo'];
$titulo= $_SESSION['session_info_prova_titulo'];

$ID_professor=$_SESSION['session_info_prova_ID_professor'];
$ID_disciplina = $_SESSION['session_info_prova_ID_Disciplina'];
$ID_instituto = $_SESSION['session_info_prova_ID_instituto'];

$var_gabarito=$_SESSION['session_info_prova_GABARITO'];

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

   $var_mysqli = new mysqli($host,$usuario,$senha,$bd);

   $sql_buscar_dados_professor="SELECT * FROM tabela_professor
					     WHERE id_professor =' $ID_professor ' ";

					     if (!$var_mysqli -> query( $sql_buscar_dados_professor))
					       {
					            echo("Error description: " . $var_mysqli -> error);
					    }else
					    {
					      $con_info_professor = $var_mysqli-> query($sql_buscar_dados_professor);
					      
					    }

					    while ($dado_info_professor = $con_info_professor-> fetch_array())
					    {
					    	$nome_professor= $dado_info_professor['nome_professor'];
					    	
					    }

	$sql_buscar_dados_DIS="SELECT * FROM tabela_disciplina
					     WHERE id_disciplina =' $ID_disciplina ' ";

					     if (!$var_mysqli -> query( $sql_buscar_dados_DIS))
					       {
					            echo("Error description: " . $var_mysqli -> error);
					    }else
					    {
					      $con_info_DIS = $var_mysqli-> query($sql_buscar_dados_DIS);
					      
					    }

					    while ($dado_info_DIS= $con_info_DIS-> fetch_array())
					    {
					    	$nome_DIS= $dado_info_DIS['nome_disciplina'];
					    	
					    }
					    

					    	if (isset($_POST['btn-voltar'])) {
					    		header("location: ListaAtividadeEstaticaALUNO.php");
					    	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="" method="POST">
		<div class="d-flex flex-column justify-content-center w-100 h-100">

	<div class="d-flex flex-column justify-content-center align-items-center">
		

	<div class="titulo">
		<h1>Informações da Prova</h1>
	</div>

<div class="book">
  <div class="back"></div>
  <div class="page6">
  	<h3> Conte comigo mengo</h3>
  	 <textarea style="display:none;" name="sourceCode" id="sourceCode">
<html>
<head>
<title>Hello</title>
</head>
<body>

<?php echo $var_gabarito; ?>


</body>
</html>
                        </textarea>
                        <iframe name="targetCode" id="targetCode"></iframe>
  </div>
  <div class="page5">
  	<div class="texto">

  	</div>
  </div>
  <div class="page4"></div>
  <div class="page3">
  	<p class="titulo-trabalho"> <?php echo $titulo ?> </p>
  	<p class="resumo-trabalho"><?php echo $Objetivo ?></p>

	  	
  </div>
  <div class="page2"></div>
  <div class="page1"></div>
  <div class="front">
  	<br>
  	<label class="texto-capa"> Professor: <?php echo $nome_professor ?></label>
  	<br>
  	<label class="texto-capa"> Disciplina: <?php echo $nome_DIS ?></label>

  	<br>
  	<label class="texto-capa"> Assunto: <?php echo $Assunto ?></label>



  </div>
</div>

<button class="botao-ok" name="btn-voltar"> Voltar</button>

</div>
</div>

</form>
<script type="text/javascript">
            function runCode()
            {
                var content = document.getElementById('sourceCode').value;
                var iframe = document.getElementById('targetCode');
                iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
                iframe.document.open();
                iframe.document.write(content);
                iframe.document.close();
                return false;
            }
            runCode();
        </script>
</body>
</html>


<style type="text/css">

	
@keyframes gradient {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}


	body {
  width: 100%;
  
  display: flex;
  justify-content: center;
  align-items: center;
  perspective: 1200px;
  background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
	background-size: 400% 400%;
	animation: gradient 15s ease infinite;
	height: 100vh;
  overflow: hidden;
}

.titulo
{
	position: relative;
	top: -120px;

}
h1
{
	color: white;
}

.botao-ok
{
	font-size: 1.2em;
	color: red;
	position: relative;
	top: 20px;
	left: 300px;
}

.titulo-trabalho
{
	color: gray.
	font-size:2.3em;
	vertical-align: center;
	text-align: center;
	transform: rotateY(-180deg) scale(1.1);
	padding-right: 25px;
	padding-left: 25px;
}

.resumo-trabalho
{
	color: black;
	font-size:1.1em;
	transform: rotateY(-180deg) scale(1.1);
	
	padding-right: 25px;
	padding-left: 30px;
	
}
.texto-capa
{
	color: black;
	font-size:1.3em;
	vertical-align: center;
	text-align: center;
	padding-bottom: 30px;
	margin: 30px;

}
iframe
    {
      position: relative;
      width: 100%;
      height: 100%;
      
      top: -100px;
      
      border-style: none;
      border: none;

    }

 h3
 {
 	color: white;
 	font-size: 2em;
 }
.book {  
  transform-style: preserve-3d;
  position: relative;
  height: 300px;
  cursor: pointer;
  backface-visibility: visible;
  
  left: -100px;
}

.front, .back, .page1, .page2, .page3, .page4, .page5, .page6 {
  transform-style: preserve-3d;
  position: absolute;
  width: 300px;
  height: 100%;
  top: 0; left: 0;
  transform-origin: left center;
  transition: transform .5s ease-in-out, box-shadow .35s ease-in-out;
}

.front, .back {
  background: #8B4513;
}

.front, .page1, .page3, .page5 {
  border-bottom-right-radius: .5em;
  border-top-right-radius: .5em;
}

.back, .page2, .page4, .page6 {
  border-bottom-right-radius: .5em;
  border-top-right-radius: .5em;
}

.page1 { 
  background: white;
}

.page2 {
  background: white;
}

.page3 {
  background: skyblue;
}

.page4 {
  background: white;
}

.page5 {
  background: red;
}

.page6 {
  background: white;
}

.book:hover .front {
  transform: rotateY(-160deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page1 {
  transform: rotateY(-150deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page2 {
  transform: rotateY(-30deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page3 {
  transform: rotateY(-140deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page4 {
  transform: rotateY(-40deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page5 {
  transform: rotateY(-30deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .page6 {
  transform: rotateY(-50deg) scale(1.1);
  box-shadow: 0 1em 3em 0 rgba(0, 0, 0, .2);
}

.book:hover .back {
  transform: rotateY(-20deg) scale(1.1);
}

 
 
</style>