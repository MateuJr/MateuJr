<?php 

session_start();

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

$msg='Selecione...';

/*-----------------------------------Busca IE------------------------------------------------------------*/

$var_nome_professor= $_SESSION['session_NOME_professor'];

$var_ID_professor=$_SESSION['session_ID_professor'];

$sql_busca_IE="SELECT distinct (ti.nome_instituto) as nome_IE, tp.nome_professor as nome_prof FROM tabela_prof_instituto as tpi, tabela_professor as tp,tabela_instituto as ti where tpi.id_professor = tp.id_professor and tpi.id_instituto = ti.id_instituto and tp.id_professor ='$var_ID_professor' ";

			   if (!$mysqli -> query( $sql_busca_IE))
			       {
			            echo("Error description: " . $mysqli -> error);
			           
			    }else
			    {
			      $sql_resultado_IE = $mysqli-> query($sql_busca_IE);
			     /* echo "jefferson";*/
			      
			    }

	
$sql_busca_professor=" SELECT * FROM tabela_professor where id_professor='$var_ID_professor' ";

			   if (!$mysqli -> query( $sql_busca_professor))
			       {
			            echo("Error description: " . $mysqli -> error);
			           
			    }else
			    {
			      $sql_resultado_PROF = $mysqli-> query($sql_busca_professor);
			     
			      
			    }
	/*while ($dado_prof = $sql_resultado_PROF-> fetch_array())
	{

		$var_nome_professor = $dado_prof['nome_professor'];
		
	}*/


/*--------------------------------------Buscar DIS -------------------------------------------------------*/
$var_nome_IE='';
if (isset($_POST['btn-ok']))
 {
	$var_nome_IE=$_POST['combobox_IE'];
	$_SESSION['sessao_nome_IE_aux']=$_POST['combobox_IE'];
	$msg=$var_nome_IE;
}

$sql_pesquisa_IE="SELECT * from tabela_instituto WHERE nome_instituto='$var_nome_IE'";

	if (!$mysqli -> query( $sql_pesquisa_IE))
			       {
			            echo("Error description: " . $mysqli -> error);
			            
			    }else
			    {
			      $sql_ie = $mysqli-> query($sql_pesquisa_IE);
			      
			      
			    }


	while ($dado_IE_ID = $sql_ie-> fetch_array())
	{

		 $_SESSION['session_ID_IE_aux']= $dado_IE_ID['id_instituto'];
		
		
	}
	 $var_ID_IE=$_SESSION['session_ID_IE_aux'];


$sql_busca_DIS="SELECT td.nome_disciplina as nome_dis, td.id_disciplina as id_dis FROM tabela_prof_disciplina as tpd, tabela_professor as tp,tabela_disciplina as td 
WHERE tp.nome_professor ='$var_nome_professor' and td.id_instituto='$var_ID_IE' and tpd.id_professor = tp.id_professor and tpd.id_disciplina = td.id_disciplina ;";

			   if (!$mysqli -> query( $sql_busca_DIS))
			       {
			            echo("Error description: " . $mysqli -> error);
			            
			    }else
			    {
			      $sql_resultado_DIS = $mysqli-> query($sql_busca_DIS);
			      
			      
			    }

/*---------------------------------SALVAR------------------------------------------------------------------*/



if (isset($_POST['btn-enviar']))
 {
 	 $_SESSION['session_Nome_DIS_aux']=$_POST['combobox_DIS'];
 	$var_nome_DIS= $_SESSION['session_Nome_DIS_aux'];

 		$sql_pesquisa_DIS="SELECT  td.id_disciplina as id_dis FROM tabela_disciplina as td 
			WHERE  td.id_instituto=' $var_ID_IE'  and td.nome_disciplina = '$var_nome_DIS' ";

			   if (!$mysqli -> query( $sql_pesquisa_DIS))
			       {
			            echo("Error description: " . $mysqli -> error);
			            
			    }else
			    {
			      $sql_DIS_novo = $mysqli-> query($sql_pesquisa_DIS);
			      
			      
			    }

		 while ($dado_DIS_ID = $sql_DIS_novo-> fetch_array())
	{

		$_SESSION['session_ID_DIS_aux']= $dado_DIS_ID['id_dis'];
		
		
	}

			$var_serial_disciplina= $_SESSION['session_ID_DIS_aux'];


	 		$serial_IE=$_SESSION['session_ID_IE_aux'];
		
					

	  $sql_add_atividade = "INSERT INTO tabela_atividade (tipo,id_professor,id_disciplina,id_instituto)
		                     VALUES ('ESTÁTICO',' $var_ID_professor',' $var_serial_disciplina',' $serial_IE')";


		                        if (mysqli_query($mysqli, $sql_add_atividade))
		                    {
		                          
		                          $_SESSION['sessao_nome_prof_aux']=$_SESSION['session_NOME_professor'];
		                  /*$_SESSION['sessao_nome_IE_aux']=$var_nome_IE;*/
		                  $_SESSION['sessao_nome_disciplina_aux']=$_SESSION['session_Nome_DIS_aux'];
		                  $_SESSION['sessao_serial_aux']='';

		                  header('Location: CadastroAtividadeEstatica2.php');


		                    } else {
		                          echo "Error: " . $sql_add_atividade . "<br>" . mysqli_error($mysqli);
		                         
		                    }




}


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<form action="" method="POST">
<div class="shade">
		<div class="blackboard">
				<div class="form">
						<p>
								<label>Nome Professor: <?php echo $var_nome_professor; ?> </label>
								
						</p>
						<p>
								<label>Instituto de Ensino: </label>
								<select class="combo-estilo"  name="combobox_IE">
	 <option ><?php echo $msg; ?></option> 
		<?php while ($dado_IE = $sql_resultado_IE-> fetch_array()){ ?>


	 
	 <option  value="<?php echo $dado_IE['nome_IE'] ?>" ><?php echo $dado_IE['nome_IE'] ?></option>
	 


	 <?php }   ?>
	 
	 </select><button name="btn-ok" id="btn-estilo" class="fa fa-check"></button>
						</p>
						<p>
								<label>Tipo da Atividade: Estático </label>
								
						</p>
						<p>
								<label>Disciplina: </label>
								<select  class="combo-estilo"    name="combobox_DIS"  >
	 <option  >Selecione...</option> 
		<?php while ($dado_DIS = $sql_resultado_DIS-> fetch_array()){ ?>


	 
	 <option  value="<?php echo $dado_DIS['nome_dis'] ?>" ><?php echo $dado_DIS['nome_dis'] ?></option>
	 


	 <?php }   ?>
	 
	 </select> 
						</p>
						
						<p class="wipeout">
								<input type="submit" name="btn-enviar" value="Enviar" />
						</p>
				</div>
		</div>
</div>

</form>
</body>
</html>

<style type="text/css">
	body {
		height: 100%;
		background: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/50598/concrete-wall-background.jpg) center center fixed;
		background-size: cover;
		overflow: hidden;
}

#btn-estilo
{
	cursor: pointer;
	background: red;
}
.combo-estilo
{
	
	font-size: 1.4em;
	width: 250px;
	border: none;
	
	vertical-align: middle;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.7);
		text-align: center;
		background: none;
		cursor: pointer;
}
.shade {
		overflow: auto;
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		background-image: linear-gradient( 150deg, rgba(0, 0, 0, 0.65), transparent);
}

.blackboard {
		position: relative;
		width: 640px;
		margin: 7% auto;
		border: tan solid 12px;
		border-top: #bda27e solid 12px;
		border-left: #b19876 solid 12px;
		border-bottom: #c9ad86 solid 12px;
		box-shadow: 0px 0px 6px 5px rgba(58, 18, 13, 0), 0px 0px 0px 2px #c2a782, 0px 0px 0px 4px #a58e6f, 3px 4px 8px 5px rgba(0, 0, 0, 0.5);
		background-image: radial-gradient( circle at left 30%, rgba(34, 34, 34, 0.3), rgba(34, 34, 34, 0.3) 80px, rgba(34, 34, 34, 0.5) 100px, rgba(51, 51, 51, 0.5) 160px, rgba(51, 51, 51, 0.5)), linear-gradient( 215deg, transparent, transparent 100px, #222 260px, #222 320px, transparent), radial-gradient( circle at right, #111, rgba(51, 51, 51, 1));
		background-color: #333;
}

.blackboard:before {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 100%;
		height: 100%;
		background-image: linear-gradient( 175deg, transparent, transparent 40px, rgba(120, 120, 120, 0.1) 100px, rgba(120, 120, 120, 0.1) 110px, transparent 220px, transparent), linear-gradient( 200deg, transparent 80%, rgba(50, 50, 50, 0.3)), radial-gradient( ellipse at right bottom, transparent, transparent 200px, rgba(80, 80, 80, 0.1) 260px, rgba(80, 80, 80, 0.1) 320px, transparent 400px, transparent);
		border: #2c2c2c solid 2px;
		content: "Cadastrando Atividade";
		font-family: 'Permanent Marker', cursive;
		font-size: 2.2em;
		color: rgba(238, 238, 238, 0.7);
		text-align: center;
		padding-top: 20px;
}

.form {
		padding: 70px 20px 20px;
}

p {
		position: relative;
		margin-bottom: 1em;
}

label {
		vertical-align: middle;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.7);
}

p:nth-of-type(5) > label {
		vertical-align: top;
}

input,
textarea {
		vertical-align: middle;
		padding-left: 10px;
		background: none;
		border: none;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.8);
		line-height: .6em;
		outline: none;
}

textarea {
		height: 10px;
		font-size: 1.4em;
		line-height: 1em;
		resize: none;
}

input[type="submit"] {
		cursor: pointer;
		color: rgba(238, 238, 238, 0.7);
		line-height: 1em;
		padding: 0;
}

input[type="submit"]:focus {
		background: rgba(238, 238, 238, 0.2);
		color: rgba(238, 238, 238, 0.2);
}

::-moz-selection {
		background: rgba(238, 238, 238, 0.2);
		color: rgba(238, 238, 238, 0.2);
		text-shadow: none;
}

::selection {
		background: rgba(238, 238, 238, 0.4);
		color: rgba(238, 238, 238, 0.3);
		text-shadow: none;
}
</style>