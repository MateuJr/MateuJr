
<?php 
session_start();

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

 	  $mysqli = new mysqli($host,$usuario,$senha,$bd);

      if ($mysqli-> connect_errno) 
      echo "Falha na Conexão: (".$mysqli-> connect_errno.")".$mysqli-> connect_errno;

  	  
      $id=$_SESSION['ID_PROVA_ALUNO'];
      $consulta_tabela_prova = "SELECT id_prova,nome_prof,qtd_linhas,titulo_exercicio FROM tabela_prova WHERE id_prova=$id";
      $con_tabela_prova = $mysqli-> query($consulta_tabela_prova) or die($mysqli-> erro);

      
 $consulta_tabela_linha1 = "SELECT fase1,fase2,id_linha FROM tabela_linha1 WHERE id_prova=$id";
      $con_tabela_linha1 = $mysqli-> query( $consulta_tabela_linha1) or die($mysqli-> erro);
      
      $consulta_tabela_linha2 = "SELECT fase1,fase2,id_linha FROM tabela_linha2 WHERE id_prova=$id";
      $con_tabela_linha2 = $mysqli-> query( $consulta_tabela_linha2) or die($mysqli-> erro);

       $consulta_tabela_linha3 = "SELECT fase1,fase2,id_linha FROM tabela_linha3 WHERE id_prova=$id";
      $con_tabela_linha3 = $mysqli-> query( $consulta_tabela_linha3) or die($mysqli-> erro);

      $consulta_tabela_linha4 = "SELECT fase1,fase2,id_linha FROM tabela_linha4 WHERE id_prova=$id";
      $con_tabela_linha4 = $mysqli-> query( $consulta_tabela_linha4) or die($mysqli-> erro);


      

/*echo "<br> <br><br> <br><br> <br> $id";*/



$Variavel_Fechar='< /';
$Vairiavel_Input='type=';
$Vairiavel_Value='value=';
$Texto_Professor='Tela LOGIN';
$Texto_Professor2='Entrar';
$input='';
$op=3;
$a='<p>';
$b='Usuário:';
$c='</p>';

$td = $a.$b.$c;
$e='combo1';

/*==========================================================================================================================================*/

                                /*            Botão Executar                             */


/*==========================================================================================================================================*/

if (isset($_POST['btn-executar'])) 
{
  $_SESSION['combo_p1']=$_POST['combo_p1'];

  $_SESSION['combo_c1']=$_POST['combo_c1'];

  $_SESSION['combo_p2']=$_POST['combo_p2'];

  $_SESSION['combo_p3']=$_POST['combo_p3'];

  $_SESSION['combo_c2']=$_POST['combo_c2']; $_SESSION['combo_c3']=$_POST['combo_c3']; $_SESSION['combo_c4']=$_POST['combo_c4'];

  $_SESSION['combo_p4']=$_POST['combo_p4']; $_SESSION['combo_p8']=$_POST['combo_p8'];

  $_SESSION['combo_p5']=$_POST['combo_p5']; $_SESSION['combo_p6']=$_POST['combo_p6']; $_SESSION['combo_p7']=$_POST['combo_p7'];


 $_SESSION['combo_p9']=$_POST['combo_p9'];$_SESSION['combo_p10']=$_POST['combo_p10'];$_SESSION['combo_p11']=$_POST['combo_p11'];$_SESSION['combo_p12']=$_POST['combo_p12'];
 $_SESSION['combo_c5']=$_POST['combo_c5']; $_SESSION['combo_c6']=$_POST['combo_c6'];


$_SESSION['combo_p13']=$_POST['combo_p13'];$_SESSION['combo_p14']=$_POST['combo_p14'];$_SESSION['combo_p15']=$_POST['combo_p15'];$_SESSION['combo_p16']=$_POST['combo_p16'];

 $_SESSION['combo_c7']=$_POST['combo_c7']; $_SESSION['combo_c8']=$_POST['combo_c8'];


  header('location: TelaResultadoAtividadeDinamica.php');
}



if (isset($_POST['btn-voltar'])) 
{
header('location: ListaAtividadeDinamicoALUNO.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src ="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.min.css
">
</head>
<body>

	<form action="" method="POST" >


    <?php while ($dado_tabela_prova = $con_tabela_prova-> fetch_array()){ ?>
     



    <div class="texto-titulo">

            <h1 class="texto-h1"> <?php echo $dado_tabela_prova['titulo_exercicio'] ?> </h1>
            <h2 class="texto-h2"> <?php echo 'Professor:  ' . $dado_tabela_prova['nome_prof']?></h2>
           
    </div>
   <div class="inicio"> 
          <h4> 
            1 < html > <br>
            2 < head > <br>
            3 < title  >    < / title > <br>
            4 < / head > <br>
            5 < body > <br>
          </h4>
</div>
<div class="tudo">
 <?php while ($dado_tabela_linha1 = $con_tabela_linha1-> fetch_array()){ ?>
   
<div class="div-linha1-container">
  <div class="div-linha1" 
    <?php if ($dado_tabela_prova["qtd_linhas"]>=1)
     {  $habilitar =''; }
     else 
     {
      $habilitar ='hidden;';
     }  

     ?> style="visibility:<?php echo $habilitar ?> "  >

      <label class="div-numero-linha">6</label><label class="texto1"> < </label>   <select   name="combo_p1"   class="chosen" 
       <?php if ($dado_tabela_linha1 ["fase1"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>
          <div class="c1"
           <?php if ($dado_tabela_linha1 ["fase1"] ==2)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> "  >
            <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
            <select name="combo_c1"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha1 ["fase1"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value"
                      <?php
                      if ($dado_tabela_linha1 ["fase1"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha1 ["fase1"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p2"  <?php if ($dado_tabela_linha1 ["fase1"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
        $consulta_tabela_tipo11 = "SELECT DISTINCT(texto) as bbb FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha1 WHERE id_prova=$id) limit 1 ";



        


      $con_tabela_tipo11 = $mysqli-> query( $consulta_tabela_tipo11) or die($mysqli-> erro);

             while ($dado_tabela_tipo11 = $con_tabela_tipo11-> fetch_array()){ 
               
      ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo11 ["bbb"]; ?> </label>  
           <?php }   ?>
          <label class="texto1"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p2" style="">
            
            

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label>

        
  

          <div class="div-linha1-FASE2" <?php if ($dado_tabela_linha1 ["fase2"] >=1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> ">
            
              <label class="texto1"> < </label>   <select   name="combo_p3"  class="chosen" 
            <?php if ($dado_tabela_linha1 ["fase2"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>
          <div class="c2"
           <?php if ($dado_tabela_linha1 ["fase2"] ==2)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> "  >
            <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
            <select name="combo_c2"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha1 ["fase2"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value"
                      <?php
                      if ($dado_tabela_linha1 ["fase2"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha1 ["fase2"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p2"  <?php if ($dado_tabela_linha1 ["fase2"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha1 WHERE id_prova=$id))";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
              ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
           <?php }   ?>
          <label class="texto1"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p4" style="">
            
            

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label>

        
              

          </div>
        </div>
          
</div>
 <?php while ($dado_tabela_linha2 = $con_tabela_linha2-> fetch_array()){ ?>
  <!-- =============================================================================================================== -->

<!--                        LINHA 2                                 -->

<!-- ========================================================================================================== -->

<br>
<div class="parte2">


<div class="container-linha-2">
      

<div class="div-linha2" 
    <?php if ($dado_tabela_prova["qtd_linhas"]>=1)
     {  $habilitar =''; }
     else 
     {
      $habilitar ='hidden;';
     }  

     ?> style="visibility:<?php echo $habilitar ?> "  >

      <label class="div-numero-linha">7</label><label class="texto1"> < </label>   <select   name="combo_p5"   class="chosen" 
       <?php if ($dado_tabela_linha2 ["fase1"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>
          <div class="c3"
           <?php if ($dado_tabela_linha2 ["fase1"] ==2)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> "  >
            <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
            <select name="combo_c3"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha2 ["fase1"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value-linha2"
                      <?php
                      if ($dado_tabela_linha2 ["fase1"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha2 ["fase1"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p6"  <?php if ($dado_tabela_linha2 ["fase1"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
        $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha2 WHERE id_prova=$id))";

      $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

             while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
      ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
           <?php }   ?>
          <label class="texto1"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p6" style="">
            
            

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label>

        
  

          <div class="div-linha2-FASE2" <?php if ($dado_tabela_linha2 ["fase2"] >=1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> ">
            
              <label class="texto1"> < </label>   <select   name="combo_p7"  class="chosen" 
            <?php if ($dado_tabela_linha2 ["fase2"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>
          <div class="c4"
           <?php if ($dado_tabela_linha2 ["fase2"] ==2)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> "  >
            <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
            <select name="combo_c4"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha2 ["fase2"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value-linha2"
                      <?php
                      if ($dado_tabela_linha2 ["fase2"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha2 ["fase2"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p8"  <?php if ($dado_tabela_linha2 ["fase2"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha2 WHERE id_prova=$id))";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
              ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
           <?php }   ?>
          <label class="texto-linha2"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p8" style="">
            
            

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label>

  </div>    

          </div>
          
          </div>
</div>

<!-- ======================================================================================================================================================================================================================================================================================= -->

      <?php while ($dado_tabela_linha3 = $con_tabela_linha3-> fetch_array()){ ?>


<!-- =============================================================================================================== -->

<!--                        LINHA 3                                 -->

<!-- ========================================================================================================== -->
<br>


      <div class="tx">

                             
            <div class="div-linha3" 
                <?php if ($dado_tabela_prova["qtd_linhas"]>2)
                 {  $habilitar =''; }
                 else 
                 {
                  $habilitar ='hidden;';
                 }  

                 ?> style="visibility:<?php echo $habilitar ?> "  >

                  <label class="div-numero-linha">8</label><label class="texto1"> < </label>   <select   name="combo_p9"   class="chosen" 
                   <?php if ($dado_tabela_linha3 ["fase1"] ==1)  {
                        $x='';}
                        else
                        {
                          $x='hidden;';
                          }
                       
                        ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
                      </select><label class="texto1"> ></label>
                    <div class="c5"
                     <?php if ($dado_tabela_linha3 ["fase1"] ==2)  {
                      $x='';}
                      else
                      {
                        $x='hidden;';
                        }
                     
                      ?> 
                    style="visibility:<?php echo $x ?> "  >

                      <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
                      <select name="combo_c5"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha3 ["fase1"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value-linha3"
                      <?php
                      if ($dado_tabela_linha3 ["fase1"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha3 ["fase1"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p10"  <?php if ($dado_tabela_linha3 ["fase1"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
                style="visibility:<?php echo $x ?> ">
                <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha3 WHERE id_prova=$id))";

            $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                   while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
            ?>
                <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
                 <?php }   ?>
                <label class="texto1"><?php echo $Variavel_Fechar;?></label>
                  <select   class="chosen" name="combo_p10" style="">
                  
                  

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label><div class="div-linha3-FASE2" <?php if ($dado_tabela_linha3 ["fase2"] >=1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> ">
            
              <label class="texto1"> < </label>   <select   name="combo_p11"  class="chosen" 
            <?php if ($dado_tabela_linha3 ["fase2"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>

          <div class="c6"
                           <?php if ($dado_tabela_linha3 ["fase2"] ==2)  {
                            $x='';}
                            else
                            {
                              $x='hidden;';
                              }
                           
                            ?> 
                          style="visibility:<?php echo $x ?> "  >
                          <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
                            <select name="combo_c6"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                            <option value="number">number</option>
                            <option value="password">password</option>
                            <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha3 ["fase2"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>

                           <div class="div-value-linha3"

                                <?php
                                if ($dado_tabela_linha3 ["fase2"]==3) {
                                  $x='';

                                } else
                                {
                                  $x='hidden;';
                                }

                                ?> 
                                style="visibility:<?php echo $x ?> " > 
                                  <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                                  <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>

                          </div>

                          <label class="texto1" <?php
                         if ($dado_tabela_linha3 ["fase2"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
            </div>

                </div>
                <div class="div-p12"  <?php if ($dado_tabela_linha3 ["fase2"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha3 WHERE id_prova=$id))";

                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
              ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
           <?php }   ?>
          <label class="texto-linha3"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p12" style="">
              <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
            </select><label class="texto1"> > </label>
          </div>


     </div>
           
<?php while ($dado_tabela_linha4 = $con_tabela_linha4-> fetch_array()){ ?>


<!-- ======================================================================================================================================================================================================================================================================================= -->

<!-- =============================================================================================================== -->

<!--                        LINHA 4                                 -->

<!-- ========================================================================================================== -->
<br>


      <div class="container-linha-4">

                             
            <div class="div-linha4" 
                <?php if ($dado_tabela_prova["qtd_linhas"]>3)
                 {  $habilitar =''; }
                 else 
                 {
                  $habilitar ='hidden;';
                 }  

                 ?> style="visibility:<?php echo $habilitar ?> "  >

                  <label class="div-numero-linha">9</label><label class="texto1"> < </label>   <select   name="combo_p13"   class="chosen" 
                   <?php if ($dado_tabela_linha4 ["fase1"] ==1)  {
                        $x='';}
                        else
                        {
                          $x='hidden;';
                          }
                       
                        ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
                      </select><label class="texto1"> ></label>
                    <div class="c7"
                     <?php if ($dado_tabela_linha4 ["fase1"] ==2)  {
                      $x='';}
                      else
                      {
                        $x='hidden;';
                        }
                     
                      ?> 
                    style="visibility:<?php echo $x ?> "  >

                      <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
                      <select name="combo_c7"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                          <option value="number">number</option>
                          <option value="password">password</option>
                          <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha4 ["fase1"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>
                     <div class="div-value-linha4"
                      <?php
                      if ($dado_tabela_linha4 ["fase1"]==3) {
                        $x='';

                      } else
                      {
                        $x='hidden;';
                      }

                      ?> 
                      style="visibility:<?php echo $x ?> " > 
                        <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                        <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>
                  </div>

            <label class="texto1" <?php
                         if ($dado_tabela_linha4 ["fase1"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
          </div>
            

            <div class="div-p14"  <?php if ($dado_tabela_linha4 ["fase1"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
                style="visibility:<?php echo $x ?> ">
                <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha4 WHERE id_prova=$id))";

            $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                   while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
            ?>
                <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
                 <?php }   ?>
                <label class="texto1"><?php echo $Variavel_Fechar;?></label>
                  <select   class="chosen" name="combo_p14" style="">
                  
                  

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> > </label><div class="div-linha4-FASE2" <?php if ($dado_tabela_linha4 ["fase2"] >=1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> ">
            
              <label class="texto1"> < </label>   <select   name="combo_p15"  class="chosen" 
            <?php if ($dado_tabela_linha4 ["fase2"] ==1)  {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> style="visibility:<?php echo $x ?> "  >

                 <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
                                    
                                    
            </select><label class="texto1"> ></label>

          <div class="c8"
                           <?php if ($dado_tabela_linha4 ["fase2"] ==2)  {
                            $x='';}
                            else
                            {
                              $x='hidden;';
                              }
                           
                            ?> 
                          style="visibility:<?php echo $x ?> "  >
                          <label class="texto-input"><?php echo $Vairiavel_Input ?></label>
                            <select name="combo_c8"  class="chosen"> 
                            <option value=""></option>
                            <option value="textarea">textarea</option>
                            <option value="video">video</option>
                            <option value="text">text</option>
                            <option value="submit">submit</option>
                            <option value="checkbox">checkbox</option>
                            <option value="number">number</option>
                            <option value="password">password</option>
                            <option value="color">color</option>
                            
                        </select><label class="texto1" <?php
                         if ($dado_tabela_linha4 ["fase2"]==2) {
                          $x='';}
                          else {
                            $x='hidden;';
                          } 
                          ?>
                           style="visibility:<?php echo $x ?> ">/> </label>

                           <div class="div-value-linha4"

                                <?php
                                if ($dado_tabela_linha4 ["fase2"]==3) {
                                  $x='';

                                } else
                                {
                                  $x='hidden;';
                                }

                                ?> 
                                style="visibility:<?php echo $x ?> " > 
                                  <label class="texto-input" ><?php echo $Vairiavel_Value ?></label>
                                  <label class="Texto-Prof"> <?php echo $Texto_Professor2 ?> </label>

                          </div>

                          <label class="texto1" <?php
                         if ($dado_tabela_linha4 ["fase2"]<3) {
                          $x='hidden;';}
                         else 
                         {
                          $x='';
                         }
                          ?>
                           style="visibility:<?php echo $x ?> " >/> </label>
            </div>

                </div>
                <div class="div-p16"  <?php if ($dado_tabela_linha4 ["fase2"]==1)   {
            $x='';}
            else
            {
              $x='hidden;';
              }
           
            ?> 
          style="visibility:<?php echo $x ?> ">
          <?php 
              $consulta_tabela_tipo1 ="SELECT texto FROM tabela_tipo1 WHERE  id=(SELECT MAX(id) as ii from tabela_tipo1 where id_linha=( SELECT id_linha FROM tabela_linha4 WHERE id_prova=$id))";

                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array()){ 
              ?>
          <label class="Texto-Prof"> <?php echo $dado_tabela_tipo1 ["texto"]; ?> </label>  
           <?php }   ?>
          <label class="texto-linha4"><?php echo $Variavel_Fechar;?></label>
            <select   class="chosen" name="combo_p16" style="">
              <option value=""></option>
                   <option value="li">li</option>
                   <option value="p">p</option>
                   <option value="src">src</option>
                   <option value="h1">h1</option>
                   <option value="input">input</option>
                   <option value="button">button</option>
                   <option value="img">img</option>
                   <option value="a href">a href</option>
                   <option value="br">br</option>
                   <option value="div">div</option>
                   <option value="hr">hr</option>
                   <option value="ul">ul</option>
                   <option value="audio">audio</option>
                   <option value="video">video</option>
                   <option value="textarea">textarea</option>
                   <option value="label">label</option>
                   <option value="option">option</option>
                   <option value="h2">h2</option>
                   <option value="h3">h3</option>
                   <option value="h4">h4</option>
                   <option value="h5">h5</option>
            </select><label class="texto1"> > </label>
          </div>




















           </div>

</div>
<?php }   ?>

             

               <?php }   ?>
               <?php }   ?>
                <?php }   ?>
                <?php }   ?>


              <?php 
$n1=1;
      $n2=2;

      $n3=3;  $n4=4;

      $consulta_resposta_linha_1 = "SELECT resposta FROM tabela_gabarito WHERE id_prova=$id and linha=$n1";
      $con_resposta_linha_1 = $mysqli-> query($consulta_resposta_linha_1) or die($mysqli-> erro);

      $consulta_resposta = "SELECT resposta,id_prova,linha FROM tabela_gabarito WHERE id_prova=$id ";
      $con_resposta = $mysqli-> query($consulta_resposta) or die($mysqli-> erro);

      

           $consulta_resposta_linha_2 = "SELECT resposta FROM tabela_gabarito WHERE id_prova=$id and linha=$n2";
      $con_resposta_linha_2 = $mysqli-> query($consulta_resposta_linha_2) or die($mysqli-> erro);

      $consulta_resposta_linha_3 = "SELECT resposta FROM tabela_gabarito WHERE id_prova=$id and linha=$n3";
      $con_resposta_linha_3 = $mysqli-> query($consulta_resposta_linha_3) or die($mysqli-> erro);

       $consulta_resposta_linha_4 = "SELECT resposta FROM tabela_gabarito WHERE id_prova=$id and linha=$n4";
      $con_resposta_linha_4 = $mysqli-> query($consulta_resposta_linha_4) or die($mysqli-> erro);


$linha1=''; $linha2=''; $linha3=''; $linha4='';

     while ($dado_resposta_linha_1 = $con_resposta_linha_1-> fetch_array())
     { 

      $linha1=  $dado_resposta_linha_1['resposta'];
    }
          
    while ($dado_resposta_linha_2 = $con_resposta_linha_2-> fetch_array())
    { 

      $linha2=  $dado_resposta_linha_2['resposta'];
    }
    
    while ($dado_resposta_linha_3 = $con_resposta_linha_3-> fetch_array())
    
    {

      $linha3=  $dado_resposta_linha_3['resposta'];
    }


    while ($dado_resposta_linha_4 = $con_resposta_linha_4-> fetch_array())
    
    {

      $linha4=  $dado_resposta_linha_4['resposta'];
    }

  
?>
    
      





          <div class="container-obj-compilador">

                  <label class="obj">Objetivo:</label>

              <div class="container-executavel">

                
                 <?php echo  $linha1 ; ?>

                   <?php echo  $linha2 ; ?>

                   <?php echo  $linha3; ?>

                   <?php echo  $linha4; ?>


               
                  
                
              </div>

              <button class="botao" name="btn-executar">Executar</button>
              <button class="botao" name="btn-voltar">Voltar</button>

          </div>


      


                 

</form>
</body>
<script type="text/javascript">
  $('.chosen').chosen();




</script>
</html>

<style type="text/css">


  body
  {
    background: black;
    

  }




  .texto-h1
  {
    color: white;
    
    position: relative;
    left: 110px;
    top: 60px;
  }
.texto-titulo
{
  position: fixed;
  top: -70px;
  left: -80px;

}
  h4
  {
    color: red;
  }

  .texto-h2
  {
    color: white;
    
    right: -1150px;
    position: relative;
    top: 10px;
  }



  .texto1
  {
    color: red;
    font-size: 1.3em;
  }

  .Texto-Prof
  {
    color: white;
    font-size: 1.1em;
    margin: 10px;
  }

  .texto-input
  {
    color: green;
    font-size: 1.3em;
  }
  .c1
  {
    display: inline-block;
  }

  .c2
  {
    display: inline-block;
  }

  .div-value
  {
    display: inline-block;

  }


  .div-p2 /*  TESTANDO   ==========================         */
  {
    display: inline;
    /*background: red;*/
    position: relative;
    left: -320px;
    
    

  }

  .div-linha1
  {
    
  }

  .div-linha1-FASE2
  {   
      display: inline;
  }

   .div-linha1-container
  {
      display: inline-block;
      
      position: relative;
      top: 50px;
  }


/* ============================================================================================================*/


/*                   L I N H A   2                                 */

/* ============================================================================================================*/

  .container-linha-2
  {
    position: relative;
   
    
  }
.parte2
{
 position: relative;
 left:2px;
 top: -10px;
   display: inline;
   margin: 5px;
      
   
       
}

.div-linha2

{

      
}

.div-value-linha2
{
  display: inline;
}

.div-p6
{
  display: inline;
  /*background: red;*/
    position: relative;
    left: -320px;
}

.div-p8
{
  display: inline;
}

.div-linha2-FASE2
{
  display: inline;
}

.c3
{
  display: inline;
}

.c4
{
  display: inline;
}



/* ============================================================================================================*/


/*                   L I N H A   3                                 */

/* ============================================================================================================*/



  .tx
  {
    
    position: relative;
    top: 30px;
    left: 2px;
    
    height: 50px;
  }

.div-linha3

{
 
      
}

.div-value-linha3
{
  display: inline-block;
}

.div-p10
{
  display: inline;
  /*background: red;*/
    position: relative;
    left: -320px;
}

.div-p12
{
  display: inline;
}

.div-linha3-FASE2
{
  display: inline;
}

.c5
{
  display: inline-block;
}

.c6
{
  display: inline-block;
}

.div-numero-linha
{
  color: gray;
}


/* ============================================================================================================*/


/*                   L I N H A   4                                 */

/* ============================================================================================================*/

  .container-linha-4
  {
   
    position: relative;
    top: 30px;
    left: 5px;
    
    height: 50px;
  }
.div-linha4

{

      
}

.div-value-linha4
{
  display: inline-block;
}

.div-p14
{
  display: inline;
  /*background: red;*/
    position: relative;
    left: -320px;
}

.div-p16
{
  display: inline;
}

.div-linha4-FASE2
{
  display: inline;
}

.c7
{
  display: inline-block;
}

.c8
{
  display: inline-block;
}



/*=========================================================================================== */
/*                  E X  E C U T A V E L 
                        */
/*=========================================================================================== */



  .container-executavel
  {
    background: white;
    width: 510px;
    height: 400px;
    
   /* position: relative;
    right: -850px;
    top: -250px;*/
    color: black;
    padding: 5px;

  }

  .obj
  {
    color: red;
   
    font-size: 2.1em;
   
  }

  .inicio
  {
    position: relative;
    top: 50px;

  }

  .container-obj-compilador
  {
    position: relative;
    
    top: -210px;
    width: 600px;
    height: 500px;
    left: 1050px;
    /*background: yellow;*/
  }

  

.tudo
{
 
  position: relative;
  top: 30px;

}

.botao
{
  margin: 10px;
  cursor: pointer;
  background: none;
  border-color: white 20px;
  color: white;
  width: 90px;
  height: 50px;
  font-size: 15px;
}

.botao:hover
{
  margin: 10px;
  cursor: pointer;
  background: yellow;
  color: black;
}


</style>


