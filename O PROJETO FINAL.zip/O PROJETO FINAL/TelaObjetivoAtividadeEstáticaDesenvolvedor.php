<?php 
session_start();

$servername="localhost";
$username="root";
$password="";
$db_name="projeto_tcc";


$var_resultado='';

$cont= $_SESSION['contador_selecionado'];

$connect =mysqli_connect($servername,$username,$password,$db_name);

    if (mysqli_connect_error())
     {
      echo "Falha na conexão!!".mysqli_connect_error();
  
    }

    

          $sql = "SELECT gabarito FROM tabela_atividade_estatica_desenvolvedor WHERE id_atividade = ' $cont ' ";
          $resultado = mysqli_query($connect,$sql);
          $dados = mysqli_fetch_array($resultado);

         $var_resultado= $dados['gabarito'];
         

         
    



?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
   
</head>
<body>
<form action="" method="POST">

	<table width="100%" border="0" cellspacing="5" cellpadding="5">
            <tr>
                <td width="50%" scope="col">&nbsp;</td>
                <td width="50%" align="left" scope="col">
                    
                </td>
            </tr>
            <tr>
                <td>
                    
                        
                        <textarea style="display:none;" name="sourceCode" id="sourceCode">
<html>
<head>
<title>Hello</title>
</head>
<body>

<?php echo $var_resultado; ?>


</body>
</html>
                        </textarea>
                    </td>
                </tr>
            </table>

<div id="container">
  <div id="monitor">
  	
    <div id="monitorscreen">
    	


                    <td class="pp"><iframe name="targetCode" id="targetCode"></iframe></td> 
            </tr>
        </table>  

    </div>
  </div>
</div>




</form>

		<script type="text/javascript">
            function runCode()
            {
                var content = document.getElementById('sourceCode').value;
                var iframe = document.getElementById('targetCode');
                iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
                iframe.document.open();
                iframe.document.write(content);
                iframe.document.close();
                return false;
            }
            runCode();
        </script>
</body>
</html>

<style type="text/css">
	body {
	 background-color: #000;
	 overflow: hidden;
}

iframe
    {
      position: relative;
      width: 500px;
      height: 300px;
      top: 110px;
      left: 250px;
      background-color: #777;
      border-style: none;
      border: none;

    }

 #container {
	 max-width: 1024px;
	 margin: auto;
	 position: relative;
	 top: -90px;
}
 #monitor {
	 background: #000;
	 position: relative;
	 border-top: 3px solid #888;
	 margin: 5%;
	 padding: 2% 2% 4% 2%;
	 border-radius: 10px;
	 border-bottom-left-radius: 50% 2%;
	 border-bottom-right-radius: 50% 2%;
	 transition: margin-right 1s;
}
 #monitor:after {
	 content: '';
	 display: block;
	 position: absolute;
	 bottom: 3%;
	 left: 36%;
	 height: 0.5%;
	 width: 28%;
	 background: #ddd;
	 border-radius: 50%;
	 box-shadow: 0 0 3px 0 white;
}
 #monitorscreen {
	 position: relative;
	 background-color: #777;
	 background-size: cover;
	 background-position: top center;
	 height: 0;
	 padding-bottom: 56.25%;
	 position: relative;
	 overflow: hidden;
}
 @media all and (min-width: 960px) {
	 #monitor {
		 -webkit-animation: tvflicker 0.2s infinite alternate;
		 -moz-animation: tvflicker 0.5s infinite alternate;
		 -o-animation: tvflicker 0.5s infinite alternate;
		 animation: tvflicker 0.5s infinite alternate;
	}
	 @-webkit-keyframes tvflicker {
		 0% {
			 box-shadow: 0 0 100px 0 rgba(200, 235, 255, 0.4);
		}
		 100% {
			 box-shadow: 0 0 95px 0 rgba(200, 230, 255, 0.45);
		}
	}
	 @-moz-keyframes tvflicker {
		 0% {
			 box-shadow: 0 0 100px 0 rgba(225, 235, 255, 0.4);
		}
		 100% {
			 box-shadow: 0 0 60px 0 rgba(200, 220, 255, 0.6);
		}
	}
	 @-o-keyframes tvflicker {
		 0% {
			 box-shadow: 0 0 100px 0 rgba(225, 235, 255, 0.4);
		}
		 100% {
			 box-shadow: 0 0 60px 0 rgba(200, 220, 255, 0.6);
		}
	}
	 @keyframes tvflicker {
		 0% {
			 box-shadow: 0 0 100px 0 rgba(225, 235, 255, 0.4);
		}
		 100% {
			 box-shadow: 0 0 60px 0 rgba(200, 220, 255, 0.6);
		}
	}
}

/*============================================================*/


</style>