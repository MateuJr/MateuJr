<?php
session_start();
$combo2='';
$combo1='';



if (isset($_POST['botao-compilar']))
	 {
		/*$combo1 = $_POST['c1'];
		
		

		


		$combo2 = $_POST['c2'];*/
		
		$_SESSION['L_6_1']=$_POST['combobox_L_6_1'];
        $_SESSION['L_6_2']=$_POST['combobox_L_6_2'];

        $_SESSION['L_7_1']=$_POST['combobox_L_7_1'];
        $_SESSION['L_7_2']=$_POST['combobox_L_7_2'];
        $_SESSION['L_7_3']=$_POST['combobox_L_7_3'];
        $_SESSION['L_7_4']=$_POST['combobox_L_7_4'];

        $_SESSION['L_9_1']=$_POST['combobox_L_9_1'];
        $_SESSION['L_9_2']=$_POST['combobox_L_9_2'];
        $_SESSION['L_9_3']=$_POST['combobox_L_9_3'];
        $_SESSION['L_9_4']=$_POST['combobox_L_9_4'];

        $_SESSION['L_11_1']=$_POST['combobox_L_11_1'];
        $_SESSION['L_11_2']=$_POST['combobox_L_11_2'];
		

    

    header('Location: ExecutavelExercicioLoginInterativo.php');
		
	}

	if (isset($_POST['btn-voltar']))
   {
header("location: MenuAtividadeInterativaDesenvolvedor.php");
  }

    if (isset($_POST['btn-home']))
   {
      header("location: MenuPrincipalNovo.php");
  }



?>

<!DOCTYPE html>
<html>
<head>
	<title>Criar Login</title>
</head>
<body>
	<form action="" method="POST">

            <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
                <defs>
                    <filter id="gooey">
                        <!-- in="sourceGraphic" -->
                        <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
                        <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="highContrastGraphic" />
                        <feComposite in="SourceGraphic" in2="highContrastGraphic" operator="atop" />
                    </filter>
                </defs>
            </svg>
<div class="container-combobox">
		<h1> Exercício : Montar a Tela de Login </h1>
		
		<h4> 
			1 < html > <br>
			2 < head > <br>
			3 < title  >    < / title > <br>
			4 < / head > <br>
			5 < body > <br>
		</h4>

		<p>
                <label>6 < 
                    <select name="combobox_L_6_1"> 
                        <option value=""></option>
                        <option value="h2">h2</option>
                        <option value="p">p</option>
                        <option value="button">button</option>
                        <option value= "a href ">a href</option>
                        
                    </select>
               > Tela de Login </label>

               <label> < 
                    <select name="combobox_L_6_2"> 
                        <option value=""></option>
                        <option value="p">p</option>
                        <option value="h2">h2</option>
                        <option value="button">button</option>
                        <option value="a href">a href</option>
                        
                    </select>
               /> </label>




            </p>

            <p>
                <label>7 < 
                    <select name="combobox_L_7_1"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="li">li</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               >   Login </label>

               <label> < 
                    <select name="combobox_L_7_2"> 
                        <option value=""></option>
                        <option value="li">li</option>
                        <option value="scs">button</option>
                        <option value="label">label</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>


                <label> < 
                    <select name="combobox_L_7_3"> 
                        <option value=""></option>
                        <option value="textarea">textarea</option>
                        <option value="video">video</option>
                        <option value="button">button</option>
                        <option value="input">input</option>
                        
                    </select>

                    <label> type = "
                    	 <select name="combobox_L_7_4"> 
	                        <option value=""></option>
	                        <option value="checkbox">checkbox</option>
	                        <option value="number">number</option>
	                        <option value="text">text</option>
	                        <option value="color">color</option>
	                        
                    	</select>




                     "</label>
               
               >  </label>

            </p>
            <h4>8 < br ></h4>

            <p>
                <label>9 < 
                    <select name="combobox_L_9_1"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="li">li</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               >   Senha </label>

               <label> < 
                    <select name="combobox_L_9_2"> 
                        <option value=""></option>
                        <option value="li">li</option>
                        <option value="button">button</option>
                        <option value="label">label</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>


                <label> < 
                    <select name="combobox_L_9_3"> 
                        <option value=""></option>
                        <option value="textarea">textarea</option>
                        <option value="video">video</option>
                        <option value="button">button</option>
                        <option value="input">input</option>
                        
                    </select>

                    <label> type = "
                    	 <select name="combobox_L_9_4"> 
	                        <option value=""></option>
	                        <option value="checkbox">checkbox</option>
	                        <option value="number">number</option>
	                        <option value="text">text</option>
	                        <option value="password">password</option>
	                        
                    	</select>




                     "</label>
               
               >  </label>

            </p>

            <h4>10 < br ></h4>


            <p>
                <label>11 < 
                    <select name="combobox_L_11_1"> 
                        <option value=""></option>
                        <option value="h2">h2</option>
                        <option value="p">p</option>
                        <option value="button">button</option>
                        <option value="a href=">a href=""</option>
                        
                    </select>
               > Entrar </label>

               <label> < 
                    <select name="combobox_L_11_2"> 
                        <option value=""></option>
                        <option value="p">p</option>
                        <option value="h2">h2</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        
                    </select>
               /> </label>


</div>

            </p>
            <div class="container-foto-botao">
            	<h1 class="obj-foto"> Objetivo:</h1>
            	
	            <div class="cont-foto">
	            	
	            	<img src="log1.png">
	            	
	            </div>
            


            

            <div class="multi-button">
            <button name="btn-voltar">Voltar</button>
            <button name="botao-compilar">Compilar</button>
            <button name="btn-home">Home</button>
          </div>


        </div>

	</form>

</body>
</html>



<style type="text/css">
	.verde{
    	color: green;
    }
    .orange{
    	color: orange;
    }
	body{
		background: black;
		overflow: hidden;

	}
	h1{
		color: white;
		text-align: center;
	}
	h4{
		color: white;
		font-size: 1.2em;

	}

	label{
        font-size: 1.2em;
        color: white;
    }

    .cont-foto{
    	background: white;
    	width: 350px;
    	height: 350px;
    	position: relative;
    	left: 710px;
    	top: -450px;
    }

    .obj-foto{
    	color: red;
    	position: relative;
    	left: 150px;
    	top: -450px;
    }

    .btn-verificar{
    	border-radius: 50%;
    	width: 150px;
    	height: 100px;
    	cursor: pointer;
    	position: relative;
    	left: 1100px;
    	top: -780px;
    }


      .container-combobox
      {
        position: relative;
        top: -170px;
      }

      .container-foto-botao
      {

          position: relative;
          top: -120px;

      }

    /*======================================BOTÃO=====================================================================================*/

:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;
  --color-secondary: #707B7C;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}



.multi-button {
  display: flex;
  width: 40%;
  box-shadow: var(--shadow) 4px 4px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  top: -420px;
  right: -680px;
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  text-transform: lowercase;
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background-color: var(--color-secondary);
}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}

    

</style>