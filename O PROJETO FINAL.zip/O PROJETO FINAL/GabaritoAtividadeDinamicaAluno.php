<?php 
session_start();
$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";



if (isset($_POST['botao-voltar'])) {
	 header('Location: MenuVertical.php');
}


/*---------------------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------------------------------------*/

$mysqli = new mysqli($host,$usuario,$senha,$bd);

$resposta_linha_1='';
$resposta_linha_2='';
$resposta_linha_3='';
$resposta_linha_4='';
$ID=$_SESSION['ID_PROVA_ALUNO'];
$sql_resp_linha1="SELECT * FROM tabela_gabarito
               WHERE id_prova =' $ID ' AND linha =1 ";

$sql_resp_linha2="SELECT * FROM tabela_gabarito
               WHERE id_prova =' $ID ' AND linha =2 ";

$sql_resp_linha3="SELECT * FROM tabela_gabarito
               WHERE id_prova =' $ID ' AND linha =3 ";

$sql_resp_linha4="SELECT * FROM tabela_gabarito
               WHERE id_prova =' $ID ' AND linha =4 ";

                             if (!$mysqli -> query( $sql_resp_linha1))
                               {
                                    echo("Error description: " . $mysqli -> error);
                                   
                            }else
                            {
                              $sql_resultado_linha1 = $mysqli-> query($sql_resp_linha1);
                             
                              
                            }

                            if (!$mysqli -> query( $sql_resp_linha2))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_linha2 = $mysqli-> query($sql_resp_linha2);
           
            
          }

                            if (!$mysqli -> query( $sql_resp_linha3))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_linha3 = $mysqli-> query($sql_resp_linha3);
           
            
          }

                            if (!$mysqli -> query( $sql_resp_linha4))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_linha4 = $mysqli-> query($sql_resp_linha4);
           
            
          }



           while ($dado_1 = $sql_resultado_linha1-> fetch_array())
           { 

              $resposta_linha_1=$dado_1['resposta'];
            }

            while ($dado_2 = $sql_resultado_linha2-> fetch_array())
           { 
                $resposta_linha_2=$dado_2['resposta'];
            }

            while ($dado_3 = $sql_resultado_linha3-> fetch_array())
           { 
              $resposta_linha_3=$dado_3['resposta'];
            }

            while ($dado_4 = $sql_resultado_linha4-> fetch_array())
           { 
              $resposta_linha_4=$dado_4['resposta'];
            }


/*---------------------------------------------------------------------------------------------------------------------------------------*/

$Linha1_Finalizada=$_SESSION['linha_1'];
$Linha2_Finalizada=$_SESSION['linha_2'];
$Linha3_Finalizada=$_SESSION['linha_3'];
$Linha4_Finalizada=$_SESSION['linha_4'];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
</head>
<body>
<form action="" method="POST">
	<h1 align="center">Gabarito</h1>
	
	<div>
	  <div class="container">
	    <ul>
	      <li><a href="TelaResultadoAtividadeDinamica.php" name="botao-voltar"><i class="fa fa-arrow-left" aria-hidden="true" ></i></a></li>
	     <br>
	      <li><a href="MenuPrincipalNovo.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
	    </ul>
	  </div>
	</div>

	<h4 class="txt-resp">Sua Resposta</h4>
	<h4 class="txt-gabarito">Gabarito</h4>
</form>
             <textarea name="sourceCode" id="sourceCode" class="textarea1">

<html>
<head>
<title></title>
</head>
<body>

<?php echo $Linha1_Finalizada; ?>

<?php echo $Linha2_Finalizada; ?>

<?php echo $Linha3_Finalizada; ?>

<?php echo $Linha4_Finalizada; ?>

</body>
</html>
                        </textarea>

             <textarea name="sourceCode" id="sourceCode" class="textarea2">

<?php echo  $resposta_linha_1; ?> 

<?php echo $resposta_linha_2; ?>

<?php echo $resposta_linha_3; ?>


<?php echo $resposta_linha_4; ?>

                        </textarea>


</body>
</html>

<style type="text/css">
	body
	{
		overflow: hidden;
		background: black;
	}
	.textarea1
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			top: -150px;
          color: red;

	}

	.textarea2
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			left: 100px;
    			top: -150px;
          color: green;


	}

	.txt-resp
	{
		font-size: 1.4em;
		color: red;
		position: relative;
		top: -80px;
	}

	.txt-gabarito
	{
		font-size: 1.4em;
		color: green;
		position: relative;
		left: 750px;
		top: -140px;
	}
	.btn-voltar
	{
		height: 50px;
		width: 50px;
		position: relative;
		left: 630px;
		top: 250px;
		cursor: pointer;
	}

	/*======================= BOTÃO =============================================*/

	ul {
  margin:0;
  padding:0;
  display:block;
  position: absolute;
  top: 50%;
  left:49%;
  transform: translate(-50%, -50%);
}

ul li {
  list-style:none;
  margin: 0 15px;
}

ul li a {
  position: relative;
  display: block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  background: #171515;
  border-radius: 50%;
  font-size: 30px;
  color: #666;
  transition: .5s;
}

ul li a:before {
  content: '';
  position: absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
  border-radius:50%;
  background: #d35400;
  transition: .5s;
  transform: scale(.9);
  z-index: -1;
}

ul li a:hover:before {
  transform: scale(1.2);
  box-shadow: 0 0 15px #d35400;
  filter: blur(3px);
}

ul li a:hover {
  color: #ffa502;
  box-shadow: 0 0 15px #d35400;
  text-shadow: 0 0 15px #d35400;
}
</style>