<?php
session_start();
$combo2='';
$combo1='';



if (isset($_POST['botao-compilar']))
	 {
		
		
		    $_SESSION['L_6_1']=$_POST['combobox_L_6_1'];
        $_SESSION['L_6_2']=$_POST['combobox_L_6_2'];

         $_SESSION['L_8_1']=$_POST['combobox_L_8_1'];
        $_SESSION['L_8_2']=$_POST['combobox_L_8_2'];

        $_SESSION['L_9_1']=$_POST['combobox_L_9_1'];
        $_SESSION['L_9_2']=$_POST['combobox_L_9_2'];
       
        $_SESSION['L_10_1']=$_POST['combobox_L_10_1'];
        $_SESSION['L_10_2']=$_POST['combobox_L_10_2'];

        $_SESSION['L_11_1']=$_POST['combobox_L_11_1'];
        $_SESSION['L_11_2']=$_POST['combobox_L_11_2'];

        $_SESSION['L_12_1']=$_POST['combobox_L_12_1'];
        $_SESSION['L_12_2']=$_POST['combobox_L_12_2'];

        $_SESSION['L_17_1']=$_POST['combobox_L_17_1'];

        $_SESSION['L_19_1']=$_POST['combobox_L_19_1'];

        $_SESSION['L_20_1']=$_POST['combobox_L_20_1'];
        $_SESSION['L_20_2']=$_POST['combobox_L_20_2'];

        $_SESSION['L_21_1']=$_POST['combobox_L_21_1'];

        $_SESSION['L_22_1']=$_POST['combobox_L_22_1'];

        $_SESSION['L_23_1']=$_POST['combobox_L_23_1'];

        $_SESSION['L_24_1']=$_POST['combobox_L_24_1'];
         $_SESSION['L_24_2']=$_POST['combobox_L_24_2'];
		

    

    header('Location: ExecutavelExercicioMenuVerticalInterativo.php');
		
	}

	if (isset($_POST['btn-home']))
   {
      $_SESSION['L_6_1']='';
        $_SESSION['L_6_2']='';

         $_SESSION['L_8_1']='';
        $_SESSION['L_8_2']='';

        $_SESSION['L_9_1']='';
        $_SESSION['L_9_2']='';
       
        $_SESSION['L_10_1']='';
        $_SESSION['L_10_2']='';

        $_SESSION['L_11_1']='';
        $_SESSION['L_11_2']='';

        $_SESSION['L_12_1']='';
        $_SESSION['L_12_2']='';

        $_SESSION['L_17_1']='';

        $_SESSION['L_19_1']='';

        $_SESSION['L_20_1']='';
        $_SESSION['L_20_2']='';

        $_SESSION['L_21_1']='';

        $_SESSION['L_22_1']='';

        $_SESSION['L_23_1']='';

        $_SESSION['L_24_1']='';
         $_SESSION['L_24_2']='';

         header('Location: MenuPrincipalNovo.php');
  }


if (isset($_POST['btn-voltar']))
   {
      $_SESSION['L_6_1']='';
        $_SESSION['L_6_2']='';

         $_SESSION['L_8_1']='';
        $_SESSION['L_8_2']='';

        $_SESSION['L_9_1']='';
        $_SESSION['L_9_2']='';
       
        $_SESSION['L_10_1']='';
        $_SESSION['L_10_2']='';

        $_SESSION['L_11_1']='';
        $_SESSION['L_11_2']='';

        $_SESSION['L_12_1']='';
        $_SESSION['L_12_2']='';

        $_SESSION['L_17_1']='';

        $_SESSION['L_19_1']='';

        $_SESSION['L_20_1']='';
        $_SESSION['L_20_2']='';

        $_SESSION['L_21_1']='';

        $_SESSION['L_22_1']='';

        $_SESSION['L_23_1']='';

        $_SESSION['L_24_1']='';
         $_SESSION['L_24_2']='';

         header('Location: MenuAtividadeInterativaDesenvolvedor.php');
  }

?>

<!DOCTYPE html>
<html>
<head>
	<title>Criar Login</title>
</head>
<body>
	<form action="" method="POST">

            <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
                <defs>
                    <filter id="gooey">
                        <!-- in="sourceGraphic" -->
                        <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
                        <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="highContrastGraphic" />
                        <feComposite in="SourceGraphic" in2="highContrastGraphic" operator="atop" />
                    </filter>
                </defs>
            </svg>

		<h1 class="texto-principal"> Exercício : Montar Menu Vertical </h1>
		<div class="container-tudo">
		<h4 style="color:red;"> 
			1 < html > <br>
			2 < head > <br>
			3 < title  >    < / title > <br>
			4 < / head > <br>
			5 < body > <br>
		</h4>

		<p>
                <label >6 < 
                    <select name="combobox_L_6_1"> 
                        <option value=""></option>
                        <option value="h2">h2</option>
                        <option value="p">p</option>
                        <option value="button">button</option>
                        <option value= "a href ">a href</option>
                        
                    </select>
               > <label class="texto-padrao"> Menu Vertical </label></label>

               <label> < 
                    <select name="combobox_L_6_2"> 
                        <option value=""></option>
                        <option value="p">p</option>
                        <option value="h2">h2</option>
                        <option value="button">button</option>
                        <option value="a href">a href</option>
                        
                    </select>
               /> </label>




    </p>

            <p>
                
                  <h4>7 <label class="texto-css">< div class="vertical-menu" ></label> </h4>

            </p>
            <label>8 < 
                    <select name="combobox_L_8_1"> 
                        <option value=""></option>
                        <option value= "a href ">a href</option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               > <label class="texto-padrao">  Home</label> </label>
               <label> < 
                    <select name="combobox_L_8_2"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>



            <p>

               </p>
            <label>9 < 
                    <select name="combobox_L_9_1"> 
                        <option value=""></option>
                        <option value= "a href ">a href</option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               >   <label class="texto-padrao">Perfil </label> </label>
               <label> < 
                    <select name="combobox_L_9_2"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>



            <p>

               </p>
            <label>10 < 
                    <select name="combobox_L_10_1"> 
                        <option value=""></option>
                        <option value= "a href ">a href</option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               >   <label class="texto-padrao">Sobre Nós </label> </label>
               <label> < 
                    <select name="combobox_L_10_2"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>



            <p>

               </p>
            <label>11 < 
                    <select name="combobox_L_11_1"> 
                        <option value=""></option>
                        <option value= "a href ">a href</option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               > <label class="texto-padrao">  Configurações </label> </label>
               <label> < 
                    <select name="combobox_L_11_2"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>



            <p>

              <label>12 < 
                    <select name="combobox_L_12_1"> 
                        <option value=""></option>
                        <option value= "a href ">a href</option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               > <label class="texto-padrao">  Logout </label> </label>
               <label> < 
                    <select name="combobox_L_12_2"> 
                        <option value=""></option>
                        <option value="label">label</option>
                        <option value="button">button</option>
                        <option value="a">a</option>
                        <option value="textarea">textarea</option>
                        
                    </select>
               />  </label>

             </p>

              <h4>13 <label class="texto-css">< / div ></label> </h4>
              <h4>14 <label class="texto-css">< style ></label> </h4>
              <h4>15 <label class="texto-css">.vertical-menu {</label> </h4>
              <h4>16 <label class="texto-css">width: 200px; </label></h4>
              <h4>17 <label class="texto-css">text-align: </label> <select name="combobox_L_17_1"> 
                        <option value=""></option>
                        <option value="left">left</option>
                        <option value="center">center</option>
                        <option value="right">right</option>
                        <option value="none">none</option>
                        
                    </select>  }
              </h4>
              <p>
                <h4>18 <label class="texto-css">.vertical-menu a { </label>
                  <p>
                 <label>19</label>
                      <select name="combobox_L_19_1"> 
                        <option value=""></option>
                        <option value="background-color:">background-color:</option>
                        <option value="color:">color</option>
                        <option value="background:">background</option>
                        <option value="none:">none</option>
                        
                    </select><label>: #000;</label>

                 </h4>

                 <h4> 20 <select name="combobox_L_20_1"> 
                        <option value=""></option>
                        <option value="background-color:">background-color:</option>
                        <option value="color:">color</option>
                        <option value="background:">background</option>
                        <option value="none:">none</option>
                        
                    </select> <label>:</label> <select name="combobox_L_20_2"> 
                        <option value=""></option>
                        <option value="#000">#000</option>
                        <option value="#ffffff">#ffffff</option>
                        <option value="#008000">#008000</option>
                        <option value="#ffff00">#ffff00</option>
                        
                    </select>
                   ;
                 </h4>
                 <h4>21 <label class="texto-css">Display : </label><select name="combobox_L_21_1"> 
                        <option value=""></option>
                        <option value="block">block</option>
                        <option value="inline">inline</option>
                        <option value="flex">flex</option>
                        <option value="grid">grid</option>
                        <option value="inline-block">inline-block</option>
                        
                    </select>
                  ;</h4>

                  <h4> 22 <select name="combobox_L_22_1"> 
                        <option value=""></option>
                        <option value="margin:">margin</option>
                        <option value="width:">width</option>
                        <option value="height:">height</option>
                        <option value="padding:">padding</option>
                        
                    </select>
                   <label class="texto-css"> : 12px ; </label>
                  </h4>
                  <h4>23 <label class="texto-css">text-decoration : </label> <select name="combobox_L_23_1"> 
                        <option value=""></option>
                        <option value="overline">overline</option>
                        <option value="line-through">line-through</option>
                        <option value="underline">underline</option>
                        <option value="none">none</option>
                        
                    </select>
                    ;
                  }
                  </h4>

                  <h4>24 <label class="texto-css">.vertical-menu a:hover { </label>
                    <p>
                     <select name="combobox_L_24_1"> 
                        <option value=""></option>
                        <option value="background-color:">background-color:</option>
                        <option value="color:">color</option>
                        <option value="background:">background</option>
                        <option value="none:">none</option>
                      </select>:
                       <select name="combobox_L_24_2"> 
                        <option value=""></option>
                        <option value="#000">#000</option>
                        <option value="#ffffff">#ffffff</option>
                        <option value="#008000">#008000</option>
                        <option value="#ffff00">#ffff00</option>
                        
                    </select>


                  </h4> 
                  <h4>25  }
                    <p>
                    <h4 style="color:red;">26 < /style > </h4>  
                      <h4 style="color:red;">27 < / body > </h4>
                      <h4 style="color:red;">27 < / html > </h4>

                    
                    </p>
                  </h4>

               




            </p>
            
            	<h1 class="obj-foto"> Objetivo:</h1>
            	
	            <div class="cont-foto">
	            	
	            	<img src="vertical.jpg" align="center">
	            	
	            </div>
            
</div>

            

         <div class="multi-button">
            <button name="btn-voltar">Voltar</button>
            <button name="botao-compilar">Compilar</button>
            <button name="btn-home">Home</button>
          </div>



	</form>

</body>
</html>



<style type="text/css">
	.verde{
    	color: green;
    }
    .orange{
    	color: orange;
    }
	body{
		background: black;
		/*overflow: hidden;*/
	   }
     .texto-padrao
     {
      color: #85C1E9;
      font-size: 1.2em;
     }

      .texto-css
     {
      color: #82E0AA;
      font-size: 1.2em;
     }

     .container-tudo
     {
      position: relative;
      top: -150px;
     }
  .texto-principal{
     position: relative;
     top: -150px; 
    }
	h1{
		color: white;
		text-align: center;
	}
	h4{
		color: white;
		font-size: 1.2em;

	}

	label{
        font-size: 1.2em;
        color: white;
    }

    .cont-foto{
    	background: white;
    	width: 350px;
    	height: 350px;
    	position: relative;
    	left: 710px;
    	top: -1150px;
      

    }

    .obj-foto{
    	color: red;
    	position: relative;
    	left: 350px;
    	top: -1200px;
    }

    .btn-verificar{
    	border-radius: 50%;
    	width: 150px;
    	height: 100px;
    	cursor: pointer;
    	position: relative;
    	left: 1100px;
    	top: -780px;
    }

    /*======================================BOTÃO=====================================================================================*/

:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;
  --color-secondary: #707B7C;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}



.multi-button {
  display: flex;
  width: 40%;
  box-shadow: var(--shadow) 4px 4px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  top: -1200px;
  right: -540px;
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  text-transform: lowercase;
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background-color: var(--color-secondary);
}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}

    

</style>