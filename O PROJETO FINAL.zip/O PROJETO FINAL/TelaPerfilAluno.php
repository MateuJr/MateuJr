<?php
session_start();
$nome=$_SESSION['session_nome_completo'];
$usuario_login=$_SESSION['nome_usuario_novo'];



$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

$email_professor='';

$var_ID_ALUNO=$_SESSION['session_ID_Aluno_numero'];

$ocultar_caixa4_parte1='';

$ocultar_caixa4_parte2='style="display:none;"';
/*==================================================================================================================*/
$sql_dados_aluno="SELECT * FROM tabela_aluno WHERE
          nome_aluno = '$nome'";

             if (!$mysqli -> query( $sql_dados_aluno))
                   {
                        echo("Error description: " . $mysqli -> error);
                       
                }else
                {
                  $sql_resultado = $mysqli-> query($sql_dados_aluno);
                 
                  
                }

            while ($dado_aluno = $sql_resultado-> fetch_array())
            {

                $email_aluno= $dado_aluno['email'];

            }


/*================================================================================================*/



 $sql_busca_DIS="SELECT nome_disciplina FROM tabela_disciplina WHERE id_disciplina IN(  SELECT id_disciplina FROM tabela_disciplina_aluno WHERE id_aluno='$var_ID_ALUNO');";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_DIS = $mysqli-> query($sql_busca_DIS);
           
            
          }

/*================================================================================================*/



 $sql_busca_IE="SELECT * FROM tabela_aluno WHERE nome_aluno ='$nome' ";

         if (!$mysqli -> query( $sql_busca_IE))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_IE = $mysqli-> query($sql_busca_IE);
           
            
          }

/*=========================================================================================================================
*/
/*================================================================================================*/



 $sql_busca_Nome_Prof="SELECT nome_professor FROM tabela_professor WHERE id_professor IN(  SELECT id_professor FROM tabela_prof_aluno WHERE id_aluno='$var_ID_ALUNO');";

         if (!$mysqli -> query( $sql_busca_Nome_Prof))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_Nome_Prof = $mysqli-> query($sql_busca_Nome_Prof);
           
            
          }

/*=========================================================================================================================
*/
/*

if ($_SESSION['session_ID_PERFIL'] != '')

 {
  


 }else
 {
  $sql_busca_DIS="SELECT * FROM tabela_disciplina WHERE  id_disciplina IN (SELECT id_disciplina FROM tabela_prof_disciplina WHERE id_professor='$var_ID_PROF');";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_pesquisa = $mysqli-> query($sql_busca_DIS);
           
            
          }
 }
*/
/*=========================================================================================================================
*/







/*=========================================================================================================================
*/


if (isset($_POST['btn-IE']))
 {

  $ID_IE=$_POST['btn-IE'];
$_SESSION['session_ID_PERFIL']=$ID_IE;
$ocultar_caixa4_parte2='';
$ocultar_caixa4_parte1='style="display:none;"';

  

if ($_SESSION['session_ID_PERFIL'] != '')

 {
  

$sql_busca_pesquisa="SELECT * FROM tabela_disciplina WHERE id_instituto ='$ID_IE' AND id_disciplina IN (SELECT id_disciplina FROM tabela_prof_disciplina WHERE id_professor='$var_ID_PROF')";

         if (!$mysqli -> query( $sql_busca_pesquisa))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_pesquisa = $mysqli-> query($sql_busca_pesquisa);
           
            
          }
 }
 else
 {
  $sql_busca_DIS="SELECT * FROM tabela_disciplina WHERE  id_disciplina IN (SELECT id_disciplina FROM tabela_prof_disciplina WHERE id_professor='$var_ID_PROF');";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_pesquisa = $mysqli-> query($sql_busca_DIS);
           
            
          }
 }


}
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" charset="utf-8"></script>
</head>
<body>
<form action="" method="POST">
<a href="MenuPrincipalNovo.php">Home</a> <label> / </label> <a href="">User</a> <label>/</label> <label> User Profile</label> 

  <!-- 
====================================================================================================================================

                                  CAIXA 1

====================================================================================================================================
 -->
  <div class="container-caixa1">
        
              <div class="container-foto">
                <img  class="foto" src="student.jpg">               
              </div>

       <label class="texto-caixa1-nome"><?php echo $nome; ?></label>
       <label class="texto-caixa1-user"><?php echo $usuario_login; ?></label>

       <div class="container-botao-caixa1">

            <button class="botao-alterar">Editar</button>
           <button class="botao-mensagem">Mensagem</button>

       </div>

  </div>

<!-- 
====================================================================================================================================

                                  CAIXA 2

====================================================================================================================================
 -->
          <div class="container-caixa2">
      
                <div class="container-linha1-caixa2">

                    <label class="label-caixa2-black">Nome Completo: </label> <label class="label-caixa2-cinza-linha1"><?php echo $nome; ?></label>
                    <br>
                    <input type="text" class="a" name=""  disabled="">

                </div>

               <div class="container-linha1-caixa2">

                    <label class="label-caixa2-black">E-mail: </label> <label class="label-caixa2-cinza-linha2"><?php echo $email_aluno; ?></label>
                    <br>
                    <input type="text" class="a" name=""  disabled="">

              </div>

              <div class="container-linha1-caixa2">

                    <label class="label-caixa2-black">Usuário: </label> <label class="label-caixa2-cinza-linha3"><?php echo $usuario_login;?></label>
                    <br>
                    <input type="text" class="a" name=""  disabled="">

              </div>

                 <div class="container-linha1-caixa2">

                      <label class="label-caixa2-black">Perfil: </label> <label class="label-caixa2-cinza-linha4">Aluno</label>
                      <br>
                      <input type="text" class="a" name=""  disabled="">

                </div>

                  <button class="botao-editar-caixa2" name="btn-editar">Editar</button>
         </div>

<!-- 
====================================================================================================================================

                                  CAIXA 3

====================================================================================================================================
 -->

<div class="container-caixa3" >
  <label class="label-institutos">Institutos de Ensino:</label>
<br>
   <?php while ($dado_IE = $sql_resultado_IE-> fetch_array()){ ?>


           
           <br>
           
           <button name="btn-IE" id="botao-IE" class="fas fa-university" value="<?= $dado_IE['id_instituto']; ?>"></button><label class="label-nome-IE" > <?php echo $dado_IE['instituto_ensino'] ?></label> 
           <input type="text" class="b" name=""  disabled="">
           <br>
           <?php }   ?>
</div>


<!-- 
====================================================================================================================================

                                  CAIXA 4

====================================================================================================================================
 -->

<div class="container-caixa4" > 
      <label class="label-disciplinas">Minhas Disciplinas:</label>
        <br>
      <div class="sub-caixa 4" <?php echo $ocultar_caixa4_parte1 ?>>
          <?php while ($dado_DIS = $sql_resultado_DIS-> fetch_array()){ ?>


           
           <br>
           
           <button name="btn-IE" id="botao-IE" class="fas fa-book-open" value="<?= $dado_DIS['nome_disciplina']; ?>"></button><label class="label-nome-IE" > <?php echo $dado_DIS['nome_disciplina'] ?></label> 
           <input type="text" class="b" name=""  disabled="">
           <br>
           <?php }   ?>
      </div>

    
</div>



<!-- 
====================================================================================================================================

                                  CAIXA 5

====================================================================================================================================
 -->

<div class="container-caixa5" >
  <label class="label-institutos">Meus Professores:</label>
<br>
  
  <?php while ($dado_nome_prof = $sql_resultado_Nome_Prof-> fetch_array()){ ?>


           
           <br>
           
           <button name="btn-IE" id="botao-IE" class="fas fa-user" ></button><label class="label-nome-IE" > <?php echo $dado_nome_prof['nome_professor'] ?></label> 
           <input type="text" class="b" name=""  disabled="">
           <br>
           <?php }   ?>

</div>






</form>

</body>
</html>

<style type="text/css">
  body
  {
    background: #C0C0C0;
  }

/*===================================================================================================================


                                           LINKS

======================================================================================================================
*/


a
{
  text-decoration: none;
  font: 1.2em "Fira Sans", sans-serif;
  color: #2390f9;

}

a:hover
{
  text-decoration: none;
  font: 1.2em "Fira Sans", sans-serif;
  color: white;
}

label
{
  color: #555;
}

/*===================================================================================================================


                                    CAIXA 1

======================================================================================================================
*/
.foto
{
       border-radius: 50%;   
    
    width: 100px;
    height: 100px;
}

  .container-caixa1
  {
    border-style: solid;
   
    border-color: white;
    background: white;
    position: relative;
    left: 20px;
    top: 50px;
    width: 380px;
    height: 320px;
  }

  .container-foto
  {
    border-style: solid;
    border-radius: 50%;
    border-color: white;
    background: yellow;
    position: relative;
    left: 120px;
    top: 10px;
    width: 150px;
    height: 150px;
  }

.foto
{
       border-radius: 50%;   
    
    width: 150px;
    height: 150px;
}

.texto-caixa1-nome
{
  text-align: center;
  font-size: 1.7em;
  color: black;
  padding: 10px;
  margin: 10px;
  position: relative;
  left: 90px;
  top: 20px;

  
}


.texto-caixa1-user
{
  text-align: center;
  font-size: 1.8em;
  color: #A9A9A9;
  padding: 10px;
  margin-top: 10px;
  position: relative;
  left: 80px;
  top: 50px;

}

.botao-mensagem
{
  border-style: solid;
  background: white;
  color: #2390f9 ;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;
 
  font-size: 1em;
  position: relative;

  cursor: pointer;

}


.botao-mensagem:hover
{
  border-style: solid;
  background: #2390f9 ;
  color: white;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;
 
  font-size: 1em;
  position: relative;
  
  cursor: pointer;

}


.botao-alterar
{
  border-style: solid;
  background: white;
  color: #2390f9 ;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;
  
  font-size: 1em;
  position: relative;

  cursor: pointer;

}


.botao-alterar:hover
{
  border-style: solid;
  background: #2390f9 ;
  color: white;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;

  font-size: 1em;
  position: relative;
 
  cursor: pointer;

}

.container-botao-caixa1
{
  position: relative;
  
  width: 250px;
  height: 50px;
  display: inline-block;
  padding: 15px;
  margin: 15px;

  top: 20px;
  left: 50px;
}

/*===================================================================================================================


                                            CAIXA 2

======================================================================================================================
*/

 .container-caixa2
  {
    border-style: solid;
   
    border-color: white;
    background: white;
    position: relative;
    left: 420px;
    top: -270px;
    width: 780px;
    height: 320px;
  }



.a {
  border: none;
  border-bottom: 2px solid rgba(85,85,85,0.3);
  font-size: 1.2em;
  width: 750px;



}

.label-caixa2-black
{
 font-size: 1.4em;
 color: black;
 text-align: center;
 padding: 10px;
margin: 10px;


}

.label-caixa2-cinza-linha1
{
font-size: 1.4em;
color: #555;
left: 100px;
position: relative;
text-align: center;
padding: 10px;
margin: 10px;

}

.label-caixa2-cinza-linha2
{
font-size: 1.4em;
color: #555;
left: 190px;
position: relative;
text-align: center;
padding: 10px;
margin: 10px;

}

.container-linha1-caixa2
{
  position: relative;
  padding: 5px;
  margin: 5px;
}

.label-caixa2-cinza-linha3
{
font-size: 1.4em;
color: #555;
left: 180px;
position: relative;
text-align: center;
padding: 10px;
margin: 10px;

}

.label-caixa2-cinza-linha4
{
font-size: 1.4em;
color: #555;
left: 205px;
position: relative;
text-align: center;
padding: 10px;
margin: 10px;

}



.botao-editar-caixa2
{
  border-style: solid;
  background: white;
  color: #2390f9 ;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;
  
  font-size: 1em;
  position: relative;

  cursor: pointer;
  left: 80px;

}


.botao-editar-caixa2:hover
{
  border-style: solid;
  background: #2390f9 ;
  color: white;
  border-color: #2390f9 ;
  width: 110px;
  height: 40px;
 
  font-size: 1em;
  position: relative;
 
  cursor: pointer;

}

/*===================================================================================================================


                                            CAIXA 3

======================================================================================================================
*/

.container-caixa3
  {
    border-style: solid;
   
    border-color: white;
    background: white;
    position: relative;
    left: 20px;
    top: -240px;
    width: 380px;
    height: 350px;
  }

  .label-institutos
  {
    font: 1.6em "Fira Sans", sans-serif;
    vertical-align: center;
    text-align: center;
    position: relative;
    color: #2390f9 ;
    left: 50px;
  }

.label-nome-IE
{
   font: 1.2em "Fira Sans", sans-serif;
    vertical-align: center;
    text-align: center;
    position: relative;
    color: black ;
    left: 50px;
    margin: 10px;
    padding: 10px;
}

.b {
  border: none;
  border-bottom: 2px solid rgba(85,85,85,0.3);
  font-size: 1.2em;
  width: 380px;


}

#botao-IE
{
  color: red;
  position: relative;
  left: 40px;
  background: none;
  border: none;
  cursor: pointer;



}

#botao-IE:hover
{
  color: black;
  position: relative;
  left: 40px;
  background: #2390f9;
  border: none;
  cursor: pointer;

  
}

/*===================================================================================================================


                                            CAIXA 4

======================================================================================================================
*/

.container-caixa4
  {
    border-style: solid;
   
    border-color: white;
    background: white;
    position: relative;
    left: 450px;
    top: -595px;
    width: 380px;
    height: 350px;
  }

  .label-disciplinas
  {
    font: 1.6em "Fira Sans", sans-serif;
    vertical-align: center;
    text-align: center;
    position: relative;
    color: #2390f9 ;
    left: 50px;
  }


  /*===================================================================================================================


                                            CAIXA 5

======================================================================================================================
*/

 .container-caixa5
  {
    border-style: solid;
   
    border-color: white;
    background: white;
    position: relative;
    left: 880px;
    top: -950px;
    width: 380px;
    height: 350px;
  }

/*==============================================================================================================================*/

</style>