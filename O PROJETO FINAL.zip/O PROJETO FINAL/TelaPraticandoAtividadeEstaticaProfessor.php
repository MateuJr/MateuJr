<?php
session_start();

if(isset($_POST['botao-voltar']))
{
  header('Location: ListaAtividadeEstaticaALUNO.php');
}
$cont= $_SESSION['contador_selecionado'];

if(isset($_POST['botao-inicio']))
{
  header('Location: MenuPrincipalNovo.php');
}

?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet"  href="code.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
    <title>Html editor</title>
</head>
<body>
<form action="" method="POST">
 <div class="multi-button">
                          
                          <button name="botao-voltar"> <i class="fa fa-arrow-left" ></i> Voltar </button>
                          
                          <a href="TelaGabaritoAtividadeEstaticaProfessor.php" target="blank" > <i  class="fa fa-book" > Gabarito </i></a>

                          <a href="ExibirResultadoAlunoAtividade.php" target="blank" > <i class="fa fa-laptop"> Objetivo </i> </a>
                          
                          <button name="botao-inicio"> <i class="fa fa-home"></i> Home </button>
                          
                           
                         
                        </div>


    <div class="main-editor">
        <button class="btn">Run</button>
        <div class="first" contenteditable>
            Coloque o código Aqui!!
            
        </div>
        <iframe class="second">
        </iframe>
    </div>
</form>
    <script src="editor.js"></script>

</body>
</html>

<style type="text/css">
    * {
  box-sizing: border-box;
  padding: 0;
  margin: 0;
}
body
{
  background: black;
}


.btn {
  position:fixed;
  right:0;
   padding: 0.4rem;
  width: 4rem;
  background: rgb(0, 0, 0);
  color: gold;
  font-size: 1rem;
  outline:none;
  cursor:pointer;
   height:90vh;
}
.btn:hover{
   color:white;
   background: blue;
}


.main-editor {
  background: rgba(0, 0, 0, 0.91);
  display: flex;
  width: 100%;
  padding: 1rem;
  box-shadow:0 2px 3px black;
  position:fixed;
  height:100vh;
   justify-content: center;
    align-items: center;
  border: 7px solid #36383f;
}

.first {
  background-color: #ffffff;
  width: 50%;
  overflow-x: hidden;
  overflow-y: auto;
  white-space: pre;
  box-shadow: 0 1px 1px rgb(22, 22, 22);
  outline: none;
  padding: 0.4rem;
  height: 90vh;
}

.second {
  background-color: rgb(255, 255, 255);
  width: 50%;
  overflow-y: auto;
  white-space: pre;
  right: 0;
  box-shadow: 0 1px 1px rgb(22, 22, 22);
  padding: 0.4rem;
  height: 90vh;
}


    /*======================BOTÃO ============================================*/


:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;/*cor antes era #707B7C */
  --color-secondary: red;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}



.multi-button {
  display: flex;
  width: 40%;
  box-shadow: var(--shadow) 4px 4px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  /*text-transform: lowercase;*/
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus { 
  flex-grow: 2;
  color: black; /* Cor do icone ao passar o mouse sobre*/
  outline: none;
  text-shadow: none;
  background-color: gray;
}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}

/*==========================*/


.multi-button a {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  /*text-transform: lowercase;*/
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button a + a {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button a:hover,
.multi-button a:focus { 
  flex-grow: 2;
  color: black; /* Cor do icone ao passar o mouse sobre*/
  outline: none;
  text-shadow: none;
  background-color: gray;
}

.multi-button a:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover a:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button a:active {
  transform: translateY(var(--border-size));
}



</style>