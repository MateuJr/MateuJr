<?php 
session_start();
$x='';
if ($_SESSION['tipo'] =='PROFESSOR') {
	$x='';
}else
{
	$x='hidden;';
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Menu Principal</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="menu-bar">

		<ul>

			<li class="active"><a href="#"><i class="fa fa-home"></i> Home</a></li>
			<li><a href="#"><i class="fa fa-user"></i>Sobre</a>
				<div class="sub-menu-1">
					<ul>
						<li><a href="#">Objetivo</a></li>
						<li><a href="#">Visão</a></li>
						<li><a href="#">Equipe Técnica</a></li>
						<li><a href="#">Enviar Mensagem</a></li>
					</ul>
				</div>

			</li>
			<li><a href="#"><i class="fa fa-clone"></i>Aluno</a>

				<div class="sub-menu-1">
					<ul>
						<li><a href="#">Programar</a></li>
						<li class="hover-me"><a href="#">Atividade Professor</a><i class="fa fa-angle-right"></i>
							<div class="sub-menu-2">

								<ul>
									<li><a href="#">Form</a></li>
									<li><a href="#">Imagens</a></li>
									<li><a href="#">Tabela</a></li>
								</ul>

							</div>
						</li>

						<li><a href="#">Alterar Dados</a></li>
						<li><a href="#">Mudar Usuário/Senha</a></li>
						
					</ul>
				</div>

			</li>
			<li><a href="#"><i class="fa fa-users"></i>News</a></li>
			<li><a href="#"><i class="fa fa-angellist"></i>Atividade</a>
					<div class="sub-menu-1">
					<ul>
						<li><a href="#">Tema Livre</a></li>
						<li class="hover-me"><a href="#">HTML</a><i class="fa fa-angle-right"></i>
							<div class="sub-menu-2">

								<ul>
									<li><a href="ProvaLogin1.php">Formulário</a></li>
									<li><a href="#">Imagem</a></li>
									<li><a href="#">Tabelas</a></li>
									<li><a href="#">Formatação</a></li>
								</ul>

							</div>
						</li>
						<li class="hover-me"><a href="#">CSS</a><i class="fa fa-angle-right"></i>

							<div class="sub-menu-2">

								<ul>
									<li><a href="#">Div</a></li>
									<li><a href="#">Form</a></li>
									
								</ul>

							</div>



						</li>
					</ul>
				</div>
			</li>
			<li ><a style="visibility:<?php echo $x ?> " href="#" ><i class="fa fa-inr"></i>Professor</a>
			<div  class="sub-menu-1" >
					<ul>
						<li><a href="#">Meus Alunos</a></li>
						<li class="hover-me"><a href="#">Criar Teste</a><i class="fa fa-angle-right"></i>
							<div class="sub-menu-2">

								<ul>
									<li><a href="#">Atividade de Completar</a></li>
									<li><a href="Prova2.php">Inserir Questão</a></li>
									
								</ul>

							</div>
						</li>
						<li class="hover-me"><a href="#">Editar Dados</a><i class="fa fa-angle-right"></i>

							<div class="sub-menu-2">

								<ul>
									<li><a href="#">Mudar Senha</a></li>
									<li><a href="#">ADD Dados</a></li>
									<li><a href="#">Alterar Usuário</a></li>
									
								</ul>

							</div>



						</li>
					</ul>
				</div></li>
			<li><a href="Editor1.php"><i class="fa fa-edit"></i>Praticar</a></li>
			<li><a href="ListaAtividadeEstatica.php" ><i class="fa fa-phone"></i>Logout</a></li>

		</ul>

	</div>

<div class="rodape">
	<label>Usuário: <?php echo $_SESSION['usuario']; ?></label>
	 <label>Tipo: <?php echo  $_SESSION['tipo']; ?> </label>
	
</div>

</body>
</html>

<style type="text/css">
	*{
		padding:0;
		margin: 0;
	}
	.rodape
	{
		background: silver;
		width: 1150px;
		height: 50px;
		position: relative;
		top: 430px;
		display: inline-block;
		padding-right: : 10px;

	}
	body
	{
		background-image: url(p4.jpg);
		background-size: cover;
		background-position: unset;
		box-sizing: border-box;
		font-family: sans-serif;
		overflow: hidden;
		
		
	}
	.menu-bar
	{
		background: rgb(0,100,0);
		text-align: center;

	}

	.menu-bar ul
	{
		display: inline-flex;
		list-style: none;
		color: #fff;
	}

	.menu-bar ul li
	{
		width: 70px;
		margin: 8px;
		padding: 8px;
	}

	.menu-bar ul li a
	{
		text-decoration: none;
		color: #fff;
		font-size: 0.8em;

	}

	.active, .menu-bar ul li:hover
	{
		background: #2bab0d;
		border-radius: 3px;
	}

	.menu-bar .fa
	{
		margin-right: 8px;

	}

	.sub-menu-1
	{
		display: none;
	}

	.menu-bar ul li:hover .sub-menu-1
	{
		display: block;
		position: absolute;
		background: rgb(0,100,0);
		margin-top: 8px;
		margin-left: -8px;
	}

	.menu-bar ul li:hover .sub-menu-1 ul
	{
		display: block;
		margin: 5px;

	}

	.menu-bar ul li:hover .sub-menu-1 ul li
	{
		width: 150px;
		padding: 10px;
		border-bottom: 1px dotted #fff;
		background: transparent;
		border-radius: 0;
		text-align: left;
	}

	.menu-bar ul li:hover .sub-menu-1 ul li:last-child
	{
		border-bottom: none;

	}

	.menu-bar ul li:hover .sub-menu-1 ul li a:hover
	{
		color: #b2ff00;
	}

	.fa-angle-right
	{
		float: right;
	}

	.sub-menu-2
	{
		display: none;

	}
	.hover-me:hover .sub-menu-2
	{
		position: absolute;
		display: block;
		margin-top: -40px;
		margin-left: 140px;
		background: rgb(0,100,0);
	}



</style>