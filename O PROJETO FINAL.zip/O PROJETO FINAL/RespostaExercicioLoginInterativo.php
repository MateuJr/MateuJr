<?php 
session_start();
if (isset($_POST['botao-voltar'])) {
	 header('Location: EditorOnline1.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
</head>
<body>
<form action="" method="POST">
	<h1 align="center">Gabarito</h1>
	
	<div>
	  <div class="container">
	    <ul>
	      <li><a href="ExecutavelExercicioLoginInterativo.php"><i class="fa fa-arrow-left" aria-hidden="true"></i></a></li>
	     <br>
	      <li><a href="MenuPrincipalNovo.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
	    </ul>
	  </div>
	</div>

	<h4 class="txt-resp">Sua Resposta</h4>
	<h4 class="txt-gabarito">Gabarito</h4>
</form>
             <textarea name="sourceCode" id="sourceCode" class="textarea1">

<html>
<head>
<title>Hello</title>
</head>
<body>


	
<<?php echo  $_SESSION['L_6_1'];?>>Tela de Login</<?php echo  $_SESSION['L_6_2'];?>>
    <<?php echo   $_SESSION['L_7_1'];?>>Login</<?php echo  $_SESSION['L_7_2'];?>> <<?php echo   $_SESSION['L_7_3'];?> type="<?php echo  $_SESSION['L_7_4'];  ?>">
    <br>
    <<?php echo  $_SESSION['L_9_1'];?>>Senha</<?php echo  $_SESSION['L_9_2'];?>> <<?php echo $_SESSION['L_9_3']  ?> type="<?php echo $_SESSION['L_9_4']; ?>"  >
    <br>
    <<?php echo  $_SESSION['L_11_1'];  ?>>Entrar</<?php echo $_SESSION['L_11_2'];  ?>>


</body>
</html>
                        </textarea>

             <textarea name="sourceCode" id="sourceCode" class="textarea2">
<html>
<head>
<title>Hello</title>
</head>
<body>


	<h2>Tela de Login</h2>
	<label>Login</label> <input type="text"  >
	<br>
	<label>Senha</label> <input type="password"  >
	<br>
	<button>Entrar</button>

</body>
</html>
                        </textarea>


</body>
</html>

<style type="text/css">
	body
	{
		overflow: hidden;
		background: black;
	}
	.textarea1
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			top: -150px;

	}

	.textarea2
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			left: 100px;
    			top: -150px;

	}

	.txt-resp
	{
		font-size: 1.4em;
		color: red;
		position: relative;
		top: -80px;
	}

	.txt-gabarito
	{
		font-size: 1.4em;
		color: green;
		position: relative;
		left: 750px;
		top: -140px;
	}
	.btn-voltar
	{
		height: 50px;
		width: 50px;
		position: relative;
		left: 630px;
		top: 250px;
		cursor: pointer;
	}

	/*======================= BOTÃO =============================================*/

	ul {
  margin:0;
  padding:0;
  display:block;
  position: absolute;
  top: 50%;
  left:49%;
  transform: translate(-50%, -50%);
}

ul li {
  list-style:none;
  margin: 0 15px;
}

ul li a {
  position: relative;
  display: block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  background: #171515;
  border-radius: 50%;
  font-size: 30px;
  color: #666;
  transition: .5s;
}

ul li a:before {
  content: '';
  position: absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
  border-radius:50%;
  background: #d35400;
  transition: .5s;
  transform: scale(.9);
  z-index: -1;
}

ul li a:hover:before {
  transform: scale(1.2);
  box-shadow: 0 0 15px #d35400;
  filter: blur(3px);
}

ul li a:hover {
  color: #ffa502;
  box-shadow: 0 0 15px #d35400;
  text-shadow: 0 0 15px #d35400;
}
</style>