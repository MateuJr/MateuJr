<?php 

session_start();

$var_nome_professor=$_SESSION['sessao_nome_prof_aux'];
$var_nome_IE=$_SESSION['sessao_nome_IE_aux'];
$var_nome_disciplina=$_SESSION['sessao_nome_disciplina_aux'];

/*-------------------------------------------------------------------------------------------------------*/

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

/*-----------------------------------------------------------------------------------------------*/

	$sql_serial_atividade="SELECT max(id_atividade) as max_id from tabela_atividade where tipo='ESTÁTICO'";

	if (!$mysqli -> query( $sql_serial_atividade))
			       {
			            echo("Error description: " . $mysqli -> error);
			           
			    }else
			    {
			      $sql_resultado_serial_atividade = $mysqli-> query($sql_serial_atividade);
			     
			      
			    }

			    	while ($dado_serial_atividade = $sql_resultado_serial_atividade-> fetch_array())
				{

					 $_SESSION['sessao_serial_aux']=$dado_serial_atividade['max_id'];
					
					
				}

				$serial_atividade =$_SESSION['sessao_serial_aux'];

/*-------------------------------------SALVAR-------------------------------------------------------------*/

	if (isset($_POST['btn-salvar'])) // Caso o botão Salvar seja pressionado
	 {
		$var_titulo=$_POST['campo-titulo-atividade'];
		$var_objetivo=$_POST['campo-objetivo-atividade'];
		$var_dica =$_POST['campo-dica-atividade'];
		$var_assunto=$_POST['combo-assunto'];
		$var_id =$serial_atividade;

		$var_gabarito =$_POST['sourceCode'];
		
		// Acima cada variável recebe os dados que serão necessários para serem inseridos na tabela atividade_Estática 

		$sql_add_atividade = "INSERT INTO tabela_atividade_estatica(dica, objetivo, assunto, titulo_atividade, id_atividade)
		     VALUES ('$var_dica',' $var_objetivo',' $var_assunto',' $var_titulo',' $var_id')";

		 // O código acima é responsável por fazer a inserção dos dados na tabela atividade_Estática
		     
		                        if (mysqli_query($mysqli, $sql_add_atividade))
		                    {
		                          
		                      
		                    } else {
		                          echo "Error: " . $sql_add_atividade . "<br>" . mysqli_error($mysqli);

		                          //Caso seja encontrado algum erro será exibido na tela o motivo do mesmo.
		                         
		                    }

		         $sql_busca="SELECT id_atividade_estatica from tabela_atividade_estatica
		         where id_atividade='$var_id'";
		         
		         // O  código acima é responsável por selecionar o ID da atividade que consta na tabela estática.

		         if (!$mysqli -> query( $sql_busca))
			       {
			            echo("Error description: " . $mysqli -> error);
			           
			    }else
			    {
			      $sql_result = $mysqli-> query($sql_busca);
			     
			      // a variável sql_Result esta recebendo os dados da consulta feita anteriormente.
			    }

			    $numero='';

			    	while ($dado = $sql_result-> fetch_array())
				{

					 $numero=$dado['id_atividade_estatica'];
					
					// A variável número esta armazenando o ID da atividade que esta sendo cadastrada,pois, será importante saber este ID quando for salvar o gabarito da atividade.
				}


				$sql_add_gabarito = "INSERT INTO tabela_gabarito_estatico (id_atividade_estatica,gabarito)
		     VALUES ('$numero',' $var_gabarito')";

		     // O código acima é responsável por inserir o gabarito da atividade que esta sendo cadastrada.

		                        if (mysqli_query($mysqli, $sql_add_gabarito))
		                    {
		                          
		                       header('Location: MenuPrincipalNovo.php');

		                       // Caso não haja nenhum erro durante a inserção dos dados na tabela gabarito outra janela será aberta para o usuário.
		                       $_SESSION['enviar_titulo']='';
								$_SESSION['enviar_objetivo']='';
								$_SESSION['enviar_dica']='';
								$_SESSION['enviar_assunto']='';
								$_SESSION['enviar_serial']='';

								$_SESSION['voltar_titulo']='';
							 	$_SESSION['voltar_objetivo']='';
							 	$_SESSION['voltar_dica']='';
							 	$_SESSION['voltar_assunto']='';
							 	 $_SESSION['voltar_gabarito']='';
		                  
		                    } else {
		                    	
		                          echo "Error: " . $sql_add_gabarito . "<br>" . mysqli_error($mysqli);

		                          // Caso haja algum erro durante a inserção dos dados na tabela gabarito o mesmo será exibido na tela.
		                         
		                    }




	}

/*----------------------------------------VISUALIZAR-------------------------------------------------------*/

if (isset($_POST['btn-Visualizar']))
 {
	    $var_titulo=$_POST['campo-titulo-atividade'];
		$var_objetivo=$_POST['campo-objetivo-atividade'];
		$var_dica =$_POST['campo-dica-atividade'];
		$var_assunto=$_POST['combo-assunto'];
		$var_id =$serial_atividade;

		$_SESSION['enviar_titulo']=$var_titulo;
		$_SESSION['enviar_objetivo']=$var_objetivo;
		$_SESSION['enviar_dica']=$var_dica;
		$_SESSION['enviar_assunto']=$var_assunto;
		$_SESSION['enviar_serial']=$var_id;

		$_SESSION['enviar_nome_prof']=$_SESSION['sessao_nome_prof_aux'];

		$_SESSION['enviar_IE']=$_SESSION['sessao_nome_IE_aux'];
		$_SESSION['enviar_disciplina']=$_SESSION['sessao_nome_disciplina_aux'];

		$_SESSION['enviar_gabarito']= $_POST['sourceCode'];
		

		header('Location: PreVisualizarAtividade.php');



}

/*----------------------------------------------------------------------------------------*/
$titulo_volta='';
$objetivo_volta='';
$dica_volta='';
$assunto_volta='Selecione...';

$GABARITO='';

		
	 	if ( !empty($_SESSION['voltar_titulo']) or !empty($_SESSION['voltar_objetivo']) )
	 	 {
	 		

			 	$titulo_volta=$_SESSION['voltar_titulo'];
			 	$objetivo_volta=$_SESSION['voltar_objetivo'];
			 	$dica_volta=$_SESSION['voltar_dica'];
			 	$assunto_volta=$_SESSION['voltar_assunto'];
			 	$GABARITO= $_SESSION['voltar_gabarito'];
	 	}


	 	if (isset($_POST['btn-excluir']))
	 	 {
	 			$_SESSION['voltar_titulo']='';
			 	$_SESSION['voltar_objetivo']='';
			 	$_SESSION['voltar_dica']='';
			 	$_SESSION['voltar_assunto']='';
			 	 $_SESSION['voltar_gabarito']='';
	 		 header('Location: MenuPrincipalNovo.php');
	 	}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Cadastramento Atividade</title>
</head>
<body>
	<form action="" method="POST">
<div class="shade">
		<div class="blackboard">
				<div class="form">
						
						<div  class="teste" >

								<p>
										<label>Serial da Atividade: </label>
										<input type="text" 
										 disabled="" name="campo-serial-atividade"
										 value=<?php echo $serial_atividade; ?> />

										<label class="texto-3">Professor: <?php echo $var_nome_professor; ?>
										 </label>
										
										 <br>
										<label>Instituto de Ensino: <?php echo $var_nome_IE; ?> </label>
										

										<label class="texto-2">Disciplina: <?php echo $var_nome_disciplina; ?> </label>
										
								</p>
								

						</div>
						
						<div class="teste">
							<fieldset>
					    	<legend><label>Complete o cadastro da Atividade:</label></legend>
								<p>
										<label>Titulo da Atividade: </label>
										<input type="text" maxlength="250"
										 name="campo-titulo-atividade"
										 placeholder="Insira um Título"
										 value="<?php echo $titulo_volta; ?>" >


										<label>Dica: </label>
										<input type="text"
										 name="campo-dica-atividade"
										 placeholder="Insira uma Dica"
										 value="<?php echo $dica_volta; ?>" >
								<br><br>
										<label>Objetivo: </label>
										<input type="text"
										 name="campo-objetivo-atividade"
										 placeholder="Insira um Objetivo"
										 value="<?php echo $objetivo_volta ?>" >

										<label>Assunto:</label> <select
										 class="combo-estilo"
										 name="combo-assunto" >
										    <option ><?php echo $assunto_volta; ?></option>
										    <option value="FORMULÁRIO">Formulário</option>
										    <option value="TABELA">Tabela</option>
										    <option value="LISTA">Lista</option>
										    <option value="FORMATAÇÃO">Formatação</option>
										  </select>


								</p>
							</fieldset>

					    </div>

					    <fieldset>
					    	<legend><label>Ações:</label></legend>
						<p class="wipeout">
								<input type="submit"
								 value="Salvar Atividade"
								 name="btn-salvar" />

								 <input type="submit"
								 value="Visualizar Atividade"
								 name="btn-Visualizar" />

								  <input type="submit"
								 value="Excluir Atividade"
								 name="btn-excluir" />

								 
						</p>

						</fieldset>

						


						<br><br>
	<div class="painel-Gabarito">
		<label>Insira o Código aqui!</label>
		<textarea name="sourceCode" id="sourceCode" placeholder="Insira o Código aqui" onkeypress="runCode();" >
		
			 </textarea>
	</div>

			<div class="a" >
				<label>Resultado!</label>
					<iframe   name="targetCode" id="targetCode"  ></iframe>

			</div>
			<br><br>

			
				</div>
		</div>
</div>
</form>
</body>
</html>
<script type="text/javascript">
            function runCode()
            {
                var content = document.getElementById('sourceCode').value;
                var iframe = document.getElementById('targetCode');
                iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
                iframe.document.open();
                iframe.document.write(content);
                iframe.document.close();
                return false;
            }
            runCode();
        </script>

<style type="text/css">
	body {
		height: 100%;
		background: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/50598/concrete-wall-background.jpg) center center fixed;
		background-size: cover;
		overflow: hidden;
}
	.teste
	{
		display: inline;
		background: red;
	}

	.texto-2
	{
		position: relative;
		left: 156px;
	}

	.texto-3
	{
		position: relative;
		left: 100px;
	}

	.combo-estilo
{
	
	font-size: 1.4em;
	width: 250px;
	border: none;
	
	vertical-align: middle;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.7);
		text-align: center;
		background: none;
		cursor: pointer;
}

	.wipeout
	{
		display: inline-block;
	}

	

.shade {
		overflow: auto;
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		background-image: linear-gradient( 150deg, rgba(0, 0, 0, 0.65), transparent);
}

.blackboard {
		position: relative;
		top: -50px;
		width: 1150px;
		height: 950px;
		margin: 7% auto;
		border: tan solid 12px;
		border-top: #bda27e solid 12px;
		border-left: #b19876 solid 12px;
		border-bottom: #c9ad86 solid 12px;
		box-shadow: 0px 0px 6px 5px rgba(58, 18, 13, 0), 0px 0px 0px 2px #c2a782, 0px 0px 0px 4px #a58e6f, 3px 4px 8px 5px rgba(0, 0, 0, 0.5);
		background-image: radial-gradient( circle at left 30%, rgba(34, 34, 34, 0.3), rgba(34, 34, 34, 0.3) 80px, rgba(34, 34, 34, 0.5) 100px, rgba(51, 51, 51, 0.5) 160px, rgba(51, 51, 51, 0.5)), linear-gradient( 215deg, transparent, transparent 100px, #222 260px, #222 320px, transparent), radial-gradient( circle at right, #111, rgba(51, 51, 51, 1));
		background-color: #333;
}

.blackboard:before {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 100%;
		height: 100%;
		background-image: linear-gradient( 175deg, transparent, transparent 40px, rgba(120, 120, 120, 0.1) 100px, rgba(120, 120, 120, 0.1) 110px, transparent 220px, transparent), linear-gradient( 200deg, transparent 80%, rgba(50, 50, 50, 0.3)), radial-gradient( ellipse at right bottom, transparent, transparent 200px, rgba(80, 80, 80, 0.1) 260px, rgba(80, 80, 80, 0.1) 320px, transparent 400px, transparent);
		border: #2c2c2c solid 2px;
		content: "Cadastrando Atividade Parte 2/2";
		font-family: 'Permanent Marker', cursive;
		font-size: 2.2em;
		color: rgba(238, 238, 238, 0.7);
		text-align: center;
		padding-top: 20px;
}

.form {
		padding: 70px 20px 20px;

}

p {
		position: relative;
		margin-bottom: 1em;
}

label {
		vertical-align: middle;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.7);
}

p:nth-of-type(5) > label {
		vertical-align: top;
}

input,
textarea {
		vertical-align: middle;
		padding-left: 10px;
		background: none;
		border: none;
		font-family: 'Permanent Marker', cursive;
		font-size: 1.6em;
		color: rgba(238, 238, 238, 0.8);
		line-height: .6em;
		outline: none;

}

textarea {
		height: 120px;

		font-size: 1.4em;
		line-height: 1em;
		resize: none;
}

input[type="submit"] {
		cursor: pointer;
		color: rgba(238, 238, 238, 0.7);
		line-height: 1em;
		padding: 20px;
}

input[type="submit"]:focus {
		background: rgba(238, 238, 238, 0.2);
		color: rgba(238, 238, 238, 0.2);
}

::-moz-selection {
		background: rgba(238, 238, 238, 0.2);
		color: rgba(238, 238, 238, 0.2);
		text-shadow: none;
}

::selection {
		background: rgba(238, 238, 238, 0.4);
		color: rgba(238, 238, 238, 0.3);
		text-shadow: none;
}

/*----------------------------- GABARITO ---------------------------------------------------*/

iframe {
    			border: 6px solid #ddd;
    			height: 320px;
    			width: 100%;
    			background: white;	  
			}

textarea {
    			border: 6px solid rgba(238, 238, 238, 0.8);
    			height: 300px;
    			width: 100%;
    			background: none;	  
			}

	.painel-Gabarito
	{
		position: relative;
		width: 500px;
		height: 300px;


	}

	.a
	{
		position: relative;
		width: 500px;
		height: 390px;
		top: -308px;
		left: 550px;
		
	}

</style>