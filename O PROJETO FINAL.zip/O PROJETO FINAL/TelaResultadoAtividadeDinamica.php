<?php 
session_start();

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

$AbrirTag='<';
$FinalTag='>';
$FecharTag='</';

echo "<br> $FecharTag <br>";
/*$resp='h1';*/
$Linha1='';
$resultado='';
$Linha1Fase1=''; $Linha1Fase2='';
/*
$resp2='input';
$resp3='text';
*/

$Linha1_Finalizada='';
$Linha1_PrimeiraParte='';
$Linha1_SegundaParte='';

$Texto='';

/*$palavra='CLIENTES:';*/
 	  $mysqli = new mysqli($host,$usuario,$senha,$bd);

      if ($mysqli-> connect_errno) 
      echo "Falha na Conexão: (".$mysqli-> connect_errno.")".$mysqli-> connect_errno;

  	  $variavel =$_SESSION['ID_PROVA_ALUNO'];
      $id=$variavel;
      $consulta_tabela_prova = "SELECT id_prova,nome_prof,qtd_linhas,titulo_exercicio FROM tabela_prova WHERE id_prova=$id";
      $con_tabela_prova = $mysqli-> query($consulta_tabela_prova) or die($mysqli-> erro);

      
 $consulta_tabela_linha1 = "SELECT fase1,fase2,id_linha FROM tabela_linha1 WHERE id_prova=$id";
      $con_tabela_linha1 = $mysqli-> query( $consulta_tabela_linha1) or die($mysqli-> erro);
      
      $consulta_tabela_linha2 = "SELECT fase1,fase2,id_linha FROM tabela_linha2 WHERE id_prova=$id";
      $con_tabela_linha2 = $mysqli-> query( $consulta_tabela_linha2) or die($mysqli-> erro);

       $consulta_tabela_linha3 = "SELECT fase1,fase2,id_linha FROM tabela_linha3 WHERE id_prova=$id";
      $con_tabela_linha3 = $mysqli-> query( $consulta_tabela_linha3) or die($mysqli-> erro);

      $consulta_tabela_linha4 = "SELECT fase1,fase2,id_linha FROM tabela_linha4 WHERE id_prova=$id";
      $con_tabela_linha4 = $mysqli-> query( $consulta_tabela_linha4) or die($mysqli-> erro);
/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

                                /*       L I N H A  1            */

/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

    while ($dado_tabela_linha1 = $con_tabela_linha1-> fetch_array())

    {

        $Linha1Fase1=$dado_tabela_linha1['fase1'];

         $Linha1Fase2=$dado_tabela_linha1['fase2'];

         /*echo "<br>O que tem la->>  $Linha1Fase2";*/

        if ($Linha1Fase1==1)
       {
        
              $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha1 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto= $dado_tabela_tipo1 ["texto"];
                     
                  }

        $resultado=$AbrirTag."".$_SESSION['combo_p1']."".$FinalTag;
        $resultado2=$FecharTag."".$_SESSION['combo_p2']."".$FinalTag;

        $Linha1_PrimeiraParte=$resultado."".$Texto."".$resultado2;


      }

      if ($Linha1Fase1==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p1']." type= ".$_SESSION['combo_c1']."".$FinalTag;
        $Linha1_PrimeiraParte=$resultado;

      }


       if ($Linha1Fase2==1)
       {
        
         $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha1 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto= $dado_tabela_tipo1 ["texto"];
                     
                  }


        $resultado=$AbrirTag."".$_SESSION['combo_p3']."".$FinalTag;

        $resultado2=$FecharTag."".$_SESSION['combo_p4']."".$FinalTag;

        $Linha1_SegundaParte=$resultado."".$Texto."".$resultado2;


      }

       if ($Linha1Fase2==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p3']." type= ".$_SESSION['combo_c2']."".$FinalTag;
        $Linha1_SegundaParte=$resultado;

      }

       
    }

   

    /*$total=$FecharTag."".$resp."".$FinalTag;*/

    $Linha1_Finalizada=$Linha1_PrimeiraParte."".$Linha1_SegundaParte;

  



/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

                                /*       L I N H A  2            */

/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
$Linha2Fase1=''; $Linha2Fase2=''; $Texto_Linha_2='';  $Linha2_PrimeiraParte=''; $Linha2_SegundaParte=''; $Linha2_Finalizada='';



while ($dado_tabela_linha2 = $con_tabela_linha2-> fetch_array())

    {

        $Linha2Fase1=$dado_tabela_linha2['fase1'];

         $Linha2Fase2=$dado_tabela_linha2['fase2'];

         /*echo "<br>O que tem la->>  $Linha1Fase2";*/

        if ($Linha2Fase1==1)
       {
        
              $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha2 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_2= $dado_tabela_tipo1 ["texto"];
                     
                  }

        $resultado=$AbrirTag."".$_SESSION['combo_p5']."".$FinalTag;
        $resultado2=$FecharTag."".$_SESSION['combo_p6']."".$FinalTag;

        $Linha2_PrimeiraParte=$resultado."".$Texto_Linha_2."".$resultado2;


      }

      if ($Linha2Fase1==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p5']." type= ".$_SESSION['combo_c3']."".$FinalTag;
        $Linha2_PrimeiraParte=$resultado;

      }


       if ($Linha2Fase2==1)
       {
        
         $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha2 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_2= $dado_tabela_tipo1 ["texto"];
                     
                  }
                  

        $resultado=$AbrirTag."".$_SESSION['combo_p7']."".$FinalTag;

         $resultado2=$FecharTag."".$_SESSION['combo_p8']."".$FinalTag;

        $Linha2_SegundaParte=$resultado."".$Texto_Linha_2."".$resultado2;


      }

       if ($Linha2Fase2==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p7']." type= ".$_SESSION['combo_c4']."".$FinalTag;
        $Linha2_SegundaParte=$resultado;

      }

        /*echo "<br>O que tem la->>  $Linha1Fase2";*/
    }
$Linha2_Finalizada=$Linha2_PrimeiraParte."".$Linha2_SegundaParte;




/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

                                /*       L I N H A  3            */

/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
$Linha3Fase1=''; $Linha3Fase2=''; $Texto_Linha_3='';  $Linha3_PrimeiraParte=''; $Linha3_SegundaParte=''; $Linha3_Finalizada='';



while ($dado_tabela_linha3 = $con_tabela_linha3-> fetch_array())

    {

        $Linha3Fase1=$dado_tabela_linha3['fase1'];

         $Linha3Fase2=$dado_tabela_linha3['fase2'];

      

        if ($Linha3Fase1==1)
       {
        
              $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha3 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_3= $dado_tabela_tipo1 ["texto"];
                     
                  }

        $resultado=$AbrirTag."".$_SESSION['combo_p9']."".$FinalTag;
        $resultado2=$FecharTag."".$_SESSION['combo_p10']."".$FinalTag;

        $Linha3_PrimeiraParte=$resultado."".$Texto_Linha_3."".$resultado2;


      }

      if ($Linha3Fase1==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p9']." type= ".$_SESSION['combo_c5']."".$FinalTag;
        $Linha3_PrimeiraParte=$resultado;

      }


       if ($Linha3Fase2==1)
       {
        
         $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha3 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_3= $dado_tabela_tipo1 ["texto"];
                     
                  }
                  

        $resultado=$AbrirTag."".$_SESSION['combo_p11']."".$FinalTag;

         $resultado2=$FecharTag."".$_SESSION['combo_p12']."".$FinalTag;

        $Linha3_SegundaParte=$resultado."".$Texto_Linha_3."".$resultado2;


      }

       if ($Linha3Fase2==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p11']." type= ".$_SESSION['combo_c6']."".$FinalTag;
        $Linha3_SegundaParte=$resultado;

      }

        
    }
$Linha3_Finalizada=$Linha3_PrimeiraParte."".$Linha3_SegundaParte;



/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

                                /*       L I N H A  4            */

/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
$Linha4Fase1=''; $Linha4Fase2=''; $Texto_Linha_4='';  $Linha4_PrimeiraParte=''; $Linha4_SegundaParte=''; $Linha4_Finalizada='';



while ($dado_tabela_linha4 = $con_tabela_linha4-> fetch_array())

    {

        $Linha4Fase1=$dado_tabela_linha4['fase1'];

         $Linha4Fase2=$dado_tabela_linha4['fase2'];

      

        if ($Linha4Fase1==1)
       {
        
              $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha4 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_4= $dado_tabela_tipo1 ["texto"];
                     
                  }

        $resultado=$AbrirTag."".$_SESSION['combo_p13']."".$FinalTag;
        $resultado2=$FecharTag."".$_SESSION['combo_p14']."".$FinalTag;

        $Linha4_PrimeiraParte=$resultado."".$Texto_Linha_4."".$resultado2;


      }

      if ($Linha4Fase1==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p13']." type= ".$_SESSION['combo_c7']."".$FinalTag;
        $Linha4_PrimeiraParte=$resultado;

      }


       if ($Linha4Fase2==1)
       {
        
         $consulta_tabela_tipo1 = "SELECT texto FROM tabela_tipo1 WHERE id_linha=( SELECT id_linha FROM tabela_linha4 WHERE id_prova=$id) ";
                $con_tabela_tipo1 = $mysqli-> query( $consulta_tabela_tipo1) or die($mysqli-> erro);

                  while ($dado_tabela_tipo1 = $con_tabela_tipo1-> fetch_array())
                  { 
                     $Texto_Linha_4= $dado_tabela_tipo1 ["texto"];
                     
                  }
                  

        $resultado=$AbrirTag."".$_SESSION['combo_p15']."".$FinalTag;

         $resultado2=$FecharTag."".$_SESSION['combo_p16']."".$FinalTag;

        $Linha4_SegundaParte=$resultado."".$Texto_Linha_4."".$resultado2;


      }

       if ($Linha4Fase2==2)
       {
        
        $resultado=$AbrirTag."".$_SESSION['combo_p15']." type= ".$_SESSION['combo_c8']."".$FinalTag;
        $Linha4_SegundaParte=$resultado;

      }

        
    }
$Linha4_Finalizada=$Linha4_PrimeiraParte."".$Linha4_SegundaParte;

/*===============================================================================================================================================

================================================================================================================================================*/
if (isset($_POST['botao-resposta'])) {
  header("location: GabaritoAtividadeDinamicaAluno.php");
}

if (isset($_POST['botao-praticar'])) {
  header("location: ModoLivre.php");
}

if (isset($_POST['botao-home'])) {
  header("location: MenuPrincipalNovo.php");
}

$_SESSION['linha_1']=$Linha1_Finalizada;
$_SESSION['linha_2']=$Linha2_Finalizada;
$_SESSION['linha_3']=$Linha3_Finalizada;
$_SESSION['linha_4']=$Linha4_Finalizada;
?>


      <!DOCTYPE html>
      <html>
      <head>
        <title></title>
      </head>
      <body>
        <form action="" method="POST">
      <div class="multi-button">
                          <button name="botao-resposta">Gabarito</button>
                          <button name="botao-praticar">Praticar</button>
                          <button name="botao-home">Home</button>
                          <button onclick="runCode();" type="button"  value="Executar" class="btn-executar">Compilar</button>
                        </div>
          <strong>Entrada</strong>
          <textarea name="sourceCode" id="sourceCode">
<html>
<head>
<title></title>
</head>
<body>

 <?php echo $Linha1_Finalizada; ?>

  <?php echo $Linha2_Finalizada; ?>

  <?php echo $Linha3_Finalizada; ?>

   <?php echo $Linha4_Finalizada; ?>

</body>
</html>
                        </textarea>

<strong>Saída</strong><iframe name="targetCode" id="targetCode"></iframe>

        <script type="text/javascript">
            function runCode()
            {
                var content = document.getElementById('sourceCode').value;
                var iframe = document.getElementById('targetCode');
                iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
                iframe.document.open();
                iframe.document.write(content);
                iframe.document.close();
                return false;
            }
            runCode();
        </script>
      </form>
      </body>
      </html>


      <style type="text/css">

        body
        {
          background: black;
        }
      textarea {
          border: 12px solid green;
          height: 500px;
          width: 500px;    
          position: relative;
          top: 50px;
          color: green;
          

      }
      iframe
      {

            border: 12px solid red;
          height: 500px;
          width: 500px;    
          position: relative;
          top: 50px;
          color: white;
          background: white;

      }
            .btn-executar{
                cursor: pointer;
            }

            strong
            {
              color: red;
              position: relative;
              top: -500px;
              left: 250px;
              margin: 20px;
            }

            #targetCode
            {
              color: red;
            }

    /*======================BOTÃO ============================================*/


:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;
  --color-secondary: #707B7C;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}



.multi-button {
  display: flex;
  width: 40%;
  box-shadow: var(--shadow) 4px 4px;
  position: relative;
  top: 20px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  top: -40px;
  right: -240px;
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  text-transform: lowercase;
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background-color: var(--color-secondary);
}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}
      </style>