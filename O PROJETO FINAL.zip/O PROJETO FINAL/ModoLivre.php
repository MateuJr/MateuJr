<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<div class="code-area">

		  <textarea  id="htmlCode" placeholder="HTML Code" 
		            oninput="showPreview()"></textarea>
		  <textarea id="cssCode" placeholder="CSS Code" 
		            oninput="showPreview()"></textarea>
		  <textarea   id="jsCode" placeholder="JavaScript Code" 
		            oninput="showPreview()"></textarea>				
	</div>

	<div class="preview-area" >

	  <iframe  id="preview-window" ></iframe>

	</div>

	<script type="text/javascript">
				function showPreview(){
			  var htmlCode = document.getElementById("htmlCode").value;
			  var cssCode = document.getElementById("cssCode").value;
			  var jsCode = ""+document.getElementById("jsCode").value+"";
			  var frame = document.getElementById("preview-window").contentWindow.document;
			  frame.open();
			  frame.write(htmlCode+cssCode+jsCode);
			  frame.close();
			}

	</script>
</body>
</html>

<style type="text/css">
	* {
  margin: 0px;
  padding: 0px;
  box-sizing: border-box;
}
body {
  height: 100vh;
  display: flex;

}
.code-area {
  display: flex;
  flex-direction:column;
  width: 50%;
  border-right:5px solid #555;
  background: black;
  resize: both;
}
.code-area textarea {
  /*resize: none;*/
  outline: none;
  width: 100%;
  height: 33.33%;
  font-size: 18px;
  padding: 10px;
}

iframe
{
	background: gray;
	resize: both;
}

.preview-area {
  width: 50%;
}
.preview-area iframe {
  width: 100%;
  height: 100%;
  border: 5px solid black;
}

textarea
{
	background: black;
	color: white;
	resize: both;
}

</style>