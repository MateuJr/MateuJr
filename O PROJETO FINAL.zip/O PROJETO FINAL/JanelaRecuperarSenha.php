<?php

session_start();

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

$VAR_resposta_pergunta_1='';


$habilitar_pergunta1='';
$habilitar_pergunta2='style="display:none;"';
$habilitar_pergunta3='style="display:none;"';
$habilitar_pergunta4='style="display:none;"';
$habilitar_pergunta5='style="display:none;"';
$habilitar_pergunta6='style="display:none;"';

$var_class_etapa2='etapa2-APAGADO';
$var_class_etapa3='etapa3-APAGADO';
$var_class_etapa4='etapa4-APAGADO';
$var_class_etapa5='etapa5-APAGADO';
$var_class_etapa6='etapa6-APAGADO';

if (isset($_POST['btn-Pergunta-1']))

 {
			

		$VAR_resposta_pergunta_1=$_POST['radio_perfil'];

		

		$_SESSION['SESSION_VAR_PERFIL']=$VAR_resposta_pergunta_1;

		$var_class_etapa2='etapa2-ACESO';

		$habilitar_pergunta1='style="display:none;"';
		$habilitar_pergunta2='';
}

/*===============================================================================================================================

											P E R G U N T  A  2

===============================================================================================================================
*/

$var_msg_usuario='';

if (isset($_POST['btn-Pergunta-2']))

 {
 		$_SESSION['SESSION_VAR_USUARIO']= $_POST['campo-nome_usuario'];
 		$variavel_nome_user='';
 		if ($_SESSION['SESSION_VAR_USUARIO'] != '')
 		 {
 		 	$variavel_nome_user=$_SESSION['SESSION_VAR_USUARIO'];

 		$SQL_DADOS_Usuario= "SELECT * FROM tabela_usuario WHERE usuario = ' $variavel_nome_user '  ";

		      if (!$mysqli -> query( $SQL_DADOS_Usuario))
		       {
		            echo("Error description: " . $mysqli -> error);
		            
		      }else
		      {
		        $con_DADO_USER = $mysqli-> query($SQL_DADOS_Usuario);
		      
		        
		      }

		      $variavel_Dado_USER='';

		      while ($dado_USER = $con_DADO_USER-> fetch_array())
		      {
		        $variavel_Dado_USER = $dado_USER['id_usuario'] ;
		        
		      }

		 		if ($variavel_Dado_USER !='')
		 		{		 		
		 		
				 		$var_class_etapa3='etapa3-ACESO';
				 		$var_class_etapa2='etapa2-ACESO';

						$habilitar_pergunta2='style="display:none;"';
						$habilitar_pergunta1='style="display:none;"';
						$habilitar_pergunta3='';
				}else{

					

					$var_class_etapa3='etapa3-APAGADO';
			 		$var_class_etapa2='etapa2-ACESO';
			 		$var_class_etapa1='etapa1-ACESO';

					$habilitar_pergunta2='';
					$habilitar_pergunta1='style="display:none;"';
					$habilitar_pergunta3='style="display:none;"';

					$var_msg_usuario='O usuário informado Não consta em nossa base de dados!';
				}	
	}else
	{
		$var_class_etapa3='etapa3-APAGADO';
 		$var_class_etapa2='etapa2-ACESO';
 		$var_class_etapa1='etapa1-ACESO';

		$habilitar_pergunta2='';
		$habilitar_pergunta1='style="display:none;"';
		$habilitar_pergunta3='style="display:none;"';

		$var_msg_usuario='Por Favor, insira o Nome do Usuário no campo acima!';

		
	}
 }




if ($_SESSION['SESSION_VAR_PERFIL'] != '' )
 {
	
 			if ($_SESSION['SESSION_VAR_PERFIL'] =='PROFESSOR' and $_SESSION['SESSION_VAR_USUARIO'] !='')
 	 	{
 		
 	
 	 		$var_user=$_SESSION['SESSION_VAR_USUARIO'];
 	 		

		 	$SQL_DADOS_USER_PROF= "SELECT * FROM tabela_usuario WHERE usuario = ' $var_user '  ";

		      if (!$mysqli -> query( $SQL_DADOS_USER_PROF))
		       {
		            echo("Error description: " . $mysqli -> error);
		            
		      }else
		      {
		        $con_ID_USER = $mysqli-> query($SQL_DADOS_USER_PROF);
		      
		        
		      }

		      $variavel_ID_USER='';

		      while ($dado_ID_USER = $con_ID_USER-> fetch_array())
		      {
		        $variavel_ID_USER = $dado_ID_USER['id_usuario'] ;
		        
		      }

		      
		      /*------------------------------------------------------------*/

		      $SQL_DADOS_USER_PROF= "SELECT * FROM tabela_professor WHERE id_usuario = ' $variavel_ID_USER '  ";

		      if (!$mysqli -> query( $SQL_DADOS_USER_PROF))
		       {
		            echo("Error description: " . $mysqli -> error);
		      }else
		      {
		        $con_INFO_PROF = $mysqli-> query($SQL_DADOS_USER_PROF);

		       
		        
		      }

		      $variavel_Nome_Prof='';
		      $variavel_Email_Prof='';
		      $variavel_Palavra_Prof='';



		      while ($dado_info_PROF = $con_INFO_PROF-> fetch_array())
		      {
		        

		        $variavel_Nome_Prof=trim($dado_info_PROF['nome_professor']) ;
		        $variavel_Email_Prof=trim($dado_info_PROF['email'] );
		        $variavel_Palavra_Prof=trim($dado_info_PROF['palavra_chave'] );

		      
		      }

		      

  		}elseif ($_SESSION['SESSION_VAR_PERFIL'] =='ALUNO' and $_SESSION['SESSION_VAR_USUARIO'] !='')
  		 {
  			
  			$var_user=$_SESSION['SESSION_VAR_USUARIO'];
 	 		

		 	$SQL_DADOS_USER_ALUNO= "SELECT * FROM tabela_usuario WHERE usuario = ' $var_user '  ";

		      if (!$mysqli -> query( $SQL_DADOS_USER_ALUNO))
		       {
		            echo("Error description: " . $mysqli -> error);
		            
		      }else
		      {
		        $con_ID_USER = $mysqli-> query($SQL_DADOS_USER_ALUNO);
		      
		        
		      }

		      $variavel_ID_USER='';

		      while ($dado_ID_USER = $con_ID_USER-> fetch_array())
		      {
		        $variavel_ID_USER = $dado_ID_USER['id_usuario'] ;
		        
		      }

		      

		      
		      /*----------------------------------------------------------------------------------------------------------------*/

		       $SQL_DADOS_USER_Aluno= "SELECT * FROM tabela_aluno WHERE id_usuario = ' $variavel_ID_USER '  ";

		      if (!$mysqli -> query( $SQL_DADOS_USER_Aluno))
		       {
		            echo("Error description: " . $mysqli -> error);
		      }else
		      {
		        $con_INFO_ALUNO = $mysqli-> query($SQL_DADOS_USER_Aluno);

		       
		        
		      }

		      $variavel_Nome_Aluno='';
		      $variavel_Email_Aluno='';
		      $variavel_Palavra_Aluno='';



		      while ($dado_info_Aluno = $con_INFO_ALUNO-> fetch_array())
		      {
		        

		        $variavel_Nome_Aluno=trim($dado_info_Aluno['nome_aluno']) ;
		        $variavel_Email_Aluno=trim($dado_info_Aluno['email'] );
		        $variavel_Palavra_Aluno=trim($dado_info_Aluno['palavra_chave'] );
		        
		      }

  		}
}

/*===============================================================================================================================

											P E R G U N T  A  3

===============================================================================================================================
*/


$var_msg_email='';

  if (isset($_POST['btn-Pergunta-3']))

 {

 	$var_email = $_POST['campo-email'];
 
 	if ($var_email != '')

 	 {
 		if ($_SESSION['SESSION_VAR_PERFIL'] =='PROFESSOR')
 		 {
 		 

 		 	if ($variavel_Email_Prof == $var_email)
 			 {

				
				

				$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='';
 			}

 			if ($variavel_Email_Prof != $var_email)

 			{
				
 
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-APAGADO';
		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='';
				

 				
 				$var_msg_email='O Email Inserido Não consta em nossa base de dados!';
 			}

 		}elseif($_SESSION['SESSION_VAR_PERFIL'] =='ALUNO')
 		{

 			if ($variavel_Email_Aluno == $var_email)
 			 {

 			 	$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='';

 			}else

 			{
 				

 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-APAGADO';
		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='';

 				$var_msg_email='O Email Inserido Não consta em nossa base de dados!';
 			}
 		}
 	}
 	else
 	{
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-APAGADO';
		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='';

 		$var_msg_email='Por Favor, insira o E-mail no campo acima!';
 	}


 }

/*===============================================================================================================================

											P E R G U N T  A  4

===============================================================================================================================
*/

$var_msg_palavra='';


if (isset($_POST['btn-Pergunta-4']))

 {

 	$var_palavra = $_POST['campo-palavra'];
 
 	if ($var_palavra != '')

 	 {
 		if ($_SESSION['SESSION_VAR_PERFIL'] =='PROFESSOR')
 		 {
 		 

 		 	if ($variavel_Palavra_Prof == $var_palavra)
 			 {

				
			

				$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='';
 			}

 			if ($variavel_Palavra_Prof != $var_palavra)

 			{
				
 					

 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='';
				

 				
 				$var_msg_palavra='A Palavra Chave Inserida Não consta em nossa base de dados!';
 			}

 		}elseif($_SESSION['SESSION_VAR_PERFIL'] =='ALUNO')
 		{

 			if ($variavel_Palavra_Aluno == $var_palavra)
 			 {

 			 	

				$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='';

 			}else

 			{
 				

 		

 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='';

 				$var_msg_palavra='A Palavra Chave Inserida Não consta em nossa base de dados!';
 			}
 		}
 	}
 	else
 	{
 				

 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';

		 		$var_class_etapa1='etapa1-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='';

 		$var_msg_palavra='Por Favor, insira a Palavra Chave no campo acima!';
 	}


 }
/*===============================================================================================================================

											P E R G U N T  A  5

===============================================================================================================================
*/

$var_msg_nome_completo='';
if (isset($_POST['btn-Pergunta-5']))
 {
	

 	$var_nome_completo = $_POST['campo-nome_completo'];
 $var_nome_completo= strtolower ($var_nome_completo );

 $variavel_Nome_Prof= strtolower ($variavel_Nome_Prof );

 

 	if ($var_nome_completo != '')

 	 {
 		if ($_SESSION['SESSION_VAR_PERFIL'] =='PROFESSOR')
 		 {
 		 

 		 	if ($variavel_Nome_Prof == $var_nome_completo)
 			 {

				
				

				$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';
		 		$var_class_etapa6='etapa6-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='style="display:none;"';
				$habilitar_pergunta6='';
 			}

 			if ($variavel_Nome_Prof != $var_nome_completo)

 			{
				
 					
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='';
				

 				
 				$var_msg_nome_completo='O Nome Inserido Não consta em nossa base de dados!';
 			}

 		}elseif($_SESSION['SESSION_VAR_PERFIL'] =='ALUNO')
 		{

 			$variavel_Nome_Aluno= strtolower ($variavel_Nome_Aluno );

 			if ($variavel_Nome_Aluno == $var_nome_completo)
 			 {

 			 	

			
				$var_class_etapa1='etapa1-ACESO';
 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';
		 		$var_class_etapa6='etapa6-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='style="display:none;"';
				$habilitar_pergunta6='';

 			}else

 			{
 				

 			

 			$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='';

 				$var_msg_nome_completo='O Nome Inserido Não consta em nossa base de dados!';
 			}
 		}
 	}
 	else
 	{
 				

 				$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='';

 		$var_msg_nome_completo='Por Favor, insira o Nome no campo acima!';
 	}


 }
	

/*===============================================================================================================================

											P E R G U N T  A  6

===============================================================================================================================
*/

$var_msg_senha='';

if (isset($_POST['btn-senha'])) 
{
	  $s1='';
      $s2='';
      $s1=$_POST['campo-senha'];
      $s2=$_POST['campo_confirmar_senha'];

	 if ( ($s1 == $s2) and ($s1 !='') and ($s2 !='') )
       {

        

        		$var_senha =mysqli_escape_string($mysqli,$s1);
                $var_senh=md5($var_senha);

                

                $sql_user_update = "UPDATE tabela_usuario SET
                        senha='$var_senh'
                        WHERE id_usuario=$variavel_ID_USER";


                          
             if (mysqli_query($mysqli, $sql_user_update))
               {
                   
                   $_SESSION['SESSION_VAR_PERFIL']='';

					$_SESSION['SESSION_VAR_USUARIO']='';


					$_SESSION['var_msg_email']='';
						 header('Location: TelaLogin.php');
                   

                $var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';
		 		$var_class_etapa6='etapa6-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='style="display:none;"';
				$habilitar_pergunta6='';


                } else {
                        echo "Error: " . $sql_user_update . "<br>" . mysqli_error($mysqli);
                    }


     }else
     {
     			$var_class_etapa3='etapa3-ACESO';
		 		$var_class_etapa2='etapa2-ACESO';
		 		$var_class_etapa4='etapa4-ACESO';
		 		$var_class_etapa1='etapa1-ACESO';
		 		$var_class_etapa5='etapa5-ACESO';
		 		$var_class_etapa6='etapa6-ACESO';

				$habilitar_pergunta2='style="display:none;"';
				$habilitar_pergunta1='style="display:none;"';
				$habilitar_pergunta3='style="display:none;"';
				$habilitar_pergunta4='style="display:none;"';
				$habilitar_pergunta5='style="display:none;"';
				$habilitar_pergunta6='';


     	$var_msg_senha='Verifique a senha inserida por gentileza !';
     }
}


if (isset($_POST['botao-proximo-sair']))

 {
 	$_SESSION['SESSION_VAR_PERFIL']='';

$_SESSION['SESSION_VAR_USUARIO']='';


$_SESSION['var_msg_email']='';
	 header('Location: TelaLogin.php');
}
 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js">
</head>
<body>
<form action="" method="POST">
<video autoplay muted loop id="myVideo">
  <source src="teste.mp4" type="video/mp4">
  Your browser does not support HTML5 video.
</video>

<div class="caixa-principal" >

			<h1 class="titulo-h1"> Recuperar Login/Senha</h1>


			<div class="Container-etapas">

					<div  class="etapa1-ACESO">1</div>
					<div  class=<?php echo $var_class_etapa2; ?>>2</div>
					<div  class=<?php echo $var_class_etapa3; ?>>3</div>
					<div  class=<?php echo $var_class_etapa4; ?>>4</div>
					<div  class=<?php echo $var_class_etapa5; ?>>5</div>
					<div  class=<?php echo $var_class_etapa6; ?>>6</div>

			
			</div>
			
			<br><br>

			<div class="Pergunta-1" <?php echo $habilitar_pergunta1; ?> >

					<label class="label-pergunta">Qual o tipo do seu Perfil ? </label>
					<br><br>

					<div class="div-radio">

						<input class="w3-radio" type="radio" name="radio_perfil" value="PROFESSOR" >
						<label id="label">Sou professor</label>

						<input  class="w3-radio" type="radio" name="radio_perfil" value="ALUNO">
						<label id="label">Sou aluno</label>

					</div>

					<button class="botao-proximo" name="btn-Pergunta-1"> >> </button>

			</div>

			<br><br>

			<div class="Pergunta-2" <?php echo $habilitar_pergunta2; ?>>

				<label class="label-pergunta">Qual nome do Usuário cadastrado ?</label>
				<br><br>

				<input class="input" type="text" name="campo-nome_usuario" placeholder="Insira o nome do Usuário aqui!">
				
				<button class="botao-proximo" name="btn-Pergunta-2"> >> </button>

				<div class="erro">
					
					<label class="label-erro"><?php echo $var_msg_usuario; ?></label>

				</div>
				
				
			</div>

<br><br>

			<div class="Pergunta-3" <?php echo $habilitar_pergunta3; ?>>

				<label class="label-pergunta">Qual Seu Endereço de E-mail ?</label>
				<br><br>

				<input class="input" type="text" name="campo-email" placeholder="Insira seu endereço de e-mail aqui!">

				<button class="botao-proximo" name="btn-Pergunta-3"> >> </button>

				<div class="erro">
					
					<label class="label-erro"><?php echo $var_msg_email; ?></label>

				</div>
				
			</div>

<br><br>

			<div class="Pergunta-4" <?php echo $habilitar_pergunta4; ?>>

				<label class="label-pergunta">Qual Palavra-chave foi cadastrado ?</label>
				<br><br>

				<input class="input" type="text" name="campo-palavra" placeholder="Insira a Palavra-chave aqui!">
				
				<button class="botao-proximo" name="btn-Pergunta-4"> >> </button>

				<div class="erro">
					
					<label class="label-erro"><?php echo $var_msg_palavra; ?></label>

				</div>

			</div>

<br><br>

			<div class="Pergunta-5" <?php echo $habilitar_pergunta5; ?>>

				<label class="label-pergunta">Qual Seu Nome completo ?</label>
				<br><br>

				<input class="input" type="text" name="campo-nome_completo" placeholder="Insira seu nome completo aqui!">

				<button class="botao-proximo" name="btn-Pergunta-5"> >> </button>

				<div class="erro">
					
					<label class="label-erro"><?php echo $var_msg_nome_completo; ?></label>

				</div>
				
			</div>

			<div class="Pergunta-6" <?php echo $habilitar_pergunta6; ?>>

				<label class="label-pergunta-senha">Cadastre uma senha Nova senha: </label>
				<br><br>
				<label class="senha-label">Insira a senha </label>
				<input class="input-senha" type="password" name="campo-senha" placeholder="Insira a senha aqui!">

				<label class="senha-label">Digite novamente a senha: </label>
				<input class="input-senha" type="password" name="campo_confirmar_senha" placeholder="Insira novamente a senha aqui!">

				<button class="botao-proximo" name="btn-senha"> >> </button>

				<div class="erro">
					
					<label class="label-erro-senha"><?php echo $var_msg_senha; ?></label>

				</div>
				
			</div>
			
			<button class="botao-proximo-sair" name="botao-proximo-sair"> Sair </button>
</div>

</form>
</body>
</html>

<style type="text/css">

.botao-proximo-sair
{
	color: white;


  border-radius: 50%;
  width: 70px;
  height: 70px;
  position: fixed;
  left: 80px;
  top: 510px;

  background: #6A1B9A;
  font-size: 1.5em;
  border-color: #6A1B9A;

}

.erro
{
	position: relative;
	width: 550px;
	height: 100px;
	
	top: 20px;
}

.label-erro
{
	font-size: 1.3em;
	color: red;
	font-family: Raleway;
	text-align: center;
}

.label-erro-senha
{
	font-size: 1.3em;
	color: red;
	font-family: Raleway;
	text-align: center;
	position: relative;
	top: -70px;
}

.div-radio
{
	

	 width: 450px;
  height: 90px;
    

    border: 4px solid #6A1B9A;
  border-radius: 15px;

}
#label
{
	font-size: 1.6em;
	color: black;
	font-family: Raleway;


}

.w3-radio
{
	  border-radius: 50%;
  width: 30px;
  height:30px;
  margin: 10px;
	padding: 10px;
	cursor: pointer;
	background: red;
}
.botao-proximo
{
	color: white;


  border-radius: 50%;
  width: 70px;
  height: 70px;
  position: fixed;
  left: 560px;
  top: 520px;

  background: #6A1B9A;
  font-size: 1.5em;
  border-color: #6A1B9A;

}

.input-senha
{
	 
  width: 450px;
  height: 60px;
    

   border: 2px solid #6A1B9A;
  border-radius: 15px;
  position: relative;
  top: -90px;
}

.senha-label
{
	font-family: Raleway;
	font-size: 1.2em;
	text-align: center;
	color: black;
	margin: 10px;
	padding: 10px;
	position: relative;
	top: -70px;
}

.label-pergunta-senha
{
	font-family: Raleway;
	font-size: 1.5em;
	text-align: center;
	color: black;
	position: relative;
	top: -40px;
	left: 40px;

}

.Pergunta-6
{
	
	position: relative;
	left: 100px;
	top: -190px;
	width: 500px;
	height: 160px;
	padding: 15px;
	margin: 15px;
	
}
.Pergunta-5
{
	
	position: relative;
	left: 100px;
	top: -190px;
	width: 500px;
	height: 160px;
	padding: 10px;
	margin: 10px;
}

.Pergunta-4
{
	
	position: relative;
	left: 100px;
	top: -130px;
	width: 500px;
	height: 160px;
	padding: 10px;
	margin: 10px;
}

.Pergunta-3
{
	
	position: relative;
	left: 100px;
	top: -80px;
	width: 500px;
	height: 160px;
	padding: 10px;
	margin: 10px;
}


.Pergunta-2
{
	
	position: relative;
	left: 100px;
	top: 10px;
	width: 500px;
	height: 160px;
	padding: 10px;
	margin: 10px;
}

.Pergunta-1
{
	
	position: relative;
	left: 100px;
	top: 10px;
	width: 500px;
	height: 160px;
	padding: 10px;
	margin: 10px;
}
.label-pergunta
{
	font-family: Raleway;
	font-size: 1.5em;
	text-align: center;
	color: black;

}
.input
{
	 
  width: 450px;
  height: 60px;
    

    border: 2px solid #6A1B9A;
  border-radius: 15px;
}




.Container-etapas
{
	

	font-family: Raleway;
    
     text-align: center;
  width: 500px;
  height: 70px;
  position: relative;
  left: 50px;
  top: 30px;

 
}
/*================================================================================================================================

												 B O L I N H A

===================================================================================================================================
*/


.etapa1-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}

.etapa1-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}

.etapa2-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}
.etapa2-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}

.etapa3-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}

.etapa3-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}

.etapa4-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}

.etapa4-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}
.etapa5-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}

.etapa5-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}


.etapa6-ACESO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: #6A1B9A;
}

.etapa6-APAGADO
{
	color: white;
	font-family: Raleway;
	font-size: 1.2em;

	display: inline-block;
  margin: 10px;
  padding: 10px;

  border-radius: 50%;
  width: 50px;
  height: 50px;
  background: gray;
}

/*================================================================================================================================*/




body
{
	background: white;
	overflow: hidden;
}

/*================================================================================================================================

												 V  I  D  E  O

===================================================================================================================================
*/
	#myVideo {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%; 
  min-height: 100%;

  width: 1300px;
  height: 1100px;

  top: -210px;
  left: 410px;
 


}

.caixa-principal
{
	border-color: red;
	border-style: solid 10px ;

	width: 650px;
	height: 550px;
	position: relative;
	top: 40px;
	left: 40px;
	background: #D3D3D3;
}

.titulo-h1
{
	 
   
    font-family: Raleway;
    
     text-align: center;
     color: #6A1B9A;
     margin: 10px;
     padding: 10px;

}
</style>