<?php
session_start();

$host ="localhost";
  $usuario = "root";
  $senha = "";
  $bd = "projeto_tcc";

  $mysqli = new mysqli($host,$usuario,$senha,$bd);

      if ($mysqli-> connect_errno) 
      echo "Falha na Conexão: (".$mysqli-> connect_errno.")".$mysqli-> connect_errno;

		$consulta_id_prova = "SELECT max(id_prova) as ID  FROM tabela_prova";
        $con_id_prova = $mysqli-> query($consulta_id_prova) or die($mysqli-> erro);


	// Create connection
				$conn = mysqli_connect($host,$usuario,$senha,$bd);
				// Check connection
				if (!$conn) {
				      die("Connection failed: " . mysqli_connect_error());
				}
		 
				
$_SESSION['r1']='';
$_SESSION['texto']='';
$_SESSION['r2']='';

$variavel_combo1 ='';
$variavel_texto1 ='';
$variavel_combo2 ='';

$linha1='';
$fase1='';
$fase2='';
$x = '';
$y = '';
$z= '';
$xyz = '';

$numero_linha=1;
$fase=$_SESSION['fase'];

$habilitado='';

$habilitar_btn_visualizar='disabled=""';

$resposta_Texto=$_SESSION['texto'];


			if (isset($_POST['btn-add'])) 

			{
				$variavel_combo1 =$_POST['combo1'];
				$variavel_texto1 =$_POST['texto-campo1'];
				$variavel_combo2 =$_POST['combo2'];

				$_SESSION['texto_tipo_1'] = $_POST['texto-campo1'];

				


				

				$_SESSION['texto'] =$_POST['texto-campo1'];
				

				$x = '<'.$variavel_combo1.'>';
				$y = $variavel_texto1;
				$z= '</'.$variavel_combo2.'>';
				$xyz = $x.$y.$z;

				
				if ($fase==1)
				 {
					$fase1=$xyz;
					$_SESSION['dado_Fase1']=$fase1;

					$_SESSION['fase']=$fase +1;

					$_SESSION['Tipo_Fase1']=1;
					
				
					
				}

				if ($fase==2)
				{
					$fase2=$xyz;
					$_SESSION['dado_Fase2']=$fase2;

					$_SESSION['fase']=$fase +1;
					/*$fase=$_SESSION['fase'];*/

					$_SESSION['Tipo_Fase2']=1;
					
				}
			
				if ($_SESSION['fase'] >2)
				 {
					$habilitado='disabled=""';
				}
			
			}

				if (isset($_POST['btn-add2'])) 

			{
						

						$variavel_comb1 =$_POST['modelo2-combo3'];
						$variavel_comb2 =$_POST['modelo2-combo4'];

						
						$x = '<'.$variavel_comb1 . '  '.' type = '.$variavel_comb2.'>';

					
					
					

						if ($fase==1)
						 {
							$fase1=$x;
							$_SESSION['dado_Fase1']=$fase1;

							$_SESSION['fase']=$fase +1;
							/*$fase=$_SESSION['fase'];*/
							$_SESSION['Tipo_Fase1']=2;
						}

						if ($fase==2)
						{
							$fase2=$x;
							$_SESSION['dado_Fase2']=$fase2;

							$_SESSION['fase']=$fase +1;
							
							$_SESSION['Tipo_Fase2']=2;
						}

						if ($_SESSION['fase'] >2)
						 {
							$habilitado='disabled=""';
						}
			}
			

					if (isset($_POST['Botao_Proxima_Linha']))
			 	{
					

					if ($_SESSION['n_linha'] ==1)

				    {
						 	if ($_SESSION['dado_Fase2']=='')
						 	 {
						 		$_SESSION['info_linha']= $_SESSION['dado_Fase1'].'<br>';
						 	 }
						 	 else
						 	 {
								$_SESSION['info_linha']= $_SESSION['dado_Fase1'].$_SESSION['dado_Fase2'].'<br>';
							 }

			/*					 $nome_professor =$_POST['campo_nome'];*/
								 $tipo1=$_SESSION['Tipo_Fase1'];
								 $tipo2=$_SESSION['Tipo_Fase2'];
								 $idProva=$_SESSION['id_prova'];

						$sql = "INSERT INTO tabela_linha1 (id_prova,fase1,fase2) VALUES ('$idProva',' $tipo1',' $tipo2')";
							
								if (mysqli_query($conn, $sql))
						{
						     /* echo "New record created successfully";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}
								/*mysqli_close($conn);*/


								$consulta_id_linha1 = "SELECT id_linha FROM tabela_linha1 WHERE id_prova=$idProva";
      							$con_id_linha1 = $mysqli-> query( $consulta_id_linha1) or die($mysqli-> erro);

      			 			while ($dado_id_linha1 = $con_id_linha1-> fetch_array())
      			 		{ 
		      			 	if (($_SESSION['Tipo_Fase1'] ==1) or ($_SESSION['Tipo_Fase2'] ==1) )
		      			 	{
		      			 		
		      			 	
		      			 		$n_linha =$dado_id_linha1 ["id_linha"];
		      			 		$n=1;
		      			 		$k=$_SESSION['texto'];
		      			 		$xt=$_SESSION['texto_tipo_1'];
		      			 		$sql = "INSERT INTO tabela_tipo1 (id_tipo1,id_linha,texto) 
		      			 		VALUES ('$n',' $n_linha',' $xt')";
									
										if (mysqli_query($conn, $sql))
								{
								    /*  echo "New record created successfully";*/
								} else {
								      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
								}
								/*mysqli_close($conn);*/
							}
      			 		}

      			 		 		 $tipo1=$_SESSION['Tipo_Fase1'];
								 $tipo2=$_SESSION['Tipo_Fase2'];
								 $idProva=$_SESSION['id_prova'];
								 $xt=$_SESSION['texto_tipo_1'];


      			 		$sql = "INSERT INTO tabela_rascunho  (id_prova,fase1,fase2,texto1,linha) VALUES ('$idProva',' $tipo1',' $tipo2',' $xt',1)";
							
								if (mysqli_query($conn, $sql))
						{
						      /*echo "Dado na Tabela RASCUNHO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}



      			 		$_SESSION['info_linha1']=$_SESSION['info_linha'];

      			 		$resposta_linha_1=$_SESSION['info_linha1'];
      			 		$idProva=$_SESSION['id_prova'];

      			 		$sql = "INSERT INTO tabela_gabarito (id_prova,linha,resposta) VALUES ('$idProva',1,' $resposta_linha_1')";
							
								if (mysqli_query($conn, $sql))
						{
						      /*echo "Dado na Tabela GABARITO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}





					}

							if ($_SESSION['n_linha'] ==2)

				    {
						 	if ($_SESSION['dado_Fase2']=='')
						 	 {
						 		$_SESSION['info_linha']= $_SESSION['dado_Fase1'].'<br>';
						 	 }
						 	 else
						 	 {
								$_SESSION['info_linha']= $_SESSION['dado_Fase1'].$_SESSION['dado_Fase2'].'<br>';
							 }

			/*					 $nome_professor =$_POST['campo_nome'];*/
								 $tipo1=$_SESSION['Tipo_Fase1'];
								 $tipo2=$_SESSION['Tipo_Fase2'];
								 $idProva=$_SESSION['id_prova'];

						$sql = "INSERT INTO tabela_linha2 (id_prova,fase1,fase2) VALUES ('$idProva',' $tipo1',' $tipo2')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "New record created successfully";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}
								/*mysqli_close($conn);*/


								$consulta_id_linha2 = "SELECT id_linha FROM tabela_linha2 WHERE id_prova=$idProva";
      							$con_id_linha2 = $mysqli-> query( $consulta_id_linha2) or die($mysqli-> erro);

      			 			while ($dado_id_linha2 = $con_id_linha2-> fetch_array())
      			 		{ 
		      			 	if (($_SESSION['Tipo_Fase1'] ==1) or ($_SESSION['Tipo_Fase2'] ==1) )
		      			 	{
		      			 		
		      			 	
		      			 		$n_linha =$dado_id_linha2 ["id_linha"];
		      			 		$n=1;
		      			 		$k=$_SESSION['texto'];
		      			 		$xt=$_SESSION['texto_tipo_1'];
		      			 		$sql = "INSERT INTO tabela_tipo1 (id_tipo1,id_linha,texto) 
		      			 		VALUES ('$n',' $n_linha',' $xt')";
									
										if (mysqli_query($conn, $sql))
								{
								   /*   echo "New record created successfully";*/
								} else {
								      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
								}
								/*mysqli_close($conn);*/
							}
      			 		}


      			 		$sql = "INSERT INTO tabela_rascunho  (id_prova,fase1,fase2,texto1,linha) VALUES ('$idProva',' $tipo1',' $tipo2',' $xt',2)";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela RASCUNHO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}



      			 		$_SESSION['info_linha2']=$_SESSION['info_linha'];

      			 		$resposta_linha_2=$_SESSION['info_linha2'];
      			 		$idProva=$_SESSION['id_prova'];

      			 		$sql = "INSERT INTO tabela_gabarito (id_prova,linha,resposta) VALUES ('$idProva',2,' $resposta_linha_2')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela GABARITO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}


					}

/*--------------------------------------------------------------------------------------------------------------------------------------------*/
									/*                       Linha 3                                     */
/*--------------------------------------------------------------------------------------------------------------------------------------------*/

						if ($_SESSION['n_linha'] ==3)

				    {
						 	if ($_SESSION['dado_Fase2']=='')
						 	 {
						 		$_SESSION['info_linha']= $_SESSION['dado_Fase1'].'<br>';
						 	 }
						 	 else
						 	 {
								$_SESSION['info_linha']= $_SESSION['dado_Fase1'].$_SESSION['dado_Fase2'].'<br>';
							 }

			
								 $tipo1=$_SESSION['Tipo_Fase1'];
								 $tipo2=$_SESSION['Tipo_Fase2'];
								 $idProva=$_SESSION['id_prova'];

						$sql = "INSERT INTO tabela_linha3 (id_prova,fase1,fase2) VALUES ('$idProva',' $tipo1',' $tipo2')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "New record created successfully";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}
								


								$consulta_id_linha3 = "SELECT id_linha FROM tabela_linha3 WHERE id_prova=$idProva";
      							$con_id_linha3 = $mysqli-> query( $consulta_id_linha3) or die($mysqli-> erro);

      			 			while ($dado_id_linha3 = $con_id_linha3-> fetch_array())
      			 		{ 
		      			 	if (($_SESSION['Tipo_Fase1'] ==1) or ($_SESSION['Tipo_Fase2'] ==1) )
		      			 	{
		      			 		
		      			 	
		      			 		$n_linha =$dado_id_linha3 ["id_linha"];
		      			 		$n=1;
		      			 		$k=$_SESSION['texto'];
		      			 		$xt=$_SESSION['texto_tipo_1'];
		      			 		$sql = "INSERT INTO tabela_tipo1 (id_tipo1,id_linha,texto) 
		      			 		VALUES ('$n',' $n_linha',' $xt')";
									
										if (mysqli_query($conn, $sql))
								{
								   /*   echo "New record created successfully";*/
								} else {
								      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
								}
								/*mysqli_close($conn);*/
							}
      			 		}


      			 		$sql = "INSERT INTO tabela_rascunho  (id_prova,fase1,fase2,texto1,linha) VALUES ('$idProva',' $tipo1',' $tipo2',' $xt',3)";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela RASCUNHO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}



      			 		$_SESSION['info_linha3']=$_SESSION['info_linha'];

      			 		$resposta_linha_3=$_SESSION['info_linha3'];
      			 		$idProva=$_SESSION['id_prova'];

      			 		$sql = "INSERT INTO tabela_gabarito (id_prova,linha,resposta) VALUES ('$idProva',3,' $resposta_linha_3')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela GABARITO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}


					}


/*--------------------------------------------------------------------------------------------------------------------------------------------*/
									/*                       Linha 4                                     */
/*--------------------------------------------------------------------------------------------------------------------------------------------*/

						if ($_SESSION['n_linha'] ==4)

				    {
						 	if ($_SESSION['dado_Fase2']=='')
						 	 {
						 		$_SESSION['info_linha']= $_SESSION['dado_Fase1'].'<br>';
						 	 }
						 	 else
						 	 {
								$_SESSION['info_linha']= $_SESSION['dado_Fase1'].$_SESSION['dado_Fase2'].'<br>';
							 }

			
								 $tipo1=$_SESSION['Tipo_Fase1'];
								 $tipo2=$_SESSION['Tipo_Fase2'];
								 $idProva=$_SESSION['id_prova'];

						$sql = "INSERT INTO tabela_linha4 (id_prova,fase1,fase2) VALUES ('$idProva',' $tipo1',' $tipo2')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "New record created successfully";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}
								


								$consulta_id_linha4 = "SELECT id_linha FROM tabela_linha4 WHERE id_prova=$idProva";
      							$con_id_linha4 = $mysqli-> query( $consulta_id_linha4) or die($mysqli-> erro);

      			 			while ($dado_id_linha4 = $con_id_linha4-> fetch_array())
      			 		{ 
		      			 	if (($_SESSION['Tipo_Fase1'] ==1) or ($_SESSION['Tipo_Fase2'] ==1) )
		      			 	{
		      			 		
		      			 	
		      			 		$n_linha =$dado_id_linha4 ["id_linha"];
		      			 		$n=1;
		      			 		$k=$_SESSION['texto'];
		      			 		$xt=$_SESSION['texto_tipo_1'];
		      			 		$sql = "INSERT INTO tabela_tipo1 (id_tipo1,id_linha,texto) 
		      			 		VALUES ('$n',' $n_linha',' $xt')";
									
										if (mysqli_query($conn, $sql))
								{
								   /*   echo "New record created successfully";*/
								} else {
								      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
								}
								/*mysqli_close($conn);*/
							}
      			 		}


      			 		$sql = "INSERT INTO tabela_rascunho  (id_prova,fase1,fase2,texto1,linha) VALUES ('$idProva',' $tipo1',' $tipo2',' $xt',4)";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela RASCUNHO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}



      			 		$_SESSION['info_linha4']=$_SESSION['info_linha'];

      			 		$resposta_linha_4=$_SESSION['info_linha4'];
      			 		$idProva=$_SESSION['id_prova'];

      			 		$sql = "INSERT INTO tabela_gabarito (id_prova,linha,resposta) VALUES ('$idProva',4,' $resposta_linha_4')";
							
								if (mysqli_query($conn, $sql))
						{
						    /*  echo "Dado na Tabela GABARITO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}


					}
/*--------------------------------------------------------------------------------------------------------------------------------------------*/
		


/*--------------------------------------------------------------------------------------------------------------------------------------------*/
					$yx=$_SESSION['n_linha'];
					$idProva=$_SESSION['id_prova'];

					$sql = "UPDATE tabela_prova SET qtd_linhas=$yx WHERE id_prova=$idProva";
							
								if (mysqli_query($conn, $sql))
						{
						   /*   echo "Dado na Tabela GABARITO ADD!!";*/
						} else {
						      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
						}


						$_SESSION['fase']=1;

						$_SESSION['n_linha']=$_SESSION['n_linha']+1;

						$habilitado ='';

						

						$_SESSION['info_linha'] ='';
						$_SESSION['Tipo_Fase1']=0;
						$_SESSION['Tipo_Fase2']=0;
		}

				if (isset($_POST['btn-salvar'])) 
				{

				$yx=$_SESSION['n_linha'];
					$idProva=$_SESSION['id_prova'];

					
					$habilitar_btn_visualizar='';
				}

				if (isset($_POST['btn-visualizar']))

				{
					header('Location: TelaVisualizarCodigoeGabarito.php');
				}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src ="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.5/chosen.min.css
">
</head>
<body contenteditable>

<form action="" method="POST">
				 <?php while ($dado_id_prova = $con_id_prova-> fetch_array()){ ?>

			<div class="container">

				<div  class="div-painel-1" >
					<div class=" div-opcao1"  >
						 <label class="label-op1">Modelo 1</label>
						<button name="btn-add" class="btn-add" <?php echo $habilitado ?> >  Adicionar <i class="fa fa-plus" ></i> </button>

					</div>
						<div class="div-op-1">
							    <div class="op-1">
											<label class="texto1"> < </label> 
											<select   name="combo1"  class="chosen" <?php echo $habilitado ?> >

											   <option value=""></option>
										       <option value="li">li</option>
										       <option value="p">p</option>
										       <option value="src">src</option>
										       <option value="h1">h1</option>
										       <option value="input">input</option>
										       <option value="button">button</option>
										       <option value="img">img</option>
										       <option value="a href">a href</option>
										       <option value="br">br</option>
										       <option value="div">div</option>
										       <option value="hr">hr</option>
										       <option value="ul">ul</option>
										       <option value="audio">audio</option>
										       <option value="video">video</option>
										       <option value="textarea">textarea</option>
										       <option value="label">label</option>
										       <option value="option">option</option>
										       <option value="h2">h2</option>
										       <option value="h3">h3</option>
										       <option value="h4">h4</option>
										       <option value="h5">h5</option>
										                        
										                        
											</select><label class="texto1"> ></label>

											<input type="text" name="texto-campo1" class="texto-combo1" <?php echo $habilitado ?>>

											<label class="texto1"> < / </label>   <select name="combo2" class="chosen" <?php echo $habilitado ?> >

										   <option value=""></option>
									       <option value="li">li</option>
									       <option value="p">p</option>
									       <option value="src">src</option>
									       <option value="h1">h1</option>
									       <option value="input">input</option>
									       <option value="button">button</option>
									       <option value="img">img</option>
									       <option value="a href">a href</option>
									       <option value="br">br</option>
									       <option value="div">div</option>
									       <option value="hr">hr</option>
									       <option value="ul">ul</option>
									       <option value="audio">audio</option>
									       <option value="video">video</option>
									       <option value="textarea">textarea</option>
									       <option value="label">label</option>
									       <option value="option">option</option>
									       <option value="h2">h2</option>
									       <option value="h3">h3</option>
									       <option value="h4">h4</option>
									       <option value="h5">h5</option>
									                        
									                        
									</select><label class="texto1">></label>
								</div>
						</div>

				</div>
					


					<div class="div-painel-2">
					<div class=" div-opcao2">
						 <label class="label-op1">Modelo 2</label>
						<button name="btn-add2"  class="btn-add"  <?php echo $habilitado ?>  >Adicionar <i class="fa fa-plus" ></i></button>

					</div>
						<div class="div-op-2">
							    <div class="op-2">
											<label class="texto1"> < </label> 
											<select   name="modelo2-combo3"  class="chosen" <?php echo $habilitado ?> >

											   <option value=""></option>
										       <option value="li">li</option>
										       <option value="p">p</option>
										       <option value="src">src</option>
										       <option value="h1">h1</option>
										       <option value="input">input</option>
										       <option value="button">button</option>
										       <option value="img">img</option>
										       <option value="a href">a href</option>
										       <option value="br">br</option>
										       <option value="div">div</option>
										       <option value="hr">hr</option>
										       <option value="ul">ul</option>
										       <option value="audio">audio</option>
										       <option value="video">video</option>
										       <option value="textarea">textarea</option>
										       <option value="label">label</option>
										       <option value="option">option</option>
										       <option value="h2">h2</option>
										       <option value="h3">h3</option>
										       <option value="h4">h4</option>
										       <option value="h5">h5</option>
										                        
										                        
											</select><label class="texto1"> type =</label>

											

											  <select name="modelo2-combo4" class="chosen" <?php echo $habilitado ?> >

										    <option value=""></option>
					                        <option value="textarea">textarea</option>
					                        <option value="video">video</option>
					                        <option value="text">text</option>
					                        <option value="submit">submit</option>
					                        <option value="checkbox">checkbox</option>
						                    <option value="number">number</option>
						                    <option value="password">password</option>
						                    <option value="color">color</option>
									                        
									                        
									</select><label class="texto1"> /></label>
								</div>
						</div>

				</div>

				

			<div class="base">

				<div class="container-botao">
					
					<button class="btn-prox-linha" name="Botao_Proxima_Linha">Próxima Linha</button>
					<button class="btn-salvar" name="btn-salvar">Salvar</button>
					<button name="btn-visualizar" class="btn-visualizar" <?php echo $habilitar_btn_visualizar ?>>Visualizar Prova</button>
				</div>

				<div class="div-ID-Prova">
					<label>Código Prova:</label> <input type="text" name="campo-id" disabled="" value=<?php echo $dado_id_prova['ID']?> >
					<?php  $_SESSION['id_prova']=  $dado_id_prova['ID'] ?>
					<br>
					<label> Linha <?php echo $_SESSION['n_linha'];?></label>
					<br>
					
				</div>			
					
					
			</div>
				

				

			</div>
					<br> <br><br>
				

		 <?php }   ?>
</form>
</body>
<script type="text/javascript">
	$('.chosen').chosen();




</script>
</html>
<style type="text/css">

yle type="text/css">
	@import url(https://fonts.googleapis.com/css?family=Walter+Turncoat);
html {
  background: -webkit-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -moz-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -ms-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: -o-linear-gradient(90deg, #485563 10%, #29323c 90%);
  background: linear-gradient(90deg, #485563 10%, #29323c 90%);
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
  overflow: hidden
}

body {
  font-size: 40px;
  color: #E8E8E8;
  font-family: "Walter Turncoat", cursive;
  display: block;
  width: 80%;
  height: 80%;
  min-height: auto;
  margin: 8px auto 0 auto;
  background-color: #497959;
  padding: 20px 30px;
  overflow-y: auto;
  box-shadow: -1px 2px 2px 0px #555, inset 0 0 10px 0 #555;
  -webkit-border-radius: 10px;
  -khtml-border-radius: 10px;
  -moz-border-radius: 10px;
  -ms-border-radius: 10px;
  -o-border-radius: 10px;
  border-radius: 10px;
  border: #B78240 solid 10px;
  
  background-size: cover;
  background-repeat: no-repeat;
  position: relative;
}

body:after {
  content: "";
  display: block;
  position: fixed;
  -webkit-border-radius: 0.1em 0.1em 0 0.1em;
  -khtml-border-radius: 0.1em 0.1em 0 0.1em;
  -moz-border-radius: 0.1em 0.1em 0 0.1em;
  -ms-border-radius: 0.1em 0.1em 0 0.1em;
  -o-border-radius: 0.1em 0.1em 0 0.1em;
  border-radius: 0.1em 0.1em 0 0.1em;
  width: 50px;
  height: 8px;
  background: #f1f1f1;
  top: 80%;
  margin-top: 75px;
  margin-right: 60px;
  right: 5%;
  box-shadow: inset 0 -4px 1px rgba(0, 0, 0, 0.3), -1px -1px 1px rgba(0, 0, 0, 0.2), 0 2px 0 rgba(0, 0, 0, 0.3)
}
	.base
	{
		position: relative;
		top: 200px;
		left: 100px;
	}

	.div-ID-Prova
	{
		position: relative;
		
		height: 50px;
		width: 200px;
		top: -300px;
		display: inline;
	}

	.div-painel-1
	{
		background: none;
		width: 430px;
		height: 150px;
		border: 3px solid black;
		font-size: 0.4em;
	}

	.container
	{
		position: relative;
		width: 850px;
		height: 300px;
		background: none;
	}
	.div-opcao1
	{
		position: relative;
		left: 170px;
		font-size: 2em;
	}
	.op1
	{
		 border: 0px;
    width: 100px;
    height: 2em;
    position: relative;
    left: 90px;
    cursor: pointer;
	}
	.label-op1
	{
		font-size: 1em;
		position: relative;
		left: 20px;
	}

	.div-op-1
	{
	
		position: relative;
		width: 345px;
		height: 100px;
		top: 8px;
		/*border: 3px solid red;*/
	}
	.texto-combo1
	{
		width: 100px;
	}

	.op-1
	{
		display: inline-block;
		position: relative;
		top: 20px;
	}

	.btn-add
	{
		position: relative;
		left: -300px;
		
		cursor: pointer;

		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.4em;

	}

	.btn-add:hover
	{
		position: relative;
		left: -300px;
		
		cursor: pointer;

		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.4em;
		 color: red;

	}

	

	/* MODELO 2 ============================================================================== */

	.div-painel-2
	{
		background: none;
		width: 350px;
		height: 150px;
		border: 3px solid black;
		position: relative;
		left: 700px;
		top: -150px;
		font-size: 0.4em;
	}

	
	.div-opcao2
	{
		position: relative;
		left: 170px;
		font-size: 2em;
	}
	.op2
	{
		 border: 0px;
    width: 100px;
    height: 2em;
    position: relative;
    left: 90px;
    cursor: pointer;
	}
	

	.div-op-2
	{
	
		position: relative;
		width: 345px;
		height: 100px;
		top: 26px;
		/*border: 3px solid red;*/
	}
	

	.op-1
	{
		display: inline-block;
		position: relative;
		top: 20px;
	}


	/*======================================== B  O T O E S =========================================================== */

	.container-botao
	{
		display: inline-block;
		position: relative;
		
		top: -100px;
		width: 1100px;
		left: -100px;
	}
	.btn-prox-linha
	{
		position: relative;
		/*left: 650px; top: -220px;*/
		
		cursor: pointer;
		

		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.8em;

	}

	.btn-prox-linha:hover
	{
		position: relative;
		/*left: 650px; top: -220px;*/
		
		cursor: pointer;
		

		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.8em;
		color: blue;

	}

	.btn-salvar
	{
		position: relative;
		/*left: 200px; top: -210px;*/
		
		cursor: pointer;
		

		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.8em;
		
		margin:10px;

	}

	.btn-salvar:hover
	{
		position: relative;
				
		cursor: pointer;
		
		font-family: "Walter Turncoat", cursive;
		border: none;
	
		color: white;
	 	letter-spacing: 0.5ch;
		 font-size: 0.8em;
		
		margin:10px;
		color: black;

	}

	.btn-visualizar
	{
		position: relative;
				
		cursor: pointer;
		
		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.8em;
	}

	.btn-visualizar:hover
	{
		position: relative;
				
		cursor: pointer;
		
		font-family: "Walter Turncoat", cursive;
	border: none;
	background: none;
	color: white;
	 letter-spacing: 0.5ch;
		 font-size: 0.8em;
		 color: yellow;
	}
/*======================================== prova =========================================================== */

	.div-prova
	{
		position: relative;
		
		height: 250px;
		width: 780px;
		left: 550px;
		top: -239px;
		background: skyblue;
		
		overflow: hidden;
		font-size: 1.2em;
	}

	.div-prova-executavel
	{
		margin: 0 auto;
		font-size: 1.2em;

		position: relative;

		height: 200px;
		width: 700px;
		left: -10px;
		top: 20px;
		/*background: blue;*/



	}


	.teste
	{
		width: 530px;
		height: 240px;
		font-size: 1.3em;
		color: red;
		display: inline;

	}

	.div-gabarito-prova
	{
		/*background: red;*/
		width: 1280px;
		height: 30px;
		position: relative;
		top: -60px;
	}
	
	.div-gabarito
	{
		font-size: 1.3em;
		color: blue;
		position: relative;
		left: 50px;
	}

	.div-prova-resultado
	{
		font-size: 1.3em;
		color: green;
		position: relative;
		right: -750px;
	}

	.div-executavel-gabarito
	{
		background: yellow;
		width: 1500px;
		height: 800px;
		position: relative;
		top: -50px;

	}

</style>



