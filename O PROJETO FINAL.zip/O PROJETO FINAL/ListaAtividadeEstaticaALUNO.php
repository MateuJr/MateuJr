<?php
session_start();
$host ="localhost";
  $usuario = "root";          
  $senha = "";
  $bd = "projeto_tcc";
$msg='Selecione...'; 

$var_ID_IE='';


$Numero_PROF='';

$ocultar= 'style="display:none;"';

$Numero_IE='';
$Numero_DIS='';

$Numero_ID_Aluno=$_SESSION['session_ID_Aluno_numero'];

$Numero_ID_Instituto_Aluno=$_SESSION['session_IE_Aluno_numero'];

/*$var_ID_PROF=$_SESSION['session_ID_professor'];*/
$mysqli = new mysqli($host,$usuario,$senha,$bd);


$conn = new mysqli ("localhost", "root", "", "projeto_tcc")
 or die("Error:" . mysqli_error($conn));

 $var_mysqli = new mysqli($host,$usuario,$senha,$bd);

 $_SESSION['sessao_ID_IE_aux']='';

$var_ID_DIS='';
/*===========================================================================================================================================*/



/*===========================================================================================================================================*/

                            /*  Código permite Visualizar as atividades em outra Página */
/*===========================================================================================================================================*/


if (isset($_POST['ver']))
 {

  $ID= $_POST['ver'];
$_SESSION['id_atividade_ESTATICA_aluno']=$_POST['ver'];
    $sql_buscar_dados_prova="SELECT * FROM tabela_atividade_estatica
               WHERE id_atividade_estatica =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova = $var_mysqli-> query($sql_buscar_dados_prova);
                
              }

              while ($dado_info_prova = $con_info_prova-> fetch_array())
              {
                $_SESSION['session_info_prova_assunto']= $dado_info_prova['assunto'];
                $_SESSION['session_info_prova_objetivo']=$dado_info_prova['objetivo']; 
                $_SESSION['session_info_prova_titulo']=$dado_info_prova['titulo_atividade']; 
              }

$sql_buscar_dados_prova_PROFESSOR ="SELECT * FROM tabela_atividade 
               WHERE id_atividade =(select id_atividade from tabela_atividade_estatica where
 id_atividade_estatica = ' $ID ') ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova_PROFESSOR))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_PROFESSOR = $var_mysqli-> query($sql_buscar_dados_prova_PROFESSOR);
                
              }

              while ($dado_info_prova_PROFESSOR = $con_info_prova_PROFESSOR-> fetch_array())
              {
                $_SESSION['session_info_prova_ID_professor']= $dado_info_prova_PROFESSOR['id_professor'];
                $_SESSION['session_info_prova_ID_Disciplina']=$dado_info_prova_PROFESSOR['id_disciplina']; 
                $_SESSION['session_info_prova_ID_instituto']=$dado_info_prova_PROFESSOR['id_instituto']; 
              }

              header("location: ExibirResultadoAlunoAtividade.php");

/*Buscar gabarito da atividade */
$sql_buscar_Gabarito="SELECT * FROM tabela_gabarito_estatico
               WHERE id_atividade_estatica =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_Gabarito))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_GABARITO = $var_mysqli-> query($sql_buscar_Gabarito);
                
              }

              while ($dado_info_prova_GABARITO = $con_info_prova_GABARITO-> fetch_array())
              {
                $_SESSION['session_info_prova_GABARITO']= $dado_info_prova_GABARITO['gabarito'];
                
              }



 }

/*===============================================================================================================================================================================================================================================================

=========================================*/

if (isset($_POST['start']))
 {

        $ID= $_POST['start'];

        $sql_buscar_dados_prova="SELECT * FROM tabela_atividade_estatica
               WHERE id_atividade_estatica =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova = $var_mysqli-> query($sql_buscar_dados_prova);
                
              }

              while ($dado_info_prova = $con_info_prova-> fetch_array())
              {
                $_SESSION['session_info_prova_assunto']= $dado_info_prova['assunto'];
                $_SESSION['session_info_prova_objetivo']=$dado_info_prova['objetivo']; 
                $_SESSION['session_info_prova_titulo']=$dado_info_prova['titulo_atividade']; 
              }

            $sql_buscar_dados_prova_PROFESSOR ="SELECT * FROM tabela_atividade 
                           WHERE id_atividade =(select id_atividade from tabela_atividade_estatica where
             id_atividade_estatica = ' $ID ') ";

               if (!$var_mysqli -> query( $sql_buscar_dados_prova_PROFESSOR))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_PROFESSOR = $var_mysqli-> query($sql_buscar_dados_prova_PROFESSOR);
                
              }

              while ($dado_info_prova_PROFESSOR = $con_info_prova_PROFESSOR-> fetch_array())
              {
                $_SESSION['session_info_prova_ID_professor']= $dado_info_prova_PROFESSOR['id_professor'];
                $_SESSION['session_info_prova_ID_Disciplina']=$dado_info_prova_PROFESSOR['id_disciplina']; 
                $_SESSION['session_info_prova_ID_instituto']=$dado_info_prova_PROFESSOR['id_instituto']; 
              }

              header("location: TelaPraticandoAtividadeEstaticaProfessor.php");

            /*Buscar gabarito da atividade */
            $sql_buscar_Gabarito="SELECT * FROM tabela_gabarito_estatico
               WHERE id_atividade_estatica =' $ID ' ";

               if (!$var_mysqli -> query( $sql_buscar_Gabarito))
                 {
                      echo("Error description: " . $var_mysqli -> error);
              }else
              {
                $con_info_prova_GABARITO = $var_mysqli-> query($sql_buscar_Gabarito);
                
              }

              while ($dado_info_prova_GABARITO = $con_info_prova_GABARITO-> fetch_array())
              {
                $_SESSION['session_info_prova_GABARITO']= $dado_info_prova_GABARITO['gabarito'];
                
              }



 }

/*=========================================================*/
/*===========================================================================================================================================*/

   if (isset($_POST['btn-prox']))
     {
        
        $var_ID_DIS=$_POST['combobox_DIS'];
        
        $_SESSION['session_ID_DIS']=$_POST['combobox_DIS'];
       

        

     
    }

/*===========================================================================================================================================*/

                            /*  PREENCHE O SEGUNDO COMBO LIST COM OS NOMES DOS PROFESSORES do ALUNO */
/*===========================================================================================================================================*/


   

 $sql_busca_PROF="SELECT distinct (tp.nome_professor) as nome_PROF, tp.id_professor as id_PROF FROM tabela_professor as tp
  where tp.id_professor IN (SELECT tpd.id_professor FROM  tabela_prof_disciplina as tpd WHERE 
    tpd.id_disciplina= ' $var_ID_DIS ' and tpd.id_professor IN ( SELECT tpa.id_professor FROM tabela_prof_aluno as tpa WHERE tpa.id_aluno=' $Numero_ID_Aluno '))";

         if (!$mysqli -> query( $sql_busca_PROF))
             {
                  echo("Error description: " . $mysqli -> error);
                 
          }else
          {
            $sql_resultado_PROF = $mysqli-> query($sql_busca_PROF);
           
            
          }

          

/*===========================================================================================================================================*/

 

    

/*===========================================================================================================================================*/

                            /*  PREENCHE O PRIMEIRO COMBO LIST COM OS NOMES DAS DISCIPLINAS do ALUNO */

$sql_busca_DIS="SELECT td.nome_disciplina as nome_dis, td.id_disciplina as id_dis FROM tabela_disciplina as td 
WHERE td.id_disciplina IN (SELECT tda.id_disciplina FROM tabela_disciplina_aluno as tda WHERE  tda.id_aluno=' $Numero_ID_Aluno ');";

         if (!$mysqli -> query( $sql_busca_DIS))
             {
                  echo("Error description: " . $mysqli -> error);
                  
          }else
          {
            $sql_resultado_DIS = $mysqli-> query($sql_busca_DIS);

          }

        

 /*===========================================================================================================================================*/           
    if (isset($_POST['btn-pesquisar']))
     {
       
             $ocultar='';

            
            $_SESSION['session_ID_PROF']=$_POST['combobox_PROF'];

              $Numero_DIS=$_SESSION['session_ID_DIS'];
             $Numero_PROF=$_SESSION['session_ID_PROF'];

             
           
     } 

/*========================================================================================================================================*/

if (isset($_POST['btn-sair'])) 
{
  
              header("location: MenuPrincipalNovo.php");
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">

    <title>Tela Listagem de Atividades</title>
  </head>
  <body>
    <form action="" method="POST">
    <div class="container-filtragem">
                <fieldset> <legend>Filtrar Pesquisa: </legend>
               
                  <div class="container-conteudo">
              <label>Disciplina: </label><select  class="combo-estilo"    name="combobox_DIS"  >
                <option>Selecione...</option> 
                <?php while ($dado_DIS = $sql_resultado_DIS-> fetch_array()){ ?>


           
                <option  value="<?php echo $dado_DIS['id_dis'] ?>" ><?php echo $dado_DIS['nome_dis'] ?></option>
           


           <?php }   ?>
           
           </select><button class="botao-editar2" name="btn-prox"> <i class="fas fa-forward"></i></button><label>Professor: </label><select  class="combo-estilo"    name="combobox_PROF"  >
                <option>Selecione...</option> 
                <?php while ($dado_PROF = $sql_resultado_PROF-> fetch_array()){ ?>


           
                <option  value="<?php echo $dado_PROF['id_PROF'] ?>" ><?php echo $dado_PROF['nome_PROF'] ?></option>
           


           <?php }   ?>
           
           </select><button class="botao-editar2" name="btn-pesquisar"><i  id="oo" class="fas fa-search"></i> </button>
           <button class="botao-editar2" name="btn-sair"><i class="fas fa-sign-out-alt"></i> Sair</button>
           </div>
          </fieldset>
    </div>
</form>
    <?php require_once("ListaAtividadeEstaticaALUNO.php"); ?>

    <div class="container">
      <?php if (isset($_SESSION['msg'])): ?>
        

      <?php endif; ?>
      
      <table class="table" <?php echo $ocultar; ?> >
        <thead>
          <tr class="teste">
            <th>Serial</th>
            <th>Título</th>
            <th>Assunto</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <form action="ListaAtividadeEstaticaALUNO.php" method="POST">
          <?php 
          #Codigo para Listar os Dados
          $sQuery ="SELECT tae.id_atividade_estatica as ID,tae.titulo_atividade as titulo,tae.assunto as assunto FROM tabela_atividade_estatica as tae 
          INNER JOIN tabela_atividade as ta on (tae.id_atividade=ta.id_atividade)
           AND ta.id_professor=' $Numero_PROF ' AND ta.id_instituto=' $Numero_ID_Instituto_Aluno ' AND ta.id_disciplina=' $Numero_DIS ' limit 100";

           $result =$conn->query($sQuery);

           # Código Botão Editar

           while ($row = $result->fetch_assoc()): ?>
            <tr class="teste2">
              <td><?= $row['ID']; ?></td>
               <td><?= $row['titulo']; ?></td>
               <td><?= $row['assunto']; ?></td>
               <td style="width: 15%">
                 <button class="botao-editar" type="submit" name="start" value="<?= $row['ID']; ?>"><i class="fas fa-code"></i></button>

                 

                  <button class="botao-editar" type="submit" name="ver" value="<?= $row['ID']; ?>"><i class="fas fa-eye"></i></button>
                 
               </td>

            </tr>

          <?php endwhile; ?>
          </form>
          
        </tbody>
        
      </table>


    </div>
   
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    

  </body>
</html>

<style type="text/css">

  body
  {
    background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);
  }
  .combo-estilo
{
  
  font-size: 1.4em;
  width: 250px;
  border: none;
  
  vertical-align: middle;
    font-family: 'Permanent Marker', cursive;
    font-size: 1.6em;
    color: black;
    text-align: center;
    background: none;
    cursor: pointer;
}


fieldset
{
 border:2px solid white;
    -moz-border-radius:8px;
    -webkit-border-radius:8px;  
    border-radius:8px;  
   background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);
   color: white;
}

.container-conteudo
{
  color: white;
  position: relative;
  font-size: 1.3em;
  text-align: center;
  vertical-align: center;
}

.container-filtragem
{
  width: 1010px;
  padding: 10px;
  position: relative;
  left: 150px;

}

.teste
{
  border:2px solid black ;
   border-radius:8px; 
   background: black;
   color:white;

}

.teste2
{
   border:2px solid black ;
   border-radius:8px; 
   background: white;
   color:black;
}

.botao-editar
{
  border: none;
  color: black;
  background: white;
  font-size: 2em;
  margin: 2px;

}

.botao-editar2
{
  border: none;
  color: white;
  
  font-size: 1em;
  margin: 2px;
  background: -webkit-linear-gradient(
45deg,#4158d0,#c850c0);

}


</style>