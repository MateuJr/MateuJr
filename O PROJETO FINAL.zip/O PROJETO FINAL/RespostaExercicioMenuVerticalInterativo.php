<?php 
session_start();
if (isset($_POST['botao-voltar'])) {
	 header('Location: ExecutavelExercicioMenuVerticalInterativo.php');
}

$variavel_linha_7='<div class="vertical-menu">';

$variavel_linha_13='</div>';
$variavel_linha_14='<style>';
$variavel_linha_15='.vertical-menu{';
$variavel_linha_16='width: 200px;';
$variavel_linha_17='text-align:';
$variavel_linha_18='.vertical-menu a{';
$variavel_linha_19='#000;';

$variavel_linha_21='Display:';
$variavel_linha_22='12px;';
$variavel_virgula_colchete=';}';
$variavel_linha_23='text-decoration:';
$variavel_colchete='}';

$variavel_linha_24='.vertical-menu a:hover {';

$variavel_linha_26='</style>';

$variavel_ponto_virgula=';';

$variavel_linha_26='</style>';

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
</head>
<body>
<form action="" method="POST">
	<h1 align="center">Gabarito</h1>
	
	<div>
	  <div class="container">
	    <ul>
	      <li><a href="ExecutavelExercicioMenuVerticalInterativo.php" name="botao-voltar"><i class="fa fa-arrow-left" aria-hidden="true" ></i></a></li>
	     <br>
	      <li><a href="MenuAtividadeInterativaDesenvolvedor.php"><i class="fa fa-home" aria-hidden="true"></i></a></li>
	    </ul>
	  </div>
	</div>

	<h4 class="txt-resp">Sua Resposta</h4>
	<h4 class="txt-gabarito">Gabarito</h4>
</form>
             <textarea name="sourceCode" id="sourceCode" class="textarea1">

<html>
<head>
<title>Hello</title>
</head>
<body>


	<<?php echo  $_SESSION['L_6_1'];?>>Menu Vertical</<?php echo  $_SESSION['L_6_2'];?>>
<?php echo $variavel_linha_7;?>

    <<?php echo   $_SESSION['L_8_1'];?>>Home</<?php echo  $_SESSION['L_8_2'];?>> 
    <<?php echo   $_SESSION['L_9_1'];?>>Perfil</<?php echo  $_SESSION['L_9_2'];?>>
    <<?php echo   $_SESSION['L_10_1'];?>>Sobre Nós</<?php echo  $_SESSION['L_10_2'];?>>
    <<?php echo   $_SESSION['L_11_1'];?>>Configurações </<?php echo  $_SESSION['L_11_2'];?>>
    <<?php echo   $_SESSION['L_12_1'];?>>Logout </<?php echo  $_SESSION['L_12_2'];?>>

 <?php echo $variavel_linha_13; ?>

 <?php echo $variavel_linha_14; ?>

 <?php echo $variavel_linha_15; ?>

 <?php echo $variavel_linha_16; ?>

 <?php echo $variavel_linha_17; ?> <?php echo   $_SESSION['L_17_1'];?><?php echo $variavel_ponto_virgula; ?> <?php echo $variavel_colchete; ?>
 
 <?php echo $variavel_linha_18; ?>

 <?php echo   $_SESSION['L_19_1'];?><?php echo $variavel_linha_19; ?>

<?php echo   $_SESSION['L_20_1'];?><?php echo   $_SESSION['L_20_2'];?><?php echo $variavel_ponto_virgula; ?>

<?php echo $variavel_linha_21; ?><?php echo   $_SESSION['L_21_1'];?><?php echo $variavel_ponto_virgula; ?>

<?php echo   $_SESSION['L_22_1'];?><?php echo $variavel_linha_22; ?>

<?php echo $variavel_linha_23; ?><?php echo   $_SESSION['L_23_1'];?><?php echo $variavel_virgula_colchete; ?>

<?php echo $variavel_linha_24; ?>

<?php echo   $_SESSION['L_24_1'];?><?php echo   $_SESSION['L_24_2'];?>

<?php echo $variavel_colchete ?>

<?php echo $variavel_linha_26; ?>



</body>
</html>
                        </textarea>

             <textarea name="sourceCode" id="sourceCode" class="textarea2">
<html>
<head>
<title>Hello</title>
</head>
<body>


	<h1>Menu Vertical</h1>

<div class="vertical-menu">
  <a href="#">Home</a>
  <a href="#">Perfil</a>
  <a href="#">Sobre nós</a>
  <a href="#">Configurações</a>
  <a href="#">Logout</a>
</div>

<style>

.vertical-menu {
  width: 200px;
  text-align: center; 
}

.vertical-menu a {
  background-color: #000; 
  color: white;
  display: block;
  padding: 12px; 
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #ccc; 
}


</style>
</body>
</html>
                        </textarea>


</body>
</html>

<style type="text/css">
	body
	{
		overflow: hidden;
		background: black;
	}
	.textarea1
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			top: -150px;

	}

	.textarea2
	{
		border: 2px solid #ddd;
    			height: 500px;
    			width: 600px;
    			position: relative;
    			left: 100px;
    			top: -150px;

	}

	.txt-resp
	{
		font-size: 1.4em;
		color: red;
		position: relative;
		top: -80px;
	}

	.txt-gabarito
	{
		font-size: 1.4em;
		color: green;
		position: relative;
		left: 750px;
		top: -140px;
	}
	.btn-voltar
	{
		height: 50px;
		width: 50px;
		position: relative;
		left: 630px;
		top: 250px;
		cursor: pointer;
	}

	/*======================= BOTÃO =============================================*/

	ul {
  margin:0;
  padding:0;
  display:block;
  position: absolute;
  top: 50%;
  left:49%;
  transform: translate(-50%, -50%);
}

ul li {
  list-style:none;
  margin: 0 15px;
}

ul li a {
  position: relative;
  display: block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  background: #171515;
  border-radius: 50%;
  font-size: 30px;
  color: #666;
  transition: .5s;
}

ul li a:before {
  content: '';
  position: absolute;
  top:0;
  left:0;
  width:100%;
  height:100%;
  border-radius:50%;
  background: #d35400;
  transition: .5s;
  transform: scale(.9);
  z-index: -1;
}

ul li a:hover:before {
  transform: scale(1.2);
  box-shadow: 0 0 15px #d35400;
  filter: blur(3px);
}

ul li a:hover {
  color: #ffa502;
  box-shadow: 0 0 15px #d35400;
  text-shadow: 0 0 15px #d35400;
}
</style>