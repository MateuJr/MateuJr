<?php 
session_start();

if (isset($_POST['botao-resposta'])) {
    header('Location: RespostaExercicioLoginInterativo.php');
}


if (isset($_POST['botao-praticar'])) {
    header('Location: teste.php');
}

if (isset($_POST['botao-home']))
 {
    header('Location: MenuPrincipalNovo.php');
}

?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Editor Html</title>
		<style type="text/css">
			textarea, iframe {
    			border: 2px solid #ddd;
    			height: 500px;
    			width: 100%;	
                color: yellow;  
                background: white;
			}
            .btn-executar{
                cursor: pointer;
            }
    	</style>
	</head>
    <body>
        <table width="100%" border="0" cellspacing="5" cellpadding="5">
            <tr>
                <td width="50%" scope="col">&nbsp;</td>
                <td width="50%" align="left" scope="col">
                    
                </td>
            </tr>
            <tr>
                <td>
                    <form action="" method="POST">

                        
                        <div class="multi-button">
                          <button name="botao-resposta">Gabarito</button>
                          <button name="botao-praticar">Praticar</button>
                          <button name="botao-home">Home</button>
                          <button onclick="runCode();" type="button"  value="Executar" class="btn-executar">Compilar</button>
                        </div>
               
                </form> 
                    <form>
                        <strong>Entrada</strong>
                        <textarea name="sourceCode" id="sourceCode">
<html>
<head>
<title>Hello</title>
</head>
<body>



<<?php echo  $_SESSION['L_6_1'];?>>Tela de Login</<?php echo  $_SESSION['L_6_2'];?>>
    <<?php echo   $_SESSION['L_7_1'];?>>Login</<?php echo  $_SESSION['L_7_2'];?>> <<?php echo   $_SESSION['L_7_3'];?> type="<?php echo  $_SESSION['L_7_4'];  ?>">
    <br>
    <<?php echo  $_SESSION['L_9_1'];?>>Senha</<?php echo  $_SESSION['L_9_2'];?>> <<?php echo $_SESSION['L_9_3']  ?> type="<?php echo $_SESSION['L_9_4']; ?>"  >
    <br>
    <<?php echo  $_SESSION['L_11_1'];  ?>>Entrar</<?php echo $_SESSION['L_11_2'];  ?>>







</body>
</html>
                        </textarea>
                    </form>
                </td>
                <td><strong>Saída</strong><iframe name="targetCode" id="targetCode"></iframe></td>
            </tr>
        </table>  
        <script type="text/javascript">
            function runCode()
            {
                var content = document.getElementById('sourceCode').value;
                var iframe = document.getElementById('targetCode');
                iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
                iframe.document.open();
                iframe.document.write(content);
                iframe.document.close();
                return false;
            }
            runCode();
        </script>
    </body>
</html>


<style type="text/css">
    body
    {
        background: black;
    }
    strong
    {
        color: red;
    }

    textarea
    {
        color: blue;
    }

    /*======================BOTÃO ============================================*/


:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;
  --color-secondary: #707B7C;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}



.multi-button {
  display: flex;
  width: 40%;
  box-shadow: var(--shadow) 4px 4px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  top: -40px;
  right: -240px;
  padding:
    calc(var(--space) / 1.125)
    var(--space)
    var(--space);
  border: var(--border-size) solid black;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  font-size: 1.5rem;
  font-family: var(--font-family);
  
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background-color: var(--color-secondary);
}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}
</style>